import React from "react";
import { Link, useLocation } from "react-router-dom";

function NavBar({ currentUser }) {
  const location = useLocation();
  const isActive = (path) => location.pathname.startsWith(path);

  return (
    <nav className="nav-bar">
      <Link
        to="/home"
        className={`nav-link ${isActive("/home") ? "active-link" : ""}`}
      >
        Home
      </Link>
      <span className="nav-separator">|</span>

      <Link
        to={`/profile/${currentUser.id}`}
        className={`nav-link ${isActive("/profile") ? "active-link" : ""}`}
      >
        Profile
      </Link>
      <span className="nav-separator">|</span>

      <Link
        to="/projects"
        className={`nav-link ${isActive("/projects") ? "active-link" : ""}`}
      >
        Projects
      </Link>
      <span className="nav-separator">|</span>

      <Link to="/" className="nav-link">
        Logout
      </Link>
    </nav>
  );
}

export { NavBar };
