import React, { useEffect, useState } from "react";
import { ViewOnlyGeneralData } from "./ViewOnlyGeneralData";

function Friends({ user }) {
  const [friends, setFriends] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  const fetchFriends = async () => {
    try {
      const res = await fetch(`/api/users/${user._id}/friends`);
      const data = await res.json();
      if (data.success) setFriends(data.friends);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchAllUsers = async () => {
    try {
      const res = await fetch("/api/users");
      const data = await res.json();
      if (data.success) setAllUsers(data.users.filter((u) => u._id !== user._id));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchFriends();
    fetchAllUsers();
  }, [user]);

  if (selectedUser)
    return (
      <div className="friends-card">
        <button className="friend-button" onClick={() => setSelectedUser(null)}>Back</button>
        <ViewOnlyGeneralData
          userId={selectedUser._id}
          currentUserId={user._id}
          onFriendChange={fetchFriends}
        />
      </div>
    );

  const friendIds = friends.map((f) => f._id);

  return (
    <div className="friends-card">
      <h2 className="section-title">{user.username}'s Friends</h2>

      {friends.length === 0 ? (
        <p>No friends yet</p>
      ) : (
        <ul className="friends-list">
          {friends.map((f) => (
            <li
              key={f._id}
              className="friend-item"
              onClick={() => setSelectedUser(f)}
            >
              <img
                className="friend-img"
                src={f.image || "/assets/images/default.png"}
                alt={f.username}
              />
              <span>{f.username}</span>
            </li>
          ))}
        </ul>
      )}

      <h2 className="section-title">All Users</h2>
      <ul className="friends-list">
        {allUsers.map((u) => (
          <li
            key={u._id}
            className="friend-item flex justify-between items-center"
          >
            <div
              className="flex items-center cursor-pointer"
              onClick={() => setSelectedUser(u)}
            >
              <img
                className="friend-img"
                src={u.image || "/assets/images/default.png"}
                alt={u.username}
              />
              <span>{u.username}</span>
            </div>

            {friendIds.includes(u._id) ? (
              <span className="friend-status">Friends</span>
            ) : (
              <button
                className="friend-button"
                onClick={async () => {
                  try {
                    const res = await fetch(`/api/users/${user._id}/friends`, {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ friendId: u._id }),
                    });
                    const data = await res.json();
                    if (data.success) {
                      alert(`Friend request sent to ${u.username}`);
                      fetchFriends(); // refresh friends list
                    }
                  } catch (err) {
                    console.error(err);
                  }
                }}
              >
                Add Friend
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export { Friends };
