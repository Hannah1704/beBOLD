import React, { useEffect, useState } from "react";

function UserActivity({ user }) {
  const [activities, setActivities] = useState([]);
  const [projects, setProjects] = useState([]);
  const [allUsers, setAllUsers] = useState([]);

  useEffect(() => {
    async function fetchUsers() {
      try {
        const res = await fetch("/api/users");
        const data = await res.json();
        if (data.success) setAllUsers(data.users);
      } catch (err) {
        console.error(err);
      }
    }

    fetchUsers();
  }, []);

  useEffect(() => {
    async function fetchUserActivity() {
      try {
        const res = await fetch(`/api/users/${user._id}/activity`);
        const data = await res.json();
        if (data.success) {
          setActivities(data.activities);
          setProjects(data.projects);
        }
      } catch (err) {
        console.error(err);
      }
    }
    if (user?._id) fetchUserActivity();
  }, [user]);

  const getUsername = (id) => {
    const u = allUsers.find((usr) => usr._id === id.toString());
    return u ? u.username : "Unknown";
  };

  return (
    <div className="activity-card">
      <h2 className="section-title">{user.username}'s Activity</h2>
      {activities.length === 0 ? (
        <p>No activity yet</p>
      ) : (
        <ul className="activity-list">
          {activities.map((act, idx) => (
            <li key={idx} className="activity-item">
              <strong>Project:</strong> {act.projectName} <br />
              <strong>Action:</strong> {act.action} <br />
              <strong>Message:</strong> {act.message} <br />
              <strong>Time:</strong> {new Date(act.timestamp).toLocaleString()}
            </li>
          ))}
        </ul>
      )}

      <h2 className="section-title">Projects Involved</h2>
      {projects.length === 0 ? (
        <p>No projects yet</p>
      ) : (
        <ul className="activity-list">
          {projects.map((proj) => (
            <li key={proj._id} className="activity-item">
              <strong>{proj.name}</strong> <br />
              <strong>Owner:</strong> {getUsername(proj.owner)} <br />
              <strong>Members:</strong>{" "}
              {(proj.members || []).map((m) => getUsername(m)).join(", ")} <br />
              <strong>Date:</strong> {new Date(proj.date).toLocaleDateString()} <br />
              <strong>Popularity:</strong> {proj.popularity} | <strong>Downloads:</strong> {proj.downloads}
            </li>
          ))}
        </ul>
      )}
    </div>

  );
}

export { UserActivity };
