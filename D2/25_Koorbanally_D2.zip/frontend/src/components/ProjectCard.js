import React, { useState } from "react";
import { Link } from "react-router-dom";

function ProjectCard({ project, onHashtagClick }) {
  const projectDate = project.date?.$date?.$numberLong || project.date;
  const formattedDate = new Date(parseInt(projectDate)).toLocaleDateString();

  const [imgError, setImgError] = useState(false);

  return (
    <div className="border border-purple-300 rounded-xl p-6 mb-6 shadow-md hover:shadow-lg transition-shadow bg-white">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-purple-700">{project.name}</h2>
        <span
          className={`px-2 py-1 rounded text-white ${
            project.status === "Checked In" ? "bg-green-500" : "bg-yellow-500"
          }`}
        >
          {project.status}
        </span>
      </div>

      {/* Image */}
      {project.image && !imgError && (
        <div className="mb-4">
          <img
            src={project.image} 
            alt="project"
            className="w-32 h-32 object-cover rounded-md border border-gray-200"
            onError={() => setImgError(true)} 
          />
        </div>
      )}
      {imgError && (
        <div className="mb-4 w-32 h-32 bg-gray-200 flex items-center justify-center rounded-md text-gray-500">
          Image not found
        </div>
      )}

      {/* Basic Info */}
      <div className="mb-4 space-y-1 text-gray-700">
        <p>
          <span className="font-semibold">Type:</span> {project.type}
        </p>
        <p>
          <span className="font-semibold">Version:</span> {project.version}
        </p>
        <p>
          <span className="font-semibold">Popularity:</span> {project.popularity} |{" "}
          <span className="font-semibold">Downloads:</span> {project.downloads}
        </p>
      </div>

      {/* Hashtags */}
      {project.hashtags?.length > 0 && (
        <div className="mb-4">
          <span className="font-semibold text-gray-700">Hashtags: </span>
          {project.hashtags.map((tag, i) => (
            <span
              key={i}
              onClick={() => onHashtagClick(tag)}
              className="text-blue-500 cursor-pointer mr-2 hover:underline"
            >
              #{tag}
            </span>
          ))}
        </div>
      )}

      {/* Files */}
      {project.files?.length > 0 && (
        <div className="mb-4">
          <span className="font-semibold text-gray-700">Files:</span>
          <ul className="list-disc list-inside text-gray-700">
            {project.files.map((f, idx) => (
              <li key={idx}>{f.name}</li>
            ))}
          </ul>
        </div>
      )}


      {/* View Project Details */}
      <div className="mt-4">
        <Link
          to={`/projects/${project._id}`}
          className="block text-center bg-purple-700 text-white font-bold px-4 py-2 rounded-md hover:bg-purple-600 transition-colors"
        >
          View Project Details
        </Link>
      </div>
    </div>
  );
}

export { ProjectCard };
