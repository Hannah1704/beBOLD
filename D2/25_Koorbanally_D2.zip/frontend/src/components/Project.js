import React from "react";

function Project({ project }) {
  return (
    <li className="project-card">
      <strong className="project-name">{project.name}</strong> <br />
      <em className="project-type">{project.type}</em> – v{project.version} <br />
      <span className="project-status">Status: {project.status}</span> <br />
      <span className="project-hashtags">Hashtags: {(project.hashtags || []).join(", ")}</span> <br />
      <span className="project-popularity">Popularity: {project.popularity} | Downloads: {project.downloads}</span> <br />
      <span className="project-members">Members: {(project.memberNames || []).join(", ")}</span>
    </li>


  );
}

export { Project };
