import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function LoginForm({ onSwitchToRegister, setCurrentUser }) {
  const [form, setForm] = useState({ identifier: "", password: "" });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validate = () => {
    let newErrors = {};
    if (!form.identifier) newErrors.identifier = "Email or Username is required";
    if (form.password.length < 6)
      newErrors.password = "Password must be at least 6 characters";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await response.json();

      if (data.success) {
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));
        setCurrentUser(data.user);
        navigate("/home");
      } else {
        setErrors({ form: data.message || "Login failed" });
      }
    } catch (err) {
      setErrors({ form: "Server error" });
    }
  };

 return (
  <main className="bg-layer p-8 rounded-xl shadow-lg">
    <h1 className="text-3xl font-extrabold mb-6 text-accent1">Login</h1>

    {errors.form && <p className="text-red-500 mb-4">{errors.form}</p>}

    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block font-semibold mb-1">
          Email/Username:
        </label>
        <input
          type="text"
          name="identifier"
          value={form.identifier}
          onChange={handleChange}
          required
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
        {errors.identifier && <p className="text-red-500 mt-1">{errors.identifier}</p>}
      </div>

      <div>
        <label className="block font-semibold mb-1">
          Password:
        </label>
        <input
          type="password"
          name="password"
          value={form.password}
          onChange={handleChange}
          required
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
        {errors.password && <p className="text-red-500 mt-1">{errors.password}</p>}
      </div>

      <button
        type="submit"
        className="w-full bg-accent1 text-white font-bold py-3 rounded-lg hover:bg-accent2 transition-colors"
      >
        Login
      </button>
    </form>

    <p className="mt-4 text-center">
      New to BOLD?{" "}
      <button
        type="button"
        onClick={onSwitchToRegister}
        className="text-accent3 font-semibold hover:underline"
      >
        Register
      </button>
    </p>
  </main>
);

}

export { LoginForm };
