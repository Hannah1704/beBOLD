import React from "react";

export function ViewerAbilities({ project }) {
  
  return (
    <div className="bg-gray-800 border border-gray-600 p-6 rounded-lg mt-6">
      <h3 className="text-accent2 font-bold text-xl mb-3 font-montserrat">Viewer Access</h3>
      <p className="text-gray-300 font-montserrat">
        As a viewer, you can see all project details, activity history, and download files. 
        To participate in discussions or check out files, you need to be added as a project member.
      </p>
    </div>
  );
}