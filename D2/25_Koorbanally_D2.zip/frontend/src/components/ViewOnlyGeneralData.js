import React, { useEffect, useState } from "react";

function ViewOnlyGeneralData({ userId, currentUserId, onFriendChange }) {
  const [user, setUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    async function fetchUser() {
      try {
        const res = await fetch(`/api/users/${userId}`);
        const data = await res.json();
        if (data.success) setUser(data.user);
      } catch (err) {
        console.error(err);
      }
    }

    async function fetchCurrentUser() {
      try {
        const res = await fetch(`/api/users/${currentUserId}`);
        const data = await res.json();
        if (data.success) setCurrentUser(data.user);
      } catch (err) {
        console.error(err);
      }
    }

    if (userId) fetchUser();
    if (currentUserId) fetchCurrentUser();
  }, [userId, currentUserId]);

  if (!user) return <p>User not found</p>;

  const isFriend = currentUser?.friends?.some((f) => f === userId);

  const handleAddFriend = async () => {
    try {
      const res = await fetch(`/api/users/${currentUserId}/friends`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ friendId: userId }),
      });
      const data = await res.json();
      if (data.success) {
        alert(`Friend request sent to ${user.username}`);
        onFriendChange?.(); 
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUnfriend = async () => {
    try {
      const res = await fetch(`/api/users/${currentUserId}/friends/${userId}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) {
        alert(`You are no longer friends with ${user.username}`);
        onFriendChange?.(); 
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <img
        src={user.image || "/assets/images/default.png"}
        alt={user.username}
        style={{ width: 100, height: 100, borderRadius: "50%", marginBottom: 10 }}
      />

      <p><strong>Username / Email:</strong> {user.username}</p>
      <p><strong>Pronouns:</strong> {user.pronouns}</p>
      <p><strong>Birthday:</strong> {user.birthday}</p>
      <p><strong>Work:</strong> {user.work}</p>
      <p><strong>Contact:</strong> {user.contact}</p>

      {userId === currentUserId ? (
        <p>This is you</p>
      ) : isFriend ? (
        <>
          <p style={{ color: "pink" }}>You are friends</p>
          <button onClick={handleUnfriend}>Unfriend</button>
        </>
      ) : (
        <button onClick={handleAddFriend}>Add Friend</button>
      )}
    </div>
  );
}

export { ViewOnlyGeneralData };
