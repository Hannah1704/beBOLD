import React, { useState } from "react";

export function MemberAbilities({ project, currentUser, currentUserId, fetchProject }) {
  const [selectedFriend, setSelectedFriend] = useState("");
  const [newMessage, setNewMessage] = useState("");

  const getIdString = (obj) => {
    if (!obj) return null;
    if (typeof obj === "string") return obj;
    if (obj.$oid) return obj.$oid;
    if (obj._id?.$oid) return obj._id.$oid;
    if (obj._id) return obj._id.toString();
    return obj.toString();
  };

  const handleAddMember = async () => {
    if (!selectedFriend) return;
    try {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/add-member`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ memberId: selectedFriend })
      });
      const data = await res.json();
      if (data.success) {
        alert("Member added successfully!");
        setSelectedFriend("");
        await fetchProject();
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
      alert("Error adding member");
    }
  };

  const handlePostMessage = async () => {
    if (!newMessage.trim()) return;
    try {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/discussion`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: currentUserId, text: newMessage })
      });
      const data = await res.json();
      if (data.success) {
        setNewMessage("");
        await fetchProject();
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
      alert("Error posting discussion message");
    }
  };

  const memberIdsStr = (project.memberIds || []).map(getIdString).filter(Boolean);
  const friendsNotInProject = (currentUser.friends || []).filter(f => {
    const fid = getIdString(f);
    return !memberIdsStr.includes(fid);
  });

  return (
    <div className="bg-gray-800 border border-blue-500 p-6 rounded-lg mt-6">
      <h3 className="text-accent2 font-bold text-2xl mb-4 font-montserrat">Member Controls</h3>

      {/* Add Member Section */}
      <div className="mb-6">
        <h4 className="text-accent1 font-bold text-lg mb-2 font-montserrat">Add Member (from friends)</h4>
        {friendsNotInProject.length === 0 ? (
          <p className="text-gray-400 font-montserrat">No friends available to add.</p>
        ) : (
          <div className="flex gap-2 items-center">
            <select 
              value={selectedFriend} 
              onChange={e => setSelectedFriend(e.target.value)}
              className="px-3 py-2 rounded-md border border-gray-400 bg-white text-black font-montserrat"
            >
              <option value="">Select friend</option>
              {friendsNotInProject.map(f => {
                const fid = getIdString(f);
                const username = f.username || fid;
                return <option key={fid} value={fid}>{username}</option>;
              })}
            </select>
            <button 
              onClick={handleAddMember}
              className="bg-accent1 text-white px-4 py-2 rounded-md hover:bg-accent2 font-montserrat"
            >
              Add Member
            </button>
          </div>
        )}
      </div>

      {/* Discussion Section */}
      <div className="mb-6">
        <h4 className="text-accent1 font-bold text-lg mb-2 font-montserrat">Post to Discussion</h4>
        <textarea
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          placeholder="Write a message..."
          rows={3}
          className="w-full px-3 py-2 rounded-md border border-gray-400 bg-white text-black font-montserrat mb-2"
        />
        <button 
          onClick={handlePostMessage}
          className="bg-accent1 text-white px-4 py-2 rounded-md hover:bg-accent2 font-montserrat"
        >
          Post Message
        </button>
      </div>

      <p className="text-gray-300 text-sm font-montserrat mt-4">
        Note: File check-out/check-in controls are shown above in the Files section.
      </p>
    </div>
  );
}