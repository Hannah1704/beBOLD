import React, { useState, useEffect } from "react";

const projectTypes = [
  "Desktop Application",
  "Web Application",
  "Mobile Application",
  "Framework",
  "Library",
  "Other",
];

function CreateProjectForm({ currentUserId, onCreateProject }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState(projectTypes[0]);
  const [hashtags, setHashtags] = useState([]);
  const [newHashtag, setNewHashtag] = useState("");
  const [version, setVersion] = useState("1.0.0");
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [files, setFiles] = useState([]);
  const [errors, setErrors] = useState({});
  const [allUsers, setAllUsers] = useState([]);
  const [selectedMembers, setSelectedMembers] = useState([currentUserId]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await fetch("/api/users");
        const data = await res.json();
        setAllUsers(data.users || []);
      } catch (err) {
        console.error("Error fetching users:", err);
      }
    };
    fetchUsers();
  }, []);

  const addHashtag = () => {
    const tag = newHashtag.trim();
    if (tag && !hashtags.includes(tag)) {
      setHashtags([...hashtags, tag]);
      setNewHashtag("");
    }
  };

  const removeHashtag = (tag) => {
    setHashtags(hashtags.filter((h) => h !== tag));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file && file.size <= 5 * 1024 * 1024) {
      setImage(file);
      setImagePreview(URL.createObjectURL(file));
    } else {
      alert("Max image size 5MB.");
    }
  };

  const handleFilesChange = (e) => {
    const uploadedFiles = Array.from(e.target.files);
    const newFiles = uploadedFiles.map((f) => ({
      name: f.name,
      path: `/assets/images/${f.name}`,
    }));
    setFiles([...files, ...newFiles]);
  };

  const validateForm = () => {
    const newErrors = {};
    if (!name.trim() || name.trim().length < 3)
      newErrors.name = "Project name must be at least 3 characters.";
    const versionRegex = /^\d+\.\d+\.\d+$/;
    if (!versionRegex.test(version)) newErrors.version = "Version must be X.Y.Z";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleMemberChange = (userId) => {
    if (selectedMembers.includes(userId)) {
      setSelectedMembers(selectedMembers.filter((id) => id !== userId));
    } else {
      setSelectedMembers([...selectedMembers, userId]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    const newProject = {
      name,
      description,
      owner: currentUserId,
      members: selectedMembers,
      date: new Date(),
      popularity: 0,
      downloads: 0,
      hashtags,
      type,
      version,
      status: "Checked In",
      files,
      activity: [
        { userId: currentUserId, action: "checked in", message: "Initial commit", timestamp: new Date() },
      ],
      discussion: [],
      image: imagePreview || "",
    };

    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newProject),
      });
      const data = await res.json();
      if (data.success) {
        onCreateProject({ ...newProject, _id: data.projectId });
        setName("");
        setDescription("");
        setType(projectTypes[0]);
        setHashtags([]);
        setNewHashtag("");
        setVersion("1.0.0");
        setFiles([]);
        setImage(null);
        setImagePreview(null);
        setErrors({});
        setSelectedMembers([currentUserId]);
      } else {
        alert("Error creating project: " + data.message);
      }
    } catch (err) {
      console.error(err);
      alert("Server error creating project");
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-[#6F2AA0] p-6 rounded-xl mb-6 max-w-2xl mx-auto"
    >
      <h2 className="text-[#F50DC6] text-2xl font-bold mb-4">Create New Project</h2>

      {/* Project Name */}
      <div className="mb-4">
        <label className="block mb-1 font-medium text-white">Project Name:</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full bg-white text-black rounded-md px-4 py-2 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#F50DC6]"
        />
        {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
      </div>

      {/* Description */}
      <div className="mb-4">
        <label className="block mb-1 font-medium text-white">Description:</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full bg-white text-black rounded-md px-4 py-2 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#F50DC6] min-h-[100px] resize-none"
        />
      </div>

      {/* Type */}
      <div className="mb-4">
        <label className="block mb-1 font-medium text-white">Type:</label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="w-full bg-white text-black rounded-md px-4 py-2 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#F50DC6]"
        >
          {projectTypes.map((t, i) => (
            <option key={i} value={t}>{t}</option>
          ))}
        </select>
      </div>

      {/* Version */}
      <div className="mb-4">
        <label className="block mb-1 font-medium text-white">Version:</label>
        <input
          value={version}
          onChange={(e) => setVersion(e.target.value)}
          className="w-full bg-white text-black rounded-md px-4 py-2 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#F50DC6]"
        />
        {errors.version && <p className="text-red-500 text-sm mt-1">{errors.version}</p>}
      </div>

      {/* Hashtags */}
      <div className="mb-4">
        <label className="block mb-1 font-medium text-white">Hashtags:</label>
        <div className="flex flex-wrap gap-2 mb-2">
          {hashtags.map((tag) => (
            <span
              key={tag}
              onClick={() => removeHashtag(tag)}
              className="bg-[#F50DC6] text-white px-2 py-1 rounded cursor-pointer hover:bg-[#5EE7C8] transition-colors"
            >
              #{tag} ×
            </span>
          ))}
        </div>
        <div className="flex gap-2 mt-1">
          <input
            value={newHashtag}
            onChange={(e) => setNewHashtag(e.target.value)}
            placeholder="Add hashtag"
            className="w-full bg-white text-black rounded-md px-4 py-2 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#F50DC6]"
          />
          <button
            type="button"
            onClick={addHashtag}
            className="bg-[#F50DC6] text-white px-4 py-2 rounded-md hover:bg-[#5EE7C8] transition-colors"
          >
            Add
          </button>
        </div>
      </div>

      {/* Members */}
      <div className="mb-4">
        <label className="block mb-1 font-medium text-white">Members:</label>
        <div className="max-h-40 overflow-y-auto border border-gray-600 p-2 rounded-md bg-white text-black">
          {allUsers.map((user) => (
            <div key={user._id} className="mb-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedMembers.includes(user._id)}
                  onChange={() => handleMemberChange(user._id)}
                  disabled={user._id === currentUserId}
                  className="cursor-pointer"
                />
                {user.username} ({user.email})
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Files */}
      <div className="mb-4">
        <label className="block font-medium text-white">Files:</label>
        <input
          type="file"
          multiple
          onChange={handleFilesChange}
          className="w-full bg-white text-black rounded-md px-4 py-2 mt-1 cursor-pointer"
        />
        {files.length > 0 && (
          <ul className="text-gray-300 text-sm mt-1 list-disc list-inside">
            {files.map((f, idx) => (
              <li key={idx}>{f.name}</li>
            ))}
          </ul>
        )}
      </div>

      {/* Image */}
      <div className="mb-4">
        <label className="block font-medium text-white">Image:</label>
        <input
          type="file"
          accept="image/*"
          onChange={handleImageChange}
          className="w-full bg-white text-black rounded-md px-4 py-2 mt-1 cursor-pointer"
        />
        {imagePreview && (
          <img src={imagePreview} alt="preview" className="w-24 h-24 object-cover rounded-md mt-2" />
        )}
      </div>

      {/* Submit */}
      <button
        type="submit"
        className="bg-[#F50DC6] text-white px-4 py-2 rounded-md mt-4 hover:bg-[#5EE7C8] transition-colors"
      >
        Create Project
      </button>
    </form>
  );
}

export { CreateProjectForm };
