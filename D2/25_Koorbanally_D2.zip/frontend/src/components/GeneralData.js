import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function GeneralData({ user, setUser }) {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    username: user.username,
    password: user.password,
    pronouns: user.pronouns,
    birthday: user.birthday,
    work: user.work,
    contact: user.contact,
    image: user.image || "/assets/images/default.png",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    try {
      const res = await fetch(`/api/users/${user._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.success) {
        setUser(data.user);
        setIsEditing(false);
      } else {
        console.error(data.message);
      }
    } catch (err) {
      console.error("Error updating user:", err);
    }
  };

  const handleDelete = async () => {
    const confirmed = window.confirm(
      "Are you sure you want to delete your account? This action cannot be undone."
    );
    
    if (!confirmed) return;

    try {
      const res = await fetch(`/api/users/${user._id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      
      if (data.success) {
        alert("Account deleted successfully");
        localStorage.removeItem("user");
        localStorage.removeItem("userId");
        localStorage.removeItem("username");
        navigate("/");
      } else {
        alert("Error deleting account: " + data.message);
      }
    } catch (err) {
      console.error("Error deleting user:", err);
      alert("Error deleting account");
    }
  };

  return (
    <div className="general-data-card">
      <img className="profile-img" src={formData.image} alt="Profile" />

      <label>Username / Email:</label>
      {isEditing ? (
        <input className="profile-input" name="username" value={formData.username} onChange={handleChange} />
      ) : (
        <p className="profile-text">{formData.username}</p>
      )}

      <label>Password:</label>
      {isEditing ? (
        <input className="profile-input" type="password" name="password" value={formData.password} onChange={handleChange} />
      ) : (
        <p className="profile-text">{"*".repeat(formData.password.length)}</p>
      )}

      <label>Pronouns:</label>
      {isEditing ? (
        <input className="profile-input" name="pronouns" value={formData.pronouns} onChange={handleChange} />
      ) : (
        <p className="profile-text">{formData.pronouns}</p>
      )}

      <label>Birthday:</label>
      {isEditing ? (
        <input className="profile-input" type="date" name="birthday" value={formData.birthday} onChange={handleChange} />
      ) : (
        <p className="profile-text">{formData.birthday}</p>
      )}

      <label>Work:</label>
      {isEditing ? (
        <input className="profile-input" name="work" value={formData.work} onChange={handleChange} />
      ) : (
        <p className="profile-text">{formData.work}</p>
      )}

      <label>Contact:</label>
      {isEditing ? (
        <input className="profile-input" name="contact" value={formData.contact} onChange={handleChange} />
      ) : (
        <p className="profile-text">{formData.contact}</p>
      )}

      <div className="profile-buttons">
        <button className="profile-button" onClick={isEditing ? handleSave : () => setIsEditing(true)}>
          {isEditing ? "Save" : "Edit"}
        </button>
        <button className="profile-button delete-button" onClick={handleDelete}>
          Delete Account
        </button>
      </div>
    </div>
  );
}

export { GeneralData };