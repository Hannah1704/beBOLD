import React from "react";
import { Project } from "./Project";

function LocalFeed({ projects }) {
  return (
    <ul>
      {projects.map((proj) => (
        <Project key={proj._id} project={proj} />
      ))}
    </ul>
  );
}

export { LocalFeed };
