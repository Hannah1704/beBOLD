import React from "react";
import { Project } from "./Project";

function GlobalFeed({ projects }) {
  return (
    <ul>
      {projects.map((proj) => (
        <Project key={proj._id} project={proj} />
      ))}
    </ul>
  );
}

export { GlobalFeed };
