import React, { useState, useEffect } from "react";

const projectTypes = ["Desktop Application", "Web Application", "Mobile Application", "Framework", "Library", "Other"];

export function OwnerAbilities({
  project,
  setProject,
  handleRemoveMember,
  handleTransferOwnership,
  handleDeleteProject,
  currentUser,
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: project.name,
    description: project.description,
    image: project.image || "/assets/images/default_project.jpg",
    type: project.type,
  });

  const [selectedMemberToRemove, setSelectedMemberToRemove] = useState("");
  const [selectedNewOwner, setSelectedNewOwner] = useState("");
  const [selectedFriendsToAdd, setSelectedFriendsToAdd] = useState([]);
  const [friends, setFriends] = useState([]);
  const [newMessage, setNewMessage] = useState("");

  const getIdString = (obj) => {
    if (!obj) return null;
    if (typeof obj === "string") return obj;
    if (obj.$oid) return obj.$oid;
    if (obj._id?.$oid) return obj._id.$oid;
    if (obj._id) return obj._id.toString();
    return obj.toString();
  };

    const fetchProject = async () => {
    try {
      const res = await fetch(`/api/projects/${getIdString(project._id)}`);
      const data = await res.json();
      if (data.success) {
        setProject(data.project);
      }
    } catch (err) {
      console.error("Error fetching project:", err);
    }
  };


  const ownerId = getIdString(project.owner);
  const currentUserId = getIdString(currentUser?._id || currentUser?.id);

  const removableMembers = (project.memberIds || [])
    .map(getIdString)
    .filter(mid => mid !== ownerId);

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSave = async () => {
    try {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/details`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.success) {
        await fetchProject();
        setIsEditing(false);
        alert("Project updated successfully!");
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
      alert("Error updating project");
    }
  };

  const getMemberName = (mid) => {
    const memberIdsStr = (project.memberIds || []).map(getIdString);
    const idx = memberIdsStr.indexOf(mid);
    return project.memberNames?.[idx] || "Unknown";
  };

  useEffect(() => {
    async function fetchFriends() {
      const userId = getIdString(currentUser?._id || currentUser?.id);
      if (!userId) return;

      try {
        const res = await fetch(`/api/users/${userId}/friends`);
        const data = await res.json();
        if (data.success) {
          const existingMemberIds = (project.memberIds || []).map(getIdString);
          const availableFriends = data.friends.filter(f => {
            const fid = getIdString(f._id);
            return !existingMemberIds.includes(fid);
          });
          setFriends(availableFriends);
        }
      } catch (err) {
        console.error("Error fetching friends:", err);
      }
    }

    fetchFriends();
  }, [currentUser, project]);

  const handleAddFriends = async () => {
    if (selectedFriendsToAdd.length === 0) return;
    try {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/add-members`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ memberIds: selectedFriendsToAdd }),
      });
      const data = await res.json();
      if (data.success) {
        alert("Friends added successfully!");
        setSelectedFriendsToAdd([]);
        await fetchProject();
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
      alert("Error adding friends");
    }
  };

  const handlePostMessage = async () => {
    if (!newMessage.trim()) return;
    try {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/discussion`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: currentUserId, text: newMessage })
      });
      const data = await res.json();
      if (data.success) {
        setNewMessage("");
        await fetchProject();
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
      alert("Error posting discussion message");
    }
  };

  return (
    <div className="bg-gray-800 border border-green-500 p-6 rounded-lg mt-6">
      <h3 className="text-accent2 font-bold text-2xl mb-4 font-montserrat">Owner Controls</h3>

      {/* Edit Project */}
      <div className="border border-gray-600 p-4 rounded-md mb-6">
        <h4 className="text-accent1 font-bold text-lg mb-3 font-montserrat">Edit Project Details</h4>
        <img src={formData.image} alt="Project" className="w-40 h-40 object-cover rounded-md mb-2" />
        {isEditing ? (
          <>
            <div className="mb-2">
              <label className="block text-white mb-1 font-montserrat">Name:</label>
              <input name="name" value={formData.name} onChange={handleChange} className="w-full px-3 py-2 rounded text-black font-montserrat" />
            </div>
            <div className="mb-2">
              <label className="block text-white mb-1 font-montserrat">Description:</label>
              <textarea name="description" value={formData.description} onChange={handleChange} rows={3} className="w-full px-3 py-2 rounded text-black font-montserrat" />
            </div>
            <div className="mb-2">
              <label className="block text-white mb-1 font-montserrat">Image URL:</label>
              <input name="image" value={formData.image} onChange={handleChange} className="w-full px-3 py-2 rounded text-black font-montserrat" />
            </div>
            <div className="mb-2">
              <label className="block text-white mb-1 font-montserrat">Type:</label>
              <select name="type" value={formData.type} onChange={handleChange} className="w-full px-3 py-2 rounded text-black font-montserrat">
                {projectTypes.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <button onClick={handleSave} className="bg-accent1 text-white px-4 py-2 rounded mr-2 hover:bg-accent2 font-montserrat">Save</button>
            <button onClick={() => setIsEditing(false)} className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 font-montserrat">Cancel</button>
          </>
        ) : (
          <button onClick={() => setIsEditing(true)} className="bg-accent1 text-white px-4 py-2 rounded hover:bg-accent2 font-montserrat">Edit Project</button>
        )}
      </div>

      {/* Add Friends as Members */}
      <div className="border border-gray-600 p-4 rounded-md mb-6">
        <h4 className="text-accent1 font-bold text-lg mb-3 font-montserrat">Add Friends to Project</h4>
        {friends.length === 0 ? (
          <p className="text-gray-400 font-montserrat">No friends available to add.</p>
        ) : (
          <>
            {friends.map(friend => {
              const fId = getIdString(friend._id);
              return (
                <label key={fId} className="flex items-center text-white mb-2 cursor-pointer font-montserrat">
                  <input
                    type="checkbox"
                    value={fId}
                    checked={selectedFriendsToAdd.includes(fId)}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setSelectedFriendsToAdd(prev =>
                        checked ? [...prev, fId] : prev.filter(id => id !== fId)
                      );
                    }}
                    className="mr-2"
                  />
                  {friend.username}
                </label>
              );
            })}
            <button 
              onClick={handleAddFriends} 
              disabled={selectedFriendsToAdd.length === 0} 
              className="bg-blue-500 text-white px-4 py-2 rounded mt-2 hover:bg-blue-600 disabled:bg-gray-500 disabled:cursor-not-allowed font-montserrat"
            >
              Add Selected Friends ({selectedFriendsToAdd.length})
            </button>
          </>
        )}
      </div>

      {/* Discussion Section */}
      <div className="border border-gray-600 p-4 rounded-md mb-6">
        <h4 className="text-accent1 font-bold text-lg mb-2 font-montserrat">Post to Discussion</h4>
        <textarea
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          placeholder="Write a message..."
          rows={3}
          className="w-full px-3 py-2 rounded-md border border-gray-400 bg-white text-black font-montserrat mb-2"
        />
        <button 
          onClick={handlePostMessage}
          className="bg-accent1 text-white px-4 py-2 rounded-md hover:bg-accent2 font-montserrat"
        >
          Post Message
        </button>
      </div>

      {/* Remove Member */}
      <div className="border border-gray-600 p-4 rounded-md mb-6">
        <h4 className="text-accent1 font-bold text-lg mb-3 font-montserrat">Remove Member</h4>
        {removableMembers.length === 0 ? (
          <p className="text-gray-400 font-montserrat">No other members to remove.</p>
        ) : (
          <form onSubmit={e => {
            e.preventDefault();
            if(selectedMemberToRemove && window.confirm(`Remove ${getMemberName(selectedMemberToRemove)}?`)) {
              handleRemoveMember(selectedMemberToRemove);
              setSelectedMemberToRemove("");
            }
          }}>
            {removableMembers.map(mid => (
              <label key={mid} className="flex items-center text-white mb-2 cursor-pointer font-montserrat">
                <input type="radio" name="memberToRemove" value={mid} checked={selectedMemberToRemove===mid} onChange={e => setSelectedMemberToRemove(e.target.value)} className="mr-2" />
                {getMemberName(mid)}
              </label>
            ))}
            <button type="submit" disabled={!selectedMemberToRemove} className="bg-red-600 text-white px-4 py-2 rounded mt-2 hover:bg-red-700 disabled:bg-gray-500 disabled:cursor-not-allowed font-montserrat">Confirm Remove</button>
          </form>
        )}
      </div>

      {/* Transfer Ownership */}
      <div className="border border-gray-600 p-4 rounded-md mb-6">
        <h4 className="text-accent1 font-bold text-lg mb-3 font-montserrat">Transfer Ownership</h4>
        {removableMembers.length === 0 ? (
          <p className="text-gray-400 font-montserrat">No members to transfer ownership to.</p>
        ) : (
          <form onSubmit={e => {
            e.preventDefault();
            if(selectedNewOwner && window.confirm(`Transfer ownership to ${getMemberName(selectedNewOwner)}? You will lose owner privileges.`)) {
              handleTransferOwnership(selectedNewOwner);
              setSelectedNewOwner("");
            }
          }}>
            {removableMembers.map(mid => (
              <label key={mid} className="flex items-center text-white mb-2 cursor-pointer font-montserrat">
                <input type="radio" name="newOwner" value={mid} checked={selectedNewOwner===mid} onChange={e => setSelectedNewOwner(e.target.value)} className="mr-2" />
                {getMemberName(mid)}
              </label>
            ))}
            <button type="submit" disabled={!selectedNewOwner} className="bg-yellow-600 text-white px-4 py-2 rounded mt-2 hover:bg-yellow-700 disabled:bg-gray-500 disabled:cursor-not-allowed font-montserrat">Confirm Transfer</button>
          </form>
        )}
      </div>

      {/* Delete Project */}
      <div className="border border-red-600 p-4 rounded-md">
        <h4 className="text-red-500 font-bold text-lg mb-2 font-montserrat">Danger Zone</h4>
        <p className="text-gray-300 font-montserrat mb-3">Deleting this project will permanently remove all files, activity, and discussions. This action cannot be undone.</p>
        <button onClick={handleDeleteProject} className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 font-montserrat">Delete Project</button>
      </div>
    </div>
  );
}