import React, { useState, useEffect } from "react";
import { LocalFeed } from "../components/LocalFeed";
import { GlobalFeed } from "../components/GlobalFeed";
import { SearchBar } from "../components/SearchBar";
import { SortPanel } from "../components/SortPanel";

function Home() {
  const [projects, setProjects] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOptions, setSortOptions] = useState({
    order: "asc",
    criteria: { popularity: false, downloads: false },
    feeds: { local: true, global: true },
  });

  // ------------------------------
  const storedUser = JSON.parse(localStorage.getItem("user"));
  const loggedInUserId = storedUser?.id; 

  // ----------------------------------------------------
  // FETCH projects
  useEffect(() => {
    async function fetchProjects() {
      try {
        const res = await fetch("/api/projects");
        const data = await res.json();
        if (data.success) {
          setProjects(data.projects);
        }
      } catch (err) {
        console.error("Error fetching projects:", err);
      }
    }
    fetchProjects();
  }, []);

  // ----------------------------------------------------
  // FILTER 
  const filterProjects = (projects) => {
    if (!searchTerm) return projects;

    return projects.filter((proj) => {
      const projectNameMatch = proj.name.toLowerCase().includes(searchTerm.toLowerCase());

      const memberMatch = (proj.memberNames || [])
        .join(" ")
        .toLowerCase()
        .includes(searchTerm.toLowerCase());

      return projectNameMatch || memberMatch;
    });
  };

  // ----------------------------------------------------
  // SORT
  const sortProjects = (projects) => {
    let sorted = [...projects];

    if (sortOptions.criteria.popularity) {
      sorted.sort((a, b) => a.popularity - b.popularity);
    }
    if (sortOptions.criteria.downloads) {
      sorted.sort((a, b) => a.downloads - b.downloads);
    }

    if (!sortOptions.criteria.popularity && !sortOptions.criteria.downloads) {
      sorted.sort((a, b) => a.name.localeCompare(b.name));
    }

    if (sortOptions.order === "desc") {
      sorted.reverse();
    }

    return sorted;
  };

  // ----------------------------------------------------
  // SPLIT feeds 
  const localProjects = projects.filter((p) =>
    (p.memberIds || []).some((id) => id.toString() === loggedInUserId)
  );
  const globalProjects = projects.filter(
    (p) => !(p.memberIds || []).some((id) => id.toString() === loggedInUserId)
  );

  return (
  <div className="page-container">
    <h2 className="section-title">Search</h2>
    <div className="search-wrapper">
      <SearchBar onSearch={setSearchTerm} />
    </div>

    <h2 className="section-title">Sort Options</h2>
    <div className="sort-wrapper">
      <SortPanel onSortChange={setSortOptions} />
    </div>

    {sortOptions.feeds.local && (
      <div className="feed-section">
        <h2 className="feed-title">Local Feed</h2>
        <LocalFeed projects={sortProjects(filterProjects(localProjects))} />
      </div>
    )}

    {sortOptions.feeds.global && (
      <div className="feed-section">
        <h2 className="feed-title">Global Feed</h2>
        <GlobalFeed projects={sortProjects(filterProjects(globalProjects))} />
      </div>
    )}
  </div>
);

}

export default Home;
