import React, { useState } from "react";
import { LoginForm } from "../components/LoginForm";
import { RegisterForm } from "../components/RegisterForm";

function Splash({ setCurrentUser }) {
  const [showRegister, setShowRegister] = useState(false);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-bgMain">
      {/* Main Title */}
      <h1 className="text-5xl font-extrabold text-accent1 mb-12 text-center drop-shadow-lg">
        Welcome to beBold
      </h1>

      {/* Card Container */}
      <div className="w-full max-w-md">
        {showRegister ? (
          <RegisterForm
            onSwitchToLogin={() => setShowRegister(false)}
            setCurrentUser={setCurrentUser}
          />
        ) : (
          <LoginForm
            onSwitchToRegister={() => setShowRegister(true)}
            setCurrentUser={setCurrentUser}
          />
        )}
      </div>
    </div>
  );
}

export default Splash;
