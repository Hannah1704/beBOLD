import React, { useEffect, useState } from "react";
import { ProjectCard } from "../components/ProjectCard";
import { CreateProjectForm } from "../components/CreateProjectForm";

const getIdString = (obj) => {
  if (!obj) return null;
  if (typeof obj === "string") return obj;
  if (obj.$oid) return obj.$oid;
  if (obj._id?.$oid) return obj._id.$oid;
  return null;
};

function Projects({ currentUser }) {
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterTag, setFilterTag] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    async function fetchProjects() {
      try {
        const res = await fetch("/api/projects");
        const data = await res.json();
        if (data.success) {
          setProjects(data.projects);
          setFilteredProjects(data.projects);
        } else {
          alert("Failed to fetch projects");
        }
      } catch (err) {
        console.error(err);
        alert("Server error fetching projects");
      } finally {
        setLoading(false);
      }
    }
    fetchProjects();
  }, []);

  console.log(currentUser);

  const handleHashtagClick = (tag) => {
    if (filterTag === tag) {
      setFilterTag("");
      setFilteredProjects(projects);
    } else {
      setFilterTag(tag);
      setFilteredProjects(projects.filter((p) => p.hashtags?.includes(tag)));
    }
  };

  useEffect(() => {
    let filtered = [...projects];
    if (filterTag) filtered = filtered.filter((p) => p.hashtags?.includes(filterTag));
    if (searchTerm.trim()) filtered = filtered.filter((p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredProjects(filtered);
  }, [searchTerm, filterTag, projects]);

  if (loading) return <p>Loading projects...</p>;

  return (
  <div className="page-container font-montserrat">
    <header className="header-section font-montserrat">
      {currentUser ? (
        <div className="header-text font-montserrat">
          Welcome, <span className="font-bold font-montserrat">{currentUser.username}</span> ({currentUser.email})
        </div>
      ) : (
        <span className="header-text font-montserrat">Not logged in</span>
      )}
    </header>

    <div className="create-project-form-wrapper font-montserrat">
      <CreateProjectForm currentUserId={currentUser.id} onCreateProject={(newProject) => setProjects(prev => [...prev, newProject])} />
    </div>

    <h1 className="section-title font-montserrat">All Projects</h1>

    <div className="search-filter-container font-montserrat">
      <input type="text" placeholder="Search by name..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="search-input font-montserrat" />
      {filterTag && (
        <div className="filter-tag font-montserrat">
          <span>Filtering by <span className="text-accent3 font-semibold font-montserrat">#{filterTag}</span></span>
          <button className="profile-button clear-filter-button font-montserrat" onClick={() => setFilterTag("")}>Clear</button>
        </div>
      )}
    </div>

    {loading ? (
      <p className="text-white font-montserrat">Loading projects...</p>
    ) : filteredProjects.length === 0 ? (
      <p className="text-white font-montserrat">No projects found.</p>
    ) : (
      <div className="projects-grid font-montserrat">
        {filteredProjects.map((project) => (
          <ProjectCard key={getIdString(project._id)} project={project} onHashtagClick={handleHashtagClick} currentUser={currentUser.id} />
        ))}
      </div>
    )}
  </div>
);

}

export default Projects;
