import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { GeneralData } from "../components/GeneralData";
import { UserActivity } from "../components/UserActivity";
import { Friends } from "../components/Friends";

function Profile() {
  const { id } = useParams();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchUser() {
      try {
        const res = await fetch(`/api/users/${id}`);
        const data = await res.json();
        if (data.success) {
          setUser(data.user);
        } else {
          console.error(data.message);
        }
      } catch (err) {
        console.error("Error fetching user:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchUser();
  }, [id]);

  if (loading) return <p>Loading...</p>;
  if (!user) return <p>User not found</p>;

  return (
    <div className="profile-page">
      <h1 className="profile-title">Profile Page</h1>

      <section className="profile-section">
        <h2 className="section-title">My Profile Data</h2>
        <GeneralData user={user} setUser={setUser} />
      </section>

      <section className="profile-section">
        <h2 className="section-title">My Activity</h2>
        <UserActivity user={user} />
      </section>

      <section className="profile-section">
        <h2 className="section-title">My Friends</h2>
        <Friends user={user} />
      </section>
    </div>

  );
}

export default Profile;
