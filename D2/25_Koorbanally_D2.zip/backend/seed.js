// seed.js
const { MongoClient, ObjectId } = require("mongodb");

const uri = "mongodb+srv://u23587832_db_user:xfgMK9xfqhisZkVD@beboldcluster.tidjvrq.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(uri);

async function seed() {
  try {
    await client.connect();
    const db = client.db("beBold");

    // Clear existing data
    await db.collection("users").deleteMany({});
    await db.collection("projects").deleteMany({});

    // ------------------------
    // USERS
    const usersData = [
      { email: "hannah@example.com", username: "Hannah", password: "pass123", pronouns: "she/her", birthday: "1995-08-15", work: "Software Engineer", contact: "123-456-7890", image: "/assets/images/user1.jpg" },
      { email: "ryan@example.com", username: "Ryan", password: "pass456", pronouns: "he/him", birthday: "1990-02-20", work: "Product Manager", contact: "987-654-3210", image: "/assets/images/user2.jpg" },
      { email: "clay@example.com", username: "Clay", password: "pass789", pronouns: "they/them", birthday: "1992-06-10", work: "UX Designer", contact: "555-123-4567", image: "/assets/images/user3.jpg" },
      { email: "conno@example.com", username: "Conno", password: "pass321", pronouns: "he/him", birthday: "1994-04-22", work: "DevOps Engineer", contact: "444-555-6666", image: "/assets/images/user4.jpg" },
      { email: "nix@example.com", username: "Nix", password: "pass654", pronouns: "she/her", birthday: "1993-12-30", work: "Data Scientist", contact: "777-888-9999", image: "/assets/images/user5.jpg" },
      { email: "test@test.com", username: "TestUser", password: "test1234", pronouns: "they/them", birthday: "2000-01-01", work: "Student", contact: "000-000-0000", image: "/assets/images/user6.jpg" }
    ];

    const usersResult = await db.collection("users").insertMany(
      usersData.map(u => ({
        ...u,
        friends: [],
        projects: [],
        connections: [],
        createdAt: new Date()
      }))
    );

    const userIds = Object.values(usersResult.insertedIds);

    // ------------------------
    // FRIENDSHIPS
    await db.collection("users").updateOne({ _id: userIds[0] }, { $set: { friends: [userIds[1], userIds[2], userIds[3]] } });
    await db.collection("users").updateOne({ _id: userIds[1] }, { $set: { friends: [userIds[0], userIds[2]] } });
    await db.collection("users").updateOne({ _id: userIds[2] }, { $set: { friends: [userIds[0], userIds[1]] } });
    await db.collection("users").updateOne({ _id: userIds[3] }, { $set: { friends: [userIds[0], userIds[4]] } });
    await db.collection("users").updateOne({ _id: userIds[4] }, { $set: { friends: [userIds[0], userIds[3]] } });
    await db.collection("users").updateOne({ _id: userIds[5] }, { $set: { friends: [userIds[0], userIds[1]] } });

    // ------------------------
    // PROJECTS
    const projectsData = [
      {
        name: "MatchaLatte",
        owner: userIds[0],
        members: [userIds[0], userIds[1], userIds[2]],
        date: new Date(),
        popularity: 12,
        downloads: 35,
        hashtags: ["JavaScript", "React"],
        type: "Web Application",
        version: "1.0.0",
        status: "Checked In",
        files: [
          { name: "cucumber.html", path: "/assets/images/cucumber.html" },
          { name: "grape.html", path: "/assets/images/grape.html" }
        ],
        activity: [
          { userId: userIds[0], action: "checked in", message: "Initial commit", timestamp: new Date() },
          { userId: userIds[1], action: "checked in", message: "Added header component", timestamp: new Date() },
          { userId: userIds[2], action: "checked in", message: "Implemented state management", timestamp: new Date() },
          { userId: userIds[0], action: "checked in", message: "Fixed routing issues", timestamp: new Date() }
        ],
        discussion: [
          { userId: userIds[0], text: "Let's get started with the main layout." },
          { userId: userIds[1], text: "I'll work on the navigation bar." }
        ],
        image: "/assets/images/project1.jpg"
      },
      {
        name: "CoffeeBrew",
        owner: userIds[1],
        members: [userIds[1], userIds[2], userIds[4]],
        date: new Date(),
        popularity: 25,
        downloads: 50,
        hashtags: ["Python"],
        type: "Desktop Application",
        version: "1.0.0",
        status: "Checked Out",
        files: [
          { name: "cherry.html", path: "/assets/images/cherry.html" },
          { name: "honey.html", path: "/assets/images/honey.html" }
        ],
        activity: [
          { userId: userIds[1], action: "checked in", message: "Initial project setup", timestamp: new Date() },
          { userId: userIds[2], action: "checked in", message: "UI layout updated", timestamp: new Date() },
          { userId: userIds[4], action: "checked in", message: "Added database connection", timestamp: new Date() },
          { userId: userIds[1], action: "checked out", message: "Working on feature X", timestamp: new Date() }
        ],
        discussion: [
          { userId: userIds[1], text: "Database schema is ready." },
          { userId: userIds[2], text: "I'll integrate the GUI next." }
        ],
        image: "/assets/images/project2.jpg"
      },
      {
        name: "HotChoccies",
        owner: userIds[2],
        members: [userIds[0], userIds[2], userIds[3], userIds[4]],
        date: new Date(),
        popularity: 8,
        downloads: 20,
        hashtags: ["CSS", "HTML"],
        type: "Web Application",
        version: "1.0.0",
        status: "Checked In",
        files: [
          { name: "olive.html", path: "/assets/images/olive.html" },
          { name: "pineapple.html", path: "/assets/images/pineapple.html" }
        ],
        activity: [
          { userId: userIds[2], action: "checked in", message: "Initial commit", timestamp: new Date() },
          { userId: userIds[0], action: "checked in", message: "Added responsive layout", timestamp: new Date() },
          { userId: userIds[3], action: "checked in", message: "Updated color scheme", timestamp: new Date() },
          { userId: userIds[4], action: "checked in", message: "Fixed mobile navigation", timestamp: new Date() }
        ],
        discussion: [
          { userId: userIds[2], text: "Main styles done, review please." },
          { userId: userIds[0], text: "Looks good, will add media queries." }
        ],
        image: "/assets/images/project3.jpg"
      },
      {
        name: "StrawberryShortcake",
        owner: userIds[3],
        members: [userIds[3], userIds[0], userIds[4]],
        date: new Date(),
        popularity: 15,
        downloads: 40,
        hashtags: ["C#", ".NET"],
        type: "Desktop Application",
        version: "1.2.0",
        status: "Checked In",
        files: [
          { name: "blueberry.html", path: "/assets/images/blueberry.html" },
          { name: "ice.html", path: "/assets/images/ice.html" }
        ],
        activity: [
          { userId: userIds[3], action: "checked in", message: "Initial shortcake release", timestamp: new Date() },
          { userId: userIds[0], action: "checked in", message: "Added form validation", timestamp: new Date() },
          { userId: userIds[4], action: "checked in", message: "Implemented data persistence", timestamp: new Date() }
        ],
        discussion: [
          { userId: userIds[0], text: "Yum, looks delicious!" }
        ],
        image: "/assets/images/project4.jpg"
      },
      {
        name: "TiramisuDelight",
        owner: userIds[4],
        members: [userIds[4], userIds[1], userIds[5]],
        date: new Date(),
        popularity: 30,
        downloads: 60,
        hashtags: ["Java", "SpringBoot"],
        type: "Backend Service",
        version: "2.0.0",
        status: "Checked Out",
        files: [
          { name: "cucumber.html", path: "/assets/images/cucumber.html" },
          { name: "grape.html", path: "/assets/images/grape.html" }
        ],
        activity: [
          { userId: userIds[4], action: "checked in", message: "Initial backend setup", timestamp: new Date() },
          { userId: userIds[1], action: "checked in", message: "Added authentication endpoints", timestamp: new Date() },
          { userId: userIds[5], action: "checked in", message: "Implemented API documentation", timestamp: new Date() },
          { userId: userIds[4], action: "checked out", message: "Working on service endpoints", timestamp: new Date() }
        ],
        discussion: [
          { userId: userIds[1], text: "Make sure to add API docs" }
        ],
        image: "/assets/images/project5.jpg"
      },
      {
        name: "CheesecakeHeaven",
        owner: userIds[5],
        members: [userIds[5], userIds[0], userIds[2]],
        date: new Date(),
        popularity: 18,
        downloads: 45,
        hashtags: ["Node.js", "Express"],
        type: "API Service",
        version: "1.0.0",
        status: "Checked In",
        files: [
          { name: "pomegranate.html", path: "/assets/images/pomegranate.html" },
          { name: "mango.html", path: "/assets/images/mango.html" }
        ],
        activity: [
          { userId: userIds[5], action: "checked in", message: "Initial cheesecake API", timestamp: new Date() },
          { userId: userIds[0], action: "checked in", message: "Added error handling middleware", timestamp: new Date() },
          { userId: userIds[2], action: "checked in", message: "Implemented request validation", timestamp: new Date() }
        ],
        discussion: [
          { userId: userIds[2], text: "Don't forget to handle errors" }
        ],
        image: "/assets/images/project6.jpg"
      },
      {
        name: "LemonTart",
        owner: userIds[0],
        members: [userIds[0], userIds[1], userIds[3], userIds[5]],
        date: new Date(),
        popularity: 10,
        downloads: 25,
        hashtags: ["Vue.js"],
        type: "Web Application",
        version: "1.0.0",
        status: "Checked In",
        files: [
          { name: "cherry.html", path: "/assets/images/cherry.html" }
        ],
        activity: [
          { userId: userIds[0], action: "checked in", message: "Initial tart UI", timestamp: new Date() },
          { userId: userIds[1], action: "checked in", message: "Added Vue components", timestamp: new Date() },
          { userId: userIds[3], action: "checked in", message: "Implemented Vue Router", timestamp: new Date() },
          { userId: userIds[5], action: "checked in", message: "Added Vuex state management", timestamp: new Date() }
        ],
        discussion: [
          { userId: userIds[3], text: "Add routing support" }
        ],
        image: "/assets/images/project7.jpg"
      },
      {
        name: "MacaronMagic",
        owner: userIds[1],
        members: [userIds[1], userIds[2], userIds[4]],
        date: new Date(),
        popularity: 22,
        downloads: 55,
        hashtags: ["Angular"],
        type: "Frontend Application",
        version: "1.0.0",
        status: "Checked Out",
        files: [
          { name: "grape.html", path: "/assets/images/grape.html" },
          { name: "pomegranate.html", path: "/assets/images/pomegranate.html" },
          { name: "mango.html", path: "/assets/images/mango.html" }
        ],
        activity: [
          { userId: userIds[1], action: "checked in", message: "Initial Angular setup", timestamp: new Date() },
          { userId: userIds[2], action: "checked in", message: "Added RxJS operators", timestamp: new Date() },
          { userId: userIds[4], action: "checked in", message: "Implemented HTTP interceptors", timestamp: new Date() },
          { userId: userIds[1], action: "checked out", message: "Refactoring macarons", timestamp: new Date() }
        ],
        discussion: [
          { userId: userIds[2], text: "Use RxJS for streams" }
        ],
        image: "/assets/images/project8.jpg"
      }
    ];

    const projectsResult = await db.collection("projects").insertMany(projectsData);
    const projectIds = Object.values(projectsResult.insertedIds);

    // Assign projects back to owners
    await db.collection("users").updateOne({ _id: userIds[0] }, { $set: { projects: [projectIds[0], projectIds[6]] } });
    await db.collection("users").updateOne({ _id: userIds[1] }, { $set: { projects: [projectIds[1], projectIds[7]] } });
    await db.collection("users").updateOne({ _id: userIds[2] }, { $set: { projects: [projectIds[2]] } });
    await db.collection("users").updateOne({ _id: userIds[3] }, { $set: { projects: [projectIds[3]] } });
    await db.collection("users").updateOne({ _id: userIds[4] }, { $set: { projects: [projectIds[4]] } });
    await db.collection("users").updateOne({ _id: userIds[5] }, { $set: { projects: [projectIds[5]] } });

    console.log("Database seeded successfully!");
  } catch (err) {
    console.error(err);
  } finally {
    await client.close();
  }
}

seed();