const mongoose = require("mongoose");

const ProjectSchema = new mongoose.Schema({
  name: { type: String, required: true },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  date: { type: Date, default: Date.now },
  popularity: Number,
  downloads: Number,
  hashtags: [String],
  type: String,
  version: String,
  status: String,
  files: [String],
  activity: [
    {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      action: String,
      message: String,
      timestamp: Date
    }
  ],
  discussion: [
    {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      text: String
    }
  ],
  image: String,
  description: String
});

module.exports = mongoose.model("Project", ProjectSchema);
