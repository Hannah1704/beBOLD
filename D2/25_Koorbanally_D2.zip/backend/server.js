const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.static("frontend/public"));
app.use(express.json()); 

// -----------------------------------------------------------------------------
// MONGO STUFF
const { MongoClient, ObjectId } = require("mongodb");

const uri = "mongodb+srv://u23587832_db_user:xfgMK9xfqhisZkVD@beboldcluster.tidjvrq.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(uri);
let projectsCollection;

let db;

async function connectDB(){
  try 
  {
    await client.connect();
    db = client.db("beBold");              
    projectsCollection = db.collection("projects");
    console.log("Connected to MongoDB :)");
  } 
  catch(err) 
  {
    console.error("MongoDB connection error:", err);
  }
}

connectDB();

// -------------------------------------------------------------------------------------
// REGISTER
app.post("/api/auth/register", async (req, res) =>{
  try 
  {
    const { email, password, username, pronouns, birthday, work, contact } = req.body;

    const existingUser = await db.collection("users").findOne({
      $or: [{ email }, { username }]
    });

    if(existingUser) 
    {
      return res.status(400).json({ success: false, message: "User already exists" });
    }

    const result = await db.collection("users").insertOne({
      email,
      password, 
      username: username || email.split("@")[0],
      pronouns: pronouns || "",
      birthday: birthday || "",
      work: work || "",
      contact: contact || "",
      friends: [],
      image: "https://i.pinimg.com/564x/2e/79/bc/2e79bc67a9fcb56ee4cfce74e7b8e24f.jpg",
      projects: [],
      connections: [],
      createdAt: new Date(),
    });

    res.json({
      success: true,
      message: "User registered successfully",
      user: { id: result.insertedId, email, username },
      token: "fake-jwt-token-123",
    });
  } 
  catch(err) 
  {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});


// -------------------------------------------------------------------------------------
// LOGIN
app.post("/api/auth/login", async (req, res) => {
  try 
  {
    const { identifier, password } = req.body; 

    const user = await db.collection("users").findOne({
      $or: [{ email: identifier }, { username: identifier }]
    });

    if(!user || user.password !== password) 
    {
      return res.status(401).json({ success: false, message: "Invalid credentials" });
    }

    res.json({
      success: true,
      message: "Login successful",
      user: { id: user._id, email: user.email, username: user.username },
      token: "fake-jwt-token-123",
    });
  } 

  catch(err) 
  {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});


// -------------------------------------------------------------------------------------
// PROJECT CRUD 
// ------------------------------------------------------------
// return usernames from id's in member fields from project listing
// GET all projects with member names
app.get("/api/projects", async (req, res) => {
  try {
    const projects = await db.collection("projects").aggregate([
      {
        $lookup: {
          from: "users",
          localField: "members",
          foreignField: "_id",
          as: "memberDetails"
        }
      },
      {
        $project: {
          name: 1,
          type: 1,
          version: 1,
          status: 1,
          hashtags: 1,
          popularity: 1,
          downloads: 1,
          image: 1,
          owner: 1,
          files: 1,
          memberIds: "$members",
          memberNames: "$memberDetails.username"
        }
      }
    ]).toArray();

    res.json({ success: true, projects });
  } catch (err) {
    console.error("Error fetching projects:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// **************************************************************************************
// -------------------------------------------------------------------------------------
// checkin
// ADD check-in to a project
app.post("/api/projects/:id/checkins", async (req, res) =>{
  try
  {
    const projectId = req.params.id;
    const { userId, message } = req.body;

    if(!message || !userId) 
    {
      return res.status(400).json({ success: false, message: "userId and message are required" });
    }

    const checkIn = { userId, message, createdAt: new Date() };

    const result = await projectsCollection.updateOne(
      { _id: new ObjectId(projectId) },
      { $push: { checkIns: checkIn } }
    );

    if(result.matchedCount === 0) return res.status(404).json({ success: false, message: "Project not found" });

    res.json({ success: true, checkIn });
  } 
  catch (err) 
  {
    res.status(500).json({ success: false, message: err.message });
  }
});

// get ALL check-ins for a project
app.get("/api/projects/:id/checkins", async (req, res) => {
  try {
    const projectId = req.params.id;
    const project = await projectsCollection.findOne(
      { _id: new ObjectId(projectId) },
      { projection: { checkIns: 1 } }
    );

    if (!project) return res.status(404).json({ success: false, message: "Project not found" });

    res.json({ success: true, checkIns: project.checkIns || [] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});


// **************************************************************************************
// CREATE project
app.post("/api/projects", async (req, res) =>{
  try 
  {
    const newProject = req.body;
    const result = await projectsCollection.insertOne(newProject);
    res.json({ success: true, projectId: result.insertedId });
  } 
  catch(err) 
  {
    res.status(500).json({ success: false, message: err.message });
  }
});

// **************************************************************************************
// GET single project with owner and member names
app.get("/api/projects/:id", async (req, res) => {
  try {
    const projectId = new ObjectId(req.params.id);

    const project = await db.collection("projects").aggregate([
      { $match: { _id: projectId } },
      {
        $lookup: {
          from: "users",
          localField: "members",
          foreignField: "_id",
          as: "memberDetails"
        }
      },
      {
        $lookup: {
          from: "users",
          localField: "owner",
          foreignField: "_id",
          as: "ownerDetails"
        }
      },
      {
        $project: {
          name: 1,
          description: 1,
          type: 1,
          version: 1,
          status: 1,
          hashtags: 1,
          popularity: 1,
          downloads: 1,
          image: 1,
          files: 1, // files remain objects {name, path}
          activity: 1,
          discussion: 1,
          owner: 1,
          ownerId: "$owner",
          ownerName: { $arrayElemAt: ["$ownerDetails.username", 0] },
          ownerField: { $arrayElemAt: ["$ownerDetails.work", 0] },
          memberIds: "$members",
          memberNames: "$memberDetails.username",
          checkedOutFiles: 1
        }
      }

    ]).next();

    if (!project) return res.status(404).json({ success: false, message: "Project not found" });

    res.json({ success: true, project });
  } catch (err) {
    console.error("Error fetching project:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});


// **************************************************************************************
// UPDATE project
app.put("/api/projects/:id", async (req, res) =>{
  try 
  {
    const projectId = req.params.id;
    const updatedData = req.body;
    const result = await projectsCollection.updateOne(
      { _id: new ObjectId(projectId) },
      { $set: updatedData }
    );
    if (result.matchedCount === 0) return res.status(404).json({ success: false, message: "Project not found" });
    res.json({ success: true, message: "Project updated" });
  } 
  catch(err) 
  {
    res.status(500).json({ success: false, message: err.message });
  }
});

// **************************************************************************************
// DELETE project
app.delete("/api/projects/:id", async (req, res) => {
  try 
  {
    const projectId = req.params.id;
    const result = await projectsCollection.deleteOne({ _id: new ObjectId(projectId) });
    if (result.deletedCount === 0) return res.status(404).json({ success: false, message: "Project not found" });
    res.json({ success: true, message: "Project deleted" });
  } 
  catch(err) 
  {
    res.status(500).json({ success: false, message: err.message });
  }
});

// **************************************************************************************
// GET all projects with owner and member names
app.get("/api/projects", async (req, res) => {
  try {
    const projects = await db.collection("projects").aggregate([
      // Lookup members
      {
        $lookup: {
          from: "users",
          localField: "members",
          foreignField: "_id",
          as: "memberDetails"
        }
      },
      // Lookup owner
      {
        $lookup: {
          from: "users",
          localField: "owner",
          foreignField: "_id",
          as: "ownerDetails"
        }
      },
      {
        $project: {
          name: 1,
          type: 1,
          version: 1,
          status: 1,
          hashtags: 1,
          popularity: 1,
          downloads: 1,
          files: 1,
          image: 1,
          owner: 1,
          ownerName: { $arrayElemAt: ["$ownerDetails.username", 0] },
          ownerField: { $arrayElemAt: ["$ownerDetails.work", 0] },
          memberIds: "$members",
          memberNames: "$memberDetails.username"
        }
      }
    ]).toArray();

    res.json({ success: true, projects });
  } catch (err) {
    console.error("Error fetching projects:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// **************************************************************************************
// UPDATE basic project details (owner only)
app.put("/api/projects/:id/details", async (req, res) => {
  try {
    const projectId = new ObjectId(req.params.id);
    const { name, description, image, type } = req.body;

    const result = await projectsCollection.updateOne(
      { _id: projectId },
      { $set: { name, description, image, type } }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ success: false, message: "Project not found" });
    }

    res.json({ success: true, message: "Project updated" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});
// **************************************************************************************
// REMOVING A MEMBER FROM A PROJECT
// REMOVE member from project (owner only)
app.patch("/api/projects/:id/remove-member", async (req, res) => {
  try {
    const projectId = new ObjectId(req.params.id);
    const { memberId } = req.body;

    const result = await projectsCollection.updateOne(
      { _id: projectId },
      { $pull: { members: new ObjectId(memberId) } }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ success: false, message: "Project not found" });
    }

    res.json({ success: true, message: "Member removed" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});


// **************************************************************************************
// TRANSFERRING OWNERSHIP
app.patch("/api/projects/:id/transfer-ownership", async (req, res) => {
  try {
    const projectId = new ObjectId(req.params.id);
    const { newOwnerId } = req.body;

    const result = await projectsCollection.updateOne(
      { _id: projectId },
      { $set: { owner: new ObjectId(newOwnerId) } }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ success: false, message: "Project not found" });
    }

    res.json({ success: true, message: "Ownership transferred" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// **************************************************************************************
// getting usernames from ids
// POST /api/users/by-ids
app.post("/api/users/by-ids", async (req, res) => {
  try {
    const { ids } = req.body; // array of ObjectId strings
    if (!ids || !ids.length) return res.json({ success: true, users: [] });

    // Convert strings to ObjectId
    const objectIds = ids.map(id => new ObjectId(id));

    const users = await db.collection("users").find(
      { _id: { $in: objectIds } },
      { projection: { username: 1 } }
    ).toArray();

    res.json({ success: true, users });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ************************************************************************************
// adding friends to project// GET friends of a user
app.get("/api/users/:id/friends", async (req, res) => {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) return res.status(400).json({ success: false, message: "Invalid user ID" });

    const user = await db.collection("users").findOne({ _id: new ObjectId(id) });
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    const friendIds = (user.friends || []).filter(f => ObjectId.isValid(f)).map(f => new ObjectId(f));
    const friends = await db.collection("users").find({ _id: { $in: friendIds } }).toArray();

    res.json({ success: true, friends });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// PATCH add friends to a project
app.patch("/api/projects/:id/add-members", async (req, res) => {
  try {
    const projectId = req.params.id;
    const { memberIds } = req.body; // array of friend ID strings

    if (!Array.isArray(memberIds) || memberIds.length === 0) {
      return res.status(400).json({ success: false, message: "memberIds is required" });
    }

    const project = await db.collection("projects").findOne({ _id: new ObjectId(projectId) });
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });

    // filter out duplicates
    const existingIds = (project.members || []).map(id => id.toString());
    const newMembers = memberIds.filter(id => !existingIds.includes(id)).map(id => new ObjectId(id));

    if (newMembers.length === 0) {
      return res.json({ success: true, message: "No new members to add" });
    }

    await db.collection("projects").updateOne(
      { _id: new ObjectId(projectId) },
      { $push: { members: { $each: newMembers } } }
    );

    res.json({ success: true, message: "Members added successfully", addedMembers: newMembers });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});


// -----------------------------------------------------------------------------------
// app.patch("/api/projects/:id/add-member", async (req, res) => {
//   try {
//     const projectId = new ObjectId(req.params.id);
//     const { memberId } = req.body;

//     if (!memberId) return res.status(400).json({ success: false, message: "memberId is required" });

//     // Check if member is already in the project
//     const project = await projectsCollection.findOne({ _id: projectId });
//     if (!project) return res.status(404).json({ success: false, message: "Project not found" });

//     if (project.members.some((mid) => mid.toString() === memberId)) {
//       return res.status(400).json({ success: false, message: "User is already a member" });
//     }

//     // Add member
//     await projectsCollection.updateOne(
//       { _id: projectId },
//       { $push: { members: new ObjectId(memberId) } }
//     );

//     res.json({ success: true, message: "Member added" });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ success: false, message: err.message });
//   }
// });


// **************************************************************************************
// discussion
// ADD discussion message to a project
app.patch("/api/projects/:id/discussion", async (req, res) => {
  try {
    const projectId = new ObjectId(req.params.id);
    const { userId, text } = req.body;

    if (!userId || !text) {
      return res.status(400).json({ success: false, message: "userId and text are required" });
    }

    const discussionEntry = { userId: new ObjectId(userId), text, timestamp: new Date() };

    const result = await projectsCollection.updateOne(
      { _id: projectId },
      { $push: { discussion: discussionEntry } }
    );

    if (result.matchedCount === 0) return res.status(404).json({ success: false, message: "Project not found" });

    res.json({ success: true, message: "Discussion added", discussionEntry });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// -------------------------------------------------------------------------------------
// CHECK-IN AND CHECKOUT
// --- in your server file (inside same file where other /api/projects routes live) ---

// GET single project with owner and member names (updated to include checkedOutFiles)
app.get("/api/projects/:id", async (req, res) => {
  try {
    const projectId = new ObjectId(req.params.id);

    const project = await db.collection("projects").aggregate([
      { $match: { _id: projectId } },
      {
        $lookup: {
          from: "users",
          localField: "members",
          foreignField: "_id",
          as: "memberDetails"
        }
      },
      {
        $lookup: {
          from: "users",
          localField: "owner",
          foreignField: "_id",
          as: "ownerDetails"
        }
      },
      {
        $project: {
          name: 1,
          description: 1,
          type: 1,
          version: 1,
          status: 1,
          hashtags: 1,
          popularity: 1,
          downloads: 1,
          image: 1,
          files: 1,
          activity: 1,
          discussion: 1,
          owner: 1,
          ownerId: "$owner",
          ownerName: { $arrayElemAt: ["$ownerDetails.username", 0] },
          ownerField: { $arrayElemAt: ["$ownerDetails.work", 0] },
          memberIds: "$members",
          memberNames: "$memberDetails.username",
          checkedOutFiles: 1 // <-- include checked out info
        }
      }
    ]).next();

    if (!project) return res.status(404).json({ success: false, message: "Project not found" });

    res.json({ success: true, project });
  } catch (err) {
    console.error("Error fetching project:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ------------------ Check-out a file ------------------
// body: { fileName, userId }
app.post("/api/projects/:id/files/check-out", async (req, res) => {
  try {
    const projectId = new ObjectId(req.params.id);
    const { fileName, userId } = req.body;

    if (!fileName || !userId) {
      return res.status(400).json({ success: false, message: "fileName and userId required" });
    }

    const project = await projectsCollection.findOne({ _id: projectId });
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });

    // file must exist (now check object name)
    if (!Array.isArray(project.files) || !project.files.find(f => f.name === fileName)) {
      return res.status(400).json({ success: false, message: "File not found in project" });
    }

    // already checked out?
    const already = (project.checkedOutFiles || []).find(c => c.fileName === fileName);
    if (already) {
      return res.status(409).json({ success: false, message: "File already checked out", checkedOutBy: already.userId });
    }

    // push checked out entry + activity entry
    await projectsCollection.updateOne(
      { _id: projectId },
      {
        $push: {
          checkedOutFiles: { fileName, userId: new ObjectId(userId), timestamp: new Date() },
          activity: { userId: new ObjectId(userId), action: "checked out", message: fileName, timestamp: new Date() }
        }
      }
    );

    res.json({ success: true, message: "File checked out" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ------------------ Check-in a file ------------------
// body: { fileName, userId, message }
app.post("/api/projects/:id/files/check-in", async (req, res) => {
  try {
    const projectId = new ObjectId(req.params.id);
    const { fileName, userId, message } = req.body;

    if (!fileName || !userId) {
      return res.status(400).json({ success: false, message: "fileName and userId required" });
    }

    const project = await projectsCollection.findOne({ _id: projectId });
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });

    const co = (project.checkedOutFiles || []).find(c => c.fileName === fileName);
    if (!co) {
      return res.status(404).json({ success: false, message: "File is not checked out" });
    }

    // allow check-in if the same user is checking in or if requester is owner of project
    const coUserIdStr = co.userId.toString();
    const ownerIdStr = (project.owner && project.owner.toString) ? project.owner.toString() : project.owner;

    if (coUserIdStr !== userId && ownerIdStr !== userId) {
      return res.status(403).json({ success: false, message: "Only the user who checked out the file or the owner can check it in" });
    }

    // remove checkedOutFiles entry and add activity
    await projectsCollection.updateOne(
      { _id: projectId },
      {
        $pull: { checkedOutFiles: { fileName } },
        $push: { activity: { userId: new ObjectId(userId), action: "checked in", message: message || fileName, timestamp: new Date() } }
      }
    );

    res.json({ success: true, message: "File checked in" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});


// Optional: get checked-out files for a project (if you want a separate endpoint)
app.get("/api/projects/:id/checked-out", async (req, res) => {
  try {
    const projectId = new ObjectId(req.params.id);
    const project = await projectsCollection.findOne({ _id: projectId }, { projection: { checkedOutFiles: 1 } });
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });
    res.json({ success: true, checkedOutFiles: project.checkedOutFiles || [] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});





// -------------------------------------------------------------------------------------
// USER CRUD 
// **************************************************************************************
// GET activity of a specific user
// GET user activity across all projects
app.get("/api/users/:id/activity", async (req, res) => {
  try {
    const { id } = req.params;

    if (!ObjectId.isValid(id)) return res.status(400).json({ success: false, message: "Invalid user ID" });

    // Find all projects that include the user (owner or member)
    const projects = await db.collection("projects").find({
      $or: [
        { owner: new ObjectId(id) },
        { members: new ObjectId(id) }
      ]
    }).toArray();

    // Gather all activity entries where userId matches
    const userActivities = [];
    projects.forEach((proj) => {
      (proj.activity || []).forEach((act) => {
        if (act.userId.toString() === id) {
          userActivities.push({
            projectId: proj._id,
            projectName: proj.name,
            action: act.action,
            message: act.message,
            timestamp: act.timestamp
          });
        }
      });
    });

    res.json({ success: true, activities: userActivities, projects });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// **************************************************************************************
// GET all users 
app.get("/api/users", async (req, res) =>{
  try 
  {
    const users = await db.collection("users").find({}).toArray();
    res.json({ success: true, users });
  }
  catch(err) 
  {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// **************************************************************************************
// GET single user
app.get("/api/users/:id", async (req, res) =>{
  try 
  {
    const{ id } = req.params;
    const user = await db.collection("users").findOne({ _id: new ObjectId(id) });

    if(!user) 
    {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    res.json({ success: true, user });
  } 
  catch(err) 
  {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// **************************************************************************************
// UPDATE user
app.put("/api/users/:id", async (req, res) =>{
  try 
  {
    const { id } = req.params;
    const updates = req.body; 

    const result = await db.collection("users").updateOne(
      { _id: new ObjectId(id) },
      { $set: updates }
    );

    if(result.matchedCount=== 0) 
    {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    const updatedUser = await db.collection("users").findOne({ _id: new ObjectId(id) });
    res.json({ success: true, user: updatedUser });
  } 
  catch(err) 
  {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// **************************************************************************************
// UPDATE a user 
app.put("/api/users/:id", async (req, res) => {
  try 
  {
    const { id } = req.params;
    const updates = req.body; 

    const result = await db.collection("users").updateOne(
      { _id: new ObjectId(id) },
      { $set: updates }
    );

    if(result.matchedCount === 0) 
    {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    const updatedUser = await db.collection("users").findOne({ _id: new ObjectId(id) });
    res.json({ success: true, user: updatedUser });
  } 
  catch(err) 
  {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// **************************************************************************************
// DELETE user
app.delete("/api/users/:id", async (req, res) => {
  try 
  {
    const { id } = req.params;

    const result = await db.collection("users").deleteOne({ _id: new ObjectId(id) });

    if(result.deletedCount === 0) 
    {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    res.json({ success: true, message: "User deleted successfully" });
  } 
  catch(err) 
  {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});
// ---------------------------------------------------------------------------------------
// FRIENDS
// GET friends
app.get("/api/users/:id/friends", async (req, res) => {
  try {
    const { id } = req.params;

    // Ensure id is a valid ObjectId
    if (!ObjectId.isValid(id)) return res.status(400).json({ success: false, message: "Invalid user ID" });

    const user = await db.collection("users").findOne({ _id: new ObjectId(id) });
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    const friendIds = user.friends.filter(f => ObjectId.isValid(f)).map(f => new ObjectId(f));
    const friends = await db.collection("users").find({ _id: { $in: friendIds } }).toArray();

    res.json({ success: true, friends });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ADD friend
app.post("/api/users/:id/friends", async (req, res) => {
  try {
    const { id } = req.params;
    const { friendId } = req.body;

    if (!ObjectId.isValid(id) || !ObjectId.isValid(friendId)) {
      return res.status(400).json({ success: false, message: "Invalid user ID or friend ID" });
    }

    await db.collection("users").updateOne(
      { _id: new ObjectId(id) },
      { $addToSet: { friends: new ObjectId(friendId) } }
    );

    res.json({ success: true, message: "Friend added", userId: id, friendId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// REMOVE friend
app.delete("/api/users/:id/friends/:friendId", async (req, res) => {
  try {
    const { id, friendId } = req.params;

    if (!ObjectId.isValid(id) || !ObjectId.isValid(friendId)) {
      return res.status(400).json({ success: false, message: "Invalid user ID or friend ID" });
    }

    const result = await db.collection("users").updateOne(
      { _id: new ObjectId(id) },
      { $pull: { friends: new ObjectId(friendId) } }
    );

    if (result.matchedCount === 0) return res.status(404).json({ success: false, message: "User not found" });

    res.json({ success: true, message: "Friend removed" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});


// -------------------------------------------------------------------------------------
app.listen(PORT, () => {
  console.log(`beBOLD running on http://localhost:${PORT}`);
});

