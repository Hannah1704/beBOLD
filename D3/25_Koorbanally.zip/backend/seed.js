const { MongoClient, ObjectId } = require("mongodb");

const uri = "mongodb+srv://u23587832_db_user:xfgMK9xfqhisZkVD@beboldcluster.tidjvrq.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(uri);

async function seed(){
  try 
  {
    await client.connect();
    const db = client.db("beBold");

    await db.collection("users").deleteMany({});
    await db.collection("projects").deleteMany({});

    const adminUser = {
      email: "admin@bebold.com",
      username: "Admin",
      password: "admin123", 
      pronouns: "they/them",
      birthday: "1990-01-01",
      work: "System Administrator",
      contact: "admin@bebold.com",
      image: "/assets/images/admin.jpg",
      isAdmin: true,
      friends: [],
      projects: [],
      savedProjects: [],
      connections: [],
      createdAt: new Date()
    };

    const adminResult = await db.collection("users").insertOne(adminUser);
    const adminId = adminResult.insertedId;

    // -----------------------------------------------------------------------------------------------------------------------------
    const usersData = [
      { email: "hannah@example.com", username: "Hannah", password: "pass123", pronouns: "she/her", birthday: "1995-08-15", work: "Software Engineer", contact: "123-456-7890", image: "/assets/images/user1.jpg" },
      { email: "ryan@example.com", username: "Ryan", password: "pass456", pronouns: "he/him", birthday: "1990-02-20", work: "Product Manager", contact: "987-654-3210", image: "/assets/images/user2.jpg" },
      { email: "clay@example.com", username: "Clay", password: "pass789", pronouns: "they/them", birthday: "1992-06-10", work: "UX Designer", contact: "555-123-4567", image: "/assets/images/user3.jpg" },
      { email: "conno@example.com", username: "Conno", password: "pass321", pronouns: "he/him", birthday: "1994-04-22", work: "DevOps Engineer", contact: "444-555-6666", image: "/assets/images/user4.jpg" },
      { email: "nix@example.com", username: "Nix", password: "pass654", pronouns: "she/her", birthday: "1993-12-30", work: "Data Scientist", contact: "777-888-9999", image: "/assets/images/user5.jpg" },
      { email: "test@test.com", username: "Ethan", password: "test1234", pronouns: "they/them", birthday: "2000-01-01", work: "Student", contact: "000-000-0000", image: "/assets/images/user6.jpg" },
      { email: "alex@example.com", username: "Alex", password: "pass111", pronouns: "he/him", birthday: "1991-03-14", work: "Frontend Developer", contact: "111-222-3333", image: "/assets/images/user7.jpg" },
      { email: "sam@example.com", username: "Sam", password: "pass222", pronouns: "she/her", birthday: "1996-07-25", work: "Backend Developer", contact: "222-333-4444", image: "/assets/images/user8.jpg" },
      { email: "jordan@example.com", username: "Jordan", password: "pass333", pronouns: "they/them", birthday: "1989-11-08", work: "Full Stack Developer", contact: "333-444-5555", image: "/assets/images/user9.jpg" },
      { email: "taylor@example.com", username: "Taylor", password: "pass444", pronouns: "she/her", birthday: "1997-05-19", work: "Mobile Developer", contact: "444-555-6666", image: "/assets/images/user10.jpg" }
    ];

    const usersResult = await db.collection("users").insertMany(
      usersData.map(u => ({
        ...u,
        isAdmin: false,
        friends: [],
        projects: [],
        savedProjects: [],
        connections: [],
        createdAt: new Date()
      }))
    );

    const userIds = Object.values(usersResult.insertedIds);

    await db.collection("users").updateOne(
      { _id: adminId },
      { $set: { friends: userIds } }
    );

    // -----------------------------------------------------------------------------------------------------------------------------
    await db.collection("users").updateOne({ _id: userIds[0] }, { $set: { friends: [userIds[1], userIds[2], userIds[3]] } });
    await db.collection("users").updateOne({ _id: userIds[1] }, { $set: { friends: [userIds[0], userIds[2]] } });
    await db.collection("users").updateOne({ _id: userIds[2] }, { $set: { friends: [userIds[0], userIds[1]] } });
    await db.collection("users").updateOne({ _id: userIds[3] }, { $set: { friends: [userIds[0], userIds[4]] } });
    await db.collection("users").updateOne({ _id: userIds[4] }, { $set: { friends: [userIds[0], userIds[3]] } });
    await db.collection("users").updateOne({ _id: userIds[5] }, { $set: { friends: [userIds[0], userIds[1]] } });
    await db.collection("users").updateOne({ _id: userIds[6] }, { $set: { friends: [userIds[7], userIds[8]] } });
    await db.collection("users").updateOne({ _id: userIds[7] }, { $set: { friends: [userIds[6], userIds[9]] } });
    await db.collection("users").updateOne({ _id: userIds[8] }, { $set: { friends: [userIds[6], userIds[9]] } });
    await db.collection("users").updateOne({ _id: userIds[9] }, { $set: { friends: [userIds[7], userIds[8]] } });

    const daysAgo = (days) => new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const hoursAgo = (hours) => new Date(Date.now() - hours * 60 * 60 * 1000);

    // -----------------------------------------------------------------------------------------------------------------------------
    const projectsData = [
      {
        name: "MatchaLatte",
        owner: userIds[0],
        members: [userIds[0], userIds[1], userIds[2]],
        date: daysAgo(30),
        popularity: 12,
        downloads: 35,
        hashtags: ["JavaScript", "React"],
        type: "Web Application",
        version: "1.0.0",
        status: "Checked In",
        files: [
          { name: "cucumber.html", path: "/assets/images/cucumber.html" },
          { name: "grape.html", path: "/assets/images/grape.html" }
        ],
        activity: [
          { userId: userIds[0], action: "checked in", message: "Initial commit", timestamp: daysAgo(30) },
          { userId: userIds[1], action: "checked in", message: "Added header component", timestamp: daysAgo(25) },
          { userId: userIds[2], action: "checked in", message: "Implemented state management", timestamp: daysAgo(20) },
          { userId: userIds[0], action: "checked in", message: "Fixed routing issues", timestamp: daysAgo(15) }
        ],
        discussion: [
          { userId: userIds[0], text: "Let's get started with the main layout." },
          { userId: userIds[1], text: "I'll work on the navigation bar." }
        ],
        image: "/assets/images/project1.jpg"
      },
      {
        name: "CoffeeBrew",
        owner: userIds[1],
        members: [userIds[1], userIds[2], userIds[4]],
        date: daysAgo(28),
        popularity: 25,
        downloads: 50,
        hashtags: ["Python"],
        type: "Desktop Application",
        version: "1.0.0",
        status: "Checked Out",
        files: [
          { name: "cherry.html", path: "/assets/images/cherry.html" },
          { name: "honey.html", path: "/assets/images/honey.html" }
        ],
        activity: [
          { userId: userIds[1], action: "checked in", message: "Initial project setup", timestamp: daysAgo(28) },
          { userId: userIds[2], action: "checked in", message: "UI layout updated", timestamp: daysAgo(22) },
          { userId: userIds[4], action: "checked in", message: "Added database connection", timestamp: daysAgo(18) },
          { userId: userIds[1], action: "checked out", message: "Working on feature X", timestamp: hoursAgo(5) }
        ],
        discussion: [
          { userId: userIds[1], text: "Database schema is ready." },
          { userId: userIds[2], text: "I'll integrate the GUI next." }
        ],
        image: "/assets/images/project2.jpg"
      },
      {
        name: "HotChoccies",
        owner: userIds[2],
        members: [userIds[0], userIds[2], userIds[3], userIds[4]],
        date: daysAgo(26),
        popularity: 8,
        downloads: 20,
        hashtags: ["CSS", "HTML"],
        type: "Web Application",
        version: "1.0.0",
        status: "Checked In",
        files: [
          { name: "olive.html", path: "/assets/images/olive.html" },
          { name: "pineapple.html", path: "/assets/images/pineapple.html" }
        ],
        activity: [
          { userId: userIds[2], action: "checked in", message: "Initial commit", timestamp: daysAgo(26) },
          { userId: userIds[0], action: "checked in", message: "Added responsive layout", timestamp: daysAgo(12) },
          { userId: userIds[3], action: "checked in", message: "Updated color scheme", timestamp: daysAgo(10) },
          { userId: userIds[4], action: "checked in", message: "Fixed mobile navigation", timestamp: daysAgo(8) }
        ],
        discussion: [
          { userId: userIds[2], text: "Main styles done, review please." },
          { userId: userIds[0], text: "Looks good, will add media queries." }
        ],
        image: "/assets/images/project3.jpg"
      },
      {
        name: "StrawberryShortcake",
        owner: userIds[3],
        members: [userIds[3], userIds[0], userIds[4]],
        date: daysAgo(24),
        popularity: 15,
        downloads: 40,
        hashtags: ["C#", ".NET"],
        type: "Desktop Application",
        version: "1.2.0",
        status: "Checked In",
        files: [
          { name: "blueberry.html", path: "/assets/images/blueberry.html" },
          { name: "ice.html", path: "/assets/images/ice.html" }
        ],
        activity: [
          { userId: userIds[3], action: "checked in", message: "Initial shortcake release", timestamp: daysAgo(24) },
          { userId: userIds[0], action: "checked in", message: "Added form validation", timestamp: daysAgo(7) },
          { userId: userIds[4], action: "checked in", message: "Implemented data persistence", timestamp: daysAgo(6) }
        ],
        discussion: [
          { userId: userIds[0], text: "Yum, looks delicious!" }
        ],
        image: "/assets/images/project4.jpg"
      },
      {
        name: "TiramisuDelight",
        owner: userIds[4],
        members: [userIds[4], userIds[1], userIds[5]],
        date: daysAgo(22),
        popularity: 30,
        downloads: 60,
        hashtags: ["Java", "SpringBoot"],
        type: "Backend Service",
        version: "2.0.0",
        status: "Checked Out",
        files: [
          { name: "cucumber.html", path: "/assets/images/cucumber.html" },
          { name: "grape.html", path: "/assets/images/grape.html" }
        ],
        activity: [
          { userId: userIds[4], action: "checked in", message: "Initial backend setup", timestamp: daysAgo(22) },
          { userId: userIds[1], action: "checked in", message: "Added authentication endpoints", timestamp: daysAgo(16) },
          { userId: userIds[5], action: "checked in", message: "Implemented API documentation", timestamp: daysAgo(14) },
          { userId: userIds[4], action: "checked out", message: "Working on service endpoints", timestamp: hoursAgo(3) }
        ],
        discussion: [
          { userId: userIds[1], text: "Make sure to add API docs" }
        ],
        image: "/assets/images/project5.jpg"
      },
      {
        name: "CheesecakeHeaven",
        owner: userIds[5],
        members: [userIds[5], userIds[0], userIds[2]],
        date: daysAgo(20),
        popularity: 18,
        downloads: 45,
        hashtags: ["Node.js", "Express"],
        type: "API Service",
        version: "1.0.0",
        status: "Checked In",
        files: [
          { name: "pomegranate.html", path: "/assets/images/pomegranate.html" },
          { name: "mango.html", path: "/assets/images/mango.html" }
        ],
        activity: [
          { userId: userIds[5], action: "checked in", message: "Initial cheesecake API", timestamp: daysAgo(20) },
          { userId: userIds[0], action: "checked in", message: "Added error handling middleware", timestamp: daysAgo(5) },
          { userId: userIds[2], action: "checked in", message: "Implemented request validation", timestamp: daysAgo(4) }
        ],
        discussion: [
          { userId: userIds[2], text: "Don't forget to handle errors" }
        ],
        image: "/assets/images/project6.jpg"
      },
      {
        name: "LemonTart",
        owner: userIds[0],
        members: [userIds[0], userIds[1], userIds[3], userIds[5]],
        date: daysAgo(18),
        popularity: 10,
        downloads: 25,
        hashtags: ["Vue.js"],
        type: "Web Application",
        version: "1.0.0",
        status: "Checked In",
        files: [
          { name: "cherry.html", path: "/assets/images/cherry.html" }
        ],
        activity: [
          { userId: userIds[0], action: "checked in", message: "Initial tart UI", timestamp: daysAgo(18) },
          { userId: userIds[1], action: "checked in", message: "Added Vue components", timestamp: daysAgo(11) },
          { userId: userIds[3], action: "checked in", message: "Implemented Vue Router", timestamp: daysAgo(9) },
          { userId: userIds[5], action: "checked in", message: "Added Vuex state management", timestamp: daysAgo(3) }
        ],
        discussion: [
          { userId: userIds[3], text: "Add routing support" }
        ],
        image: "/assets/images/project7.jpg"
      },
      {
        name: "MacaronMagic",
        owner: userIds[1],
        members: [userIds[1], userIds[2], userIds[4]],
        date: daysAgo(16),
        popularity: 22,
        downloads: 55,
        hashtags: ["Angular"],
        type: "Frontend Application",
        version: "1.0.0",
        status: "Checked Out",
        files: [
          { name: "grape.html", path: "/assets/images/grape.html" },
          { name: "pomegranate.html", path: "/assets/images/pomegranate.html" },
          { name: "mango.html", path: "/assets/images/mango.html" }
        ],
        activity: [
          { userId: userIds[1], action: "checked in", message: "Initial Angular setup", timestamp: daysAgo(16) },
          { userId: userIds[2], action: "checked in", message: "Added RxJS operators", timestamp: daysAgo(13) },
          { userId: userIds[4], action: "checked in", message: "Implemented HTTP interceptors", timestamp: daysAgo(11) },
          { userId: userIds[1], action: "checked out", message: "Refactoring macarons", timestamp: hoursAgo(2) }
        ],
        discussion: [
          { userId: userIds[2], text: "Use RxJS for streams" }
        ],
        image: "/assets/images/project8.jpg"
      },
      {
        name: "BaklavaBliss",
        owner: userIds[6],
        members: [userIds[6], userIds[7], userIds[0]],
        date: daysAgo(14),
        popularity: 20,
        downloads: 48,
        hashtags: ["TypeScript", "React"],
        type: "Web Application",
        version: "1.1.0",
        status: "Checked In",
        files: [
          { name: "honey.html", path: "/assets/images/honey.html" },
          { name: "pistachio.html", path: "/assets/images/pistachio.html" }
        ],
        activity: [
          { userId: userIds[6], action: "checked in", message: "Initial baklava layers", timestamp: daysAgo(14) },
          { userId: userIds[7], action: "checked in", message: "Added TypeScript types", timestamp: daysAgo(10) },
          { userId: userIds[0], action: "checked in", message: "Implemented component library", timestamp: hoursAgo(48) }
        ],
        discussion: [
          { userId: userIds[6], text: "Let's layer this properly" },
          { userId: userIds[7], text: "Type safety is key here" }
        ],
        image: "/assets/images/project9.jpg"
      },
      {
        name: "PannaCottaPerfection",
        owner: userIds[8],
        members: [userIds[8], userIds[9], userIds[0], userIds[1]],
        date: daysAgo(12),
        popularity: 27,
        downloads: 62,
        hashtags: ["Python", "Django"],
        type: "Web Application",
        version: "2.1.0",
        status: "Checked In",
        files: [
          { name: "vanilla.html", path: "/assets/images/vanilla.html" },
          { name: "raspberry.html", path: "/assets/images/raspberry.html" },
          { name: "cream.html", path: "/assets/images/cream.html" }
        ],
        activity: [
          { userId: userIds[8], action: "checked in", message: "Initial Django setup", timestamp: daysAgo(12) },
          { userId: userIds[9], action: "checked in", message: "Added authentication", timestamp: daysAgo(8) },
          { userId: userIds[0], action: "checked in", message: "Implemented REST API", timestamp: hoursAgo(24) },
          { userId: userIds[1], action: "checked in", message: "Added admin panel", timestamp: hoursAgo(12) }
        ],
        discussion: [
          { userId: userIds[8], text: "Django project ready" },
          { userId: userIds[9], text: "Authentication works fine" }
        ],
        image: "/assets/images/project10.jpg"
      }
    ];

    // -----------------------------------------------------------------------------------------------------------------------------
    const projectsResult = await db.collection("projects").insertMany(projectsData);
    const projectIds = Object.values(projectsResult.insertedIds);

    await db.collection("users").updateOne({ _id: userIds[0] }, { $set: { projects: [projectIds[0], projectIds[6]] } });
    await db.collection("users").updateOne({ _id: userIds[1] }, { $set: { projects: [projectIds[1], projectIds[7]] } });
    await db.collection("users").updateOne({ _id: userIds[2] }, { $set: { projects: [projectIds[2]] } });
    await db.collection("users").updateOne({ _id: userIds[3] }, { $set: { projects: [projectIds[3]] } });
    await db.collection("users").updateOne({ _id: userIds[4] }, { $set: { projects: [projectIds[4]] } });
    await db.collection("users").updateOne({ _id: userIds[5] }, { $set: { projects: [projectIds[5]] } });
    await db.collection("users").updateOne({ _id: userIds[6] }, { $set: { projects: [projectIds[8]] } });
    await db.collection("users").updateOne({ _id: userIds[8] }, { $set: { projects: [projectIds[9]] } });

    await db.collection("users").updateOne({ _id: userIds[0] }, { $set: { savedProjects: [projectIds[1], projectIds[4], projectIds[5]] } });
    await db.collection("users").updateOne({ _id: userIds[1] }, { $set: { savedProjects: [projectIds[0], projectIds[2], projectIds[6]] } });
    await db.collection("users").updateOne({ _id: userIds[2] }, { $set: { savedProjects: [projectIds[3], projectIds[7]] } });
    await db.collection("users").updateOne({ _id: userIds[3] }, { $set: { savedProjects: [projectIds[0], projectIds[1]] } });
    await db.collection("users").updateOne({ _id: userIds[4] }, { $set: { savedProjects: [projectIds[2], projectIds[5], projectIds[6]] } });
    await db.collection("users").updateOne({ _id: userIds[5] }, { $set: { savedProjects: [projectIds[0], projectIds[7]] } });
    await db.collection("users").updateOne({ _id: userIds[6] }, { $set: { savedProjects: [projectIds[1], projectIds[3], projectIds[4]] } });
    await db.collection("users").updateOne({ _id: userIds[7] }, { $set: { savedProjects: [projectIds[0], projectIds[2], projectIds[8]] } });
    await db.collection("users").updateOne({ _id: userIds[8] }, { $set: { savedProjects: [projectIds[5], projectIds[6], projectIds[7]] } });
    await db.collection("users").updateOne({ _id: userIds[9] }, { $set: { savedProjects: [projectIds[1], projectIds[4], projectIds[9]] } });

    console.log("Database seeded successfully!");
    console.log(`Created ${userIds.length + 1} users (including admin) and ${projectIds.length} projects`);
  } 
  catch(err) 
  {
    console.error(err);
  } 
  finally 
  {
    await client.close();
  }
}

seed();
