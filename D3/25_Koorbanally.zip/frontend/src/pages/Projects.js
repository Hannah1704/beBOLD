import React, { useEffect, useState } from "react";
import { ProjectCard } from "../components/ProjectCard";
import { CreateProjectForm } from "../components/CreateProjectForm";

const getIdString = (obj) => {
  if (!obj) return null;
  if (typeof obj === "string") return obj;
  if (obj.$oid) return obj.$oid;
  if (obj._id?.$oid) return obj._id.$oid;
  return null;
};

function Projects({ currentUser }) {
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterTag, setFilterTag] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [sortBy, setSortBy] = useState("recent"); 

  useEffect(() => {
    async function fetchProjects() {
      try {
        const res = await fetch("/api/projects");
        const data = await res.json();
        if(data.success) 
        {
          setProjects(data.projects);
          setFilteredProjects(data.projects);
        } 
        else 
        {
          alert("Failed to fetch projects");
        }
      } 
      catch (err) 
      {
        console.error(err);
        alert("Server error fetching projects");
      } 
      finally 
      {
        setLoading(false);
      }
    }
    fetchProjects();
  }, []);

  const handleHashtagClick = (tag) => {
    if(filterTag === tag) {
      setFilterTag("");
      setFilteredProjects(projects);
    } 
    else {
      setFilterTag(tag);
      setFilteredProjects(projects.filter((p) => p.hashtags?.includes(tag)));
    }
  };

  useEffect(() => {
    let filtered = [...projects];
    
    if (filterTag) filtered = filtered.filter((p) => p.hashtags?.includes(filterTag));
    if (searchTerm.trim()) {
      filtered = filtered.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.type?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (sortBy === "popular") 
    {
      filtered.sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
    } 
    else if (sortBy === "name") {
      filtered.sort((a, b) => a.name.localeCompare(b.name));
    } 
    else if (sortBy === "recent") {
      filtered.sort((a, b) => {
        const dateA = new Date(a.date?.$date?.$numberLong || a.date || 0);
        const dateB = new Date(b.date?.$date?.$numberLong || b.date || 0);
        return dateB - dateA;
      });
    }

    setFilteredProjects(filtered);
  }, [searchTerm, filterTag, projects, sortBy]);

  const allHashtags = [...new Set(projects.flatMap(p => p.hashtags || []))].slice(0, 10);

  if (loading) 
  {
    return (
      <div className="page-container flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-accent1 mx-auto mb-4"></div>
          <p className="text-xl text-accent2">Loading projects...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
          <div>
            <h1 className="text-4xl font-bold text-accent3 mb-2">Projects Gallery</h1>
            <p className="text-gray-300">
              Welcome, <span className="font-bold text-accent2">{currentUser?.username || 'User'}</span>
              {' '}• {filteredProjects.length} project{filteredProjects.length !== 1 ? 's' : ''} found
            </p>
          </div>
          <button
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="bg-accent1 text-white px-6 py-3 rounded-lg hover:bg-accent2 transition-all shadow-lg font-bold flex items-center gap-2 justify-center"
          >
            <span className="text-2xl">{showCreateForm ? '−' : '+'}</span>
            {showCreateForm ? 'Hide Form' : 'Create Project'}
          </button>
        </div>
      </div>

      {showCreateForm && (
        <div className="mb-8 animate-fadeIn">
          <CreateProjectForm 
            currentUserId={currentUser.id} 
            onCreateProject={(newProject) => {
              setProjects(prev => [newProject, ...prev]);
              setShowCreateForm(false);
            }} 
          />
        </div>
      )}

      <div className="bg-layer p-6 rounded-xl mb-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
          <div className="lg:col-span-2">
            <label className="block text-accent2 font-semibold mb-2 text-sm">Search Projects</label>
            <input 
              type="text" 
              placeholder="Search by name, description, or type..." 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white text-black rounded-md px-4 py-3 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-accent1"
            />
          </div>

          <div>
            <label className="block text-accent2 font-semibold mb-2 text-sm">Sort By</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full bg-white text-black rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-accent1"
            >
              <option value="recent">Most Recent</option>
              <option value="popular">Most Popular</option>
              <option value="name">Name (A-Z)</option>
            </select>
          </div>
        </div>

        {allHashtags.length > 0 && (
          <div>
            <label className="block text-accent2 font-semibold mb-2 text-sm">Quick Filters</label>
            <div className="flex flex-wrap gap-2">
              {allHashtags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => handleHashtagClick(tag)}
                  className={`px-3 py-1 rounded-full text-sm font-semibold transition-all ${
                    filterTag === tag
                      ? 'bg-accent1 text-white shadow-lg'
                      : 'bg-white text-black hover:bg-accent3 hover:text-black'
                  }`}
                >
                  #{tag}
                </button>
              ))}
              {filterTag && (
                <button
                  onClick={() => setFilterTag("")}
                  className="px-3 py-1 rounded-full text-sm font-semibold bg-red-500 text-white hover:bg-red-600"
                >
                  Clear Filter ×
                </button>
              )}
            </div>
          </div>
        )}

        {(searchTerm || filterTag) && (
          <div className="mt-4 p-3 bg-bgMain rounded-lg">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-300">
                {searchTerm && <span>Search: <span className="text-accent3 font-semibold">"{searchTerm}"</span></span>}
                {searchTerm && filterTag && <span className="mx-2">•</span>}
                {filterTag && <span>Tag: <span className="text-accent3 font-semibold">#{filterTag}</span></span>}
              </div>
              <button
                onClick={() => {
                  setSearchTerm("");
                  setFilterTag("");
                }}
                className="text-accent1 hover:text-accent2 font-semibold text-sm"
              >
                Clear All
              </button>
            </div>
          </div>
        )}
      </div>

      {filteredProjects.length === 0 ? (
        <div className="bg-layer rounded-xl p-12 text-center">
          <div className="mb-4">
            <svg className="mx-auto h-24 w-24 text-accent2 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="text-2xl font-bold text-accent1 mb-2">No Projects Found</h3>
          <p className="text-gray-300 mb-4">
            {searchTerm || filterTag 
              ? "Try adjusting your search or filters" 
              : "Be the first to create a project!"}
          </p>
          {!showCreateForm && (
            <button
              onClick={() => setShowCreateForm(true)}
              className="bg-accent1 text-white px-6 py-2 rounded-lg hover:bg-accent2 transition-all"
            >
              Create First Project
            </button>
          )}
        </div>
      ) : (
        <>
          <div className="mb-4 flex items-center justify-between">
            <p className="text-gray-300">
              Showing <span className="text-accent3 font-bold">{filteredProjects.length}</span> of{' '}
              <span className="text-accent2 font-bold">{projects.length}</span> total projects
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <ProjectCard 
                key={getIdString(project._id)} 
                project={project} 
                onHashtagClick={handleHashtagClick} 
                currentUser={currentUser.id} 
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default Projects;