import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { GeneralData } from "../components/GeneralData";
import { UserActivity } from "../components/UserActivity";
import { Friends } from "../components/Friends";

function Profile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [savedProjects, setSavedProjects] = useState([]);
  const [createdProjects, setCreatedProjects] = useState([]);
  const [activities, setActivities] = useState([]);
  const [involvedProjects, setInvolvedProjects] = useState([]);

  useEffect(() => {
    async function fetchUser() {
      try 
      {
        const res = await fetch(`/api/users/${id}`);
        const data = await res.json();
        if (data.success) {
          setUser(data.user);
          
          if (data.user.savedProjects && data.user.savedProjects.length > 0)
          {
            const projectIds = data.user.savedProjects.map(p => {
              if (typeof p === 'string') return p;
              if (p.$oid) return p.$oid;
              if (p._id) return p._id.toString();
              return p.toString();
            }).filter(Boolean);

            if(projectIds.length > 0) 
            {
              const projRes = await fetch(`/api/projects/by-ids?ids=${projectIds.join(",")}`);
              const projData = await projRes.json();
              if (projData.success) 
              {
                setSavedProjects(projData.projects);
              }
            }
          }

          const actRes = await fetch(`/api/users/${id}/activity`);
          const actData = await actRes.json();
          if(actData.success) 
          {
            setActivities(actData.activities || []);
            setInvolvedProjects(actData.projects || []);
            
            const created = (actData.projects || []).filter(
              p => p.owner?.toString() === id
            );
            setCreatedProjects(created);
          }
        }
        else 
        {
          console.error(data.message);
        }
      } 
      catch (err) 
      {
        console.error("Error fetching user:", err);
      } 
      finally 
      {
        setLoading(false);
      }
    }
    fetchUser();
  }, [id]);

  const handleProjectClick = (projectId) => {
    navigate(`/project/${projectId}`);
  };

  const handleUserClick = (userId) => {
    navigate(`/user/${userId}`);
  };

  if (loading) return <div className="page-container"><p>Loading...</p></div>;
  if (!user) return <div className="page-container"><p>User not found</p></div>;

  return (
    <div className="profile-page">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-accent3 mb-2">
          {user.username}'s Profile
        </h1>
        <p className="text-gray-300">View profile details, activity, and projects</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="profile-section">
          <h2 className="section-title">Profile Information</h2>
          <GeneralData user={user} setUser={setUser} />
        </div>

        <div className="lg:col-span-2 profile-section">
          <h2 className="section-title">Quick Stats</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white text-black rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-accent1">{createdProjects.length}</p>
              <p className="text-sm text-gray-600">Created</p>
            </div>
            <div className="bg-white text-black rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-accent2">{savedProjects.length}</p>
              <p className="text-sm text-gray-600">Saved</p>
            </div>
            <div className="bg-white text-black rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-accent3">{involvedProjects.length}</p>
              <p className="text-sm text-gray-600">Active In</p>
            </div>
            <div className="bg-white text-black rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-accent1">{(user.friends || []).length}</p>
              <p className="text-sm text-gray-600">Friends</p>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="text-accent2 font-bold text-xl mb-3">Recent Activity</h3>
            {activities.length === 0 ? (
              <p className="text-gray-300">No recent activity</p>
            ) : (
              <div className="space-y-2">
                {activities.slice(0, 3).map((act, idx) => (
                  <div key={idx} className="bg-white text-black rounded-lg p-3 shadow-sm">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-semibold text-accent1 capitalize">{act.action}</span>
                      <span className="text-xs text-gray-500">
                        {new Date(act.timestamp).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700">{act.message}</p>
                    <button
                      onClick={() => handleProjectClick(act.projectId)}
                      className="text-xs text-accent3 hover:underline mt-1"
                    >
                      {act.projectName}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="profile-section">
          <h2 className="section-title">Created Projects ({createdProjects.length})</h2>
          {createdProjects.length === 0 ? (
            <p className="text-gray-300">No projects created yet</p>
          ) : (
            <div className="space-y-3">
              {createdProjects.map((proj) => (
                <div
                  key={proj._id}
                  onClick={() => handleProjectClick(proj._id)}
                  className="bg-white text-black rounded-lg p-4 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start gap-3">
                    {proj.image && (
                      <img
                        src={proj.image}
                        alt={proj.name}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                    )}
                    <div className="flex-1">
                      <h3 className="font-bold text-accent1 text-lg">{proj.name}</h3>
                      <p className="text-sm text-gray-600 italic">{proj.type}</p>
                      <div className="flex gap-4 mt-2 text-xs text-gray-600">
                        <span>⭐ {proj.popularity}</span>
                        <span>📥 {proj.downloads}</span>
                        <span className="capitalize">{proj.status}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="profile-section">
          <h2 className="section-title">Saved Projects ({savedProjects.length})</h2>
          {savedProjects.length === 0 ? (
            <p className="text-gray-300">No saved projects yet</p>
          ) : (
            <div className="space-y-3">
              {savedProjects.map((proj) => (
                <div
                  key={proj._id}
                  onClick={() => handleProjectClick(proj._id)}
                  className="bg-white text-black rounded-lg p-4 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start gap-3">
                    {proj.image && (
                      <img
                        src={proj.image}
                        alt={proj.name}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                    )}
                    <div className="flex-1">
                      <h3 className="font-bold text-accent1 text-lg">{proj.name}</h3>
                      <p className="text-sm text-gray-600 italic">{proj.type}</p>
                      <div className="flex gap-4 mt-2 text-xs text-gray-600">
                        <span>⭐ {proj.popularity}</span>
                        <span>📥 {proj.downloads}</span>
                      </div>
                      {proj.hashtags && proj.hashtags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {proj.hashtags.slice(0, 3).map((tag, idx) => (
                            <span
                              key={idx}
                              className="bg-accent3 text-black text-xs px-2 py-1 rounded-full"
                            >
                              #{tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="profile-section">
          <h2 className="section-title">All Activity ({activities.length})</h2>
          {activities.length === 0 ? (
            <p className="text-gray-300">No activity yet</p>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {activities.map((act, idx) => (
                <div key={idx} className="bg-white text-black rounded-lg p-3 shadow-sm">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-semibold text-accent1 capitalize">{act.action}</span>
                    <span className="text-xs text-gray-500">
                      {new Date(act.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700 mb-1">{act.message}</p>
                  <button
                    onClick={() => handleProjectClick(act.projectId)}
                    className="text-xs text-accent3 hover:underline"
                  >
                    Project: {act.projectName}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="profile-section">
          <Friends user={user} onUserClick={handleUserClick} />
        </div>
      </div>
    </div>
  );
}

export default Profile;