import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ViewOnlyGeneralData } from "../components/ViewOnlyGeneralData";
import { AdminUserEditor } from "../components/AdminUserEditor";

function UserView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [isFriend, setIsFriend] = useState(false);
  const [friendRequestSent, setFriendRequestSent] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const storedUser = JSON.parse(localStorage.getItem("user"));
  const currentUserId = storedUser?.id;

  useEffect(() => {
    async function fetchData() {
      try 
      {
        const userRes = await fetch(`/api/users/${id}`);
        const userData = await userRes.json();
        if (userData.success) setUser(userData.user);

        if (currentUserId) {
          const currentRes = await fetch(`/api/users/${currentUserId}`);
          const currentData = await currentRes.json();
          if (currentData.success) {
            setCurrentUser(currentData.user);
            setIsAdmin(currentData.user.isAdmin === true);
            
            const friendIds = (currentData.user.friends || []).map(f => 
              typeof f === 'string' ? f : f.$oid || f._id?.toString() || f.toString()
            );
            setIsFriend(friendIds.includes(id));
          }
        }
      } catch (err) {
        console.error("Error fetching user data:", err);
      }
    }
    fetchData();
  }, [id, currentUserId]);

  const handleFriendRequest = async () => {
    try {
      const res = await fetch(`/api/users/${currentUserId}/friends`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ friendId: id }),
      });
      const data = await res.json();
      if (data.success) {
        setFriendRequestSent(true);
        setIsFriend(true);
        alert(`Friend request sent to ${user.username}!`);
      }
    } catch (err) {
      console.error("Error sending friend request:", err);
    }
  };

  const handleUnfriend = async () => {
    try {
      const res = await fetch(`/api/users/${currentUserId}/friends/${id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) {
        setIsFriend(false);
        alert(`Unfriended ${user.username}`);
      }
    } catch (err) {
      console.error("Error unfriending:", err);
    }
  };

  const handleUserUpdate = (updatedUser) => {
    setUser(updatedUser);
  };

  const handleUserDelete = () => {
    alert(`User ${user.username} has been deleted. Redirecting to home...`);
    setTimeout(() => navigate("/home"), 1500);
  };

  if (!user) return <div className="page-container">Loading...</div>;

  const isOwnProfile = currentUserId === id;

  return (
    <div className="page-container">
      {isAdmin && (
        <div className="bg-yellow-900/20 border-2 border-yellow-500 rounded-xl p-4 mb-6">
          <div className="flex items-center gap-3">
            <span className="text-3xl">👑</span>
            <div>
              <h3 className="text-yellow-400 font-bold text-lg">Admin Mode</h3>
              <p className="text-yellow-300 text-sm">
                You can edit or delete this user's account using the controls below.
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="mb-6">
        <h1 className="text-3xl font-bold text-accent3 mb-2">
          {user.username}'s Profile
          {user.isAdmin && <span className="ml-3 text-red-400 text-xl">👑 Admin</span>}
        </h1>
        {!isOwnProfile && !isAdmin && (
          <div className="flex gap-2">
            {isFriend ? (
              <button
                onClick={handleUnfriend}
                className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600"
              >
                Unfriend
              </button>
            ) : (
              <button
                onClick={handleFriendRequest}
                disabled={friendRequestSent}
                className="bg-accent1 text-white px-4 py-2 rounded-md hover:bg-accent2 disabled:opacity-50"
              >
                {friendRequestSent ? "Request Sent" : "Add Friend"}
              </button>
            )}
          </div>
        )}
      </div>

      <ViewOnlyGeneralData
        userId={id}
        currentUserId={currentUserId}
        onFriendChange={() => setIsFriend(!isFriend)}
      />

      {isAdmin && !user.isAdmin && ( 
        <AdminUserEditor
          isAdmin={isAdmin}
          user={user}
          onUpdate={handleUserUpdate}
          onDelete={handleUserDelete}
        />
      )}

      {isAdmin && user.isAdmin && (
        <div className="bg-red-900/20 border-2 border-red-500 rounded-xl p-4 mt-6">
          <p className="text-red-300 text-center">
            ⚠️ Cannot edit or delete admin accounts
          </p>
        </div>
      )}
    </div>
  );
}

export default UserView;