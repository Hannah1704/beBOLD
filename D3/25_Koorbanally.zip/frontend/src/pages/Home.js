import React, { useState, useEffect } from "react";
import { LocalFeed } from "../components/LocalFeed";
import { GlobalFeed } from "../components/GlobalFeed";
import { SearchBar } from "../components/SearchBar";
import { SortPanel } from "../components/SortPanel";
import { RecentActivity } from "../components/RecentActivity";
import { AllUsers } from "../components/AllUsers";
import { AdminControls } from "../components/AdminControls";

function Home() {
  const [projects, setProjects] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [friends, setFriends] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOptions, setSortOptions] = useState({
    order: "asc",
    criteria: { popularity: false, downloads: false },
    feeds: { local: true, global: true },
  });
  const [savedProjects, setSavedProjects] = useState([]);
  const [createdProjects, setCreatedProjects] = useState([]);
  const [recentActivities, setRecentActivities] = useState([]);
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);

  const storedUser = JSON.parse(localStorage.getItem("user"));
  const loggedInUserId = storedUser?.id;

  useEffect(() => {
    async function checkAdmin() {
      if (!loggedInUserId) return;
      
      try 
      {
        const res = await fetch(`/api/users/${loggedInUserId}/is-admin`);
        const data = await res.json();
        if(data.success) 
        {
          setIsAdmin(data.isAdmin);
        }
      } 
      catch(err) 
      {
        console.error("Error checking admin status:", err);
      }
    }
    checkAdmin();
  }, [loggedInUserId]);

  useEffect(() => {
    async function fetchLoggedInUser() {
      if (!loggedInUserId) return;

      try 
      {
        const res = await fetch(`/api/users/${loggedInUserId}`);
        const data = await res.json();
        if (data.success) {
          setLoggedInUser(data.user);
        }
      } 
      catch(err) 
      {
        console.error("Error fetching logged in user:", err);
      }
    }
    fetchLoggedInUser();
  }, [loggedInUserId]);

  useEffect(() => {
    async function fetchAllUsers() {
      try 
      {
        const res = await fetch("/api/users");
        const data = await res.json();
        if(data.success) 
        {
          setAllUsers(data.users.filter((u) => u._id !== loggedInUserId));
        }
      } 
      catch (err) 
      {
        console.error("Error fetching users:", err);
      }
    }
    fetchAllUsers();
  }, [loggedInUserId]);

  useEffect(() => {
    async function fetchFriends() {
      if (!loggedInUserId) return;

      try 
      {
        const res = await fetch(`/api/users/${loggedInUserId}/friends`);
        const data = await res.json();
        if(data.success) 
        {
          setFriends(data.friends);
        }
      } 
      catch (err) 
      {
        console.error("Error fetching friends:", err);
      }
    }
    fetchFriends();
  }, [loggedInUserId]);

  useEffect(() => {
    async function fetchProjects() {
      try 
      {
        const res = await fetch("/api/projects");
        const data = await res.json();
        if (data.success) {
          setProjects(data.projects);
        }
      } 
      catch (err) {
        console.error("Error fetching projects:", err);
      }
    }
    fetchProjects();
  }, []);

  useEffect(() => {
    async function fetchSavedProjects() {
      if (!loggedInUser?.savedProjects || loggedInUser.savedProjects.length === 0) {
        setSavedProjects([]);
        return;
      }

      try 
      {
        const projectIds = loggedInUser.savedProjects.map(p => {
          if (typeof p === 'string') return p;
          if (p.$oid) return p.$oid;
          if (p._id) return p._id.toString();
          return p.toString();
        }).filter(Boolean);

        if(projectIds.length > 0) 
        {
          const res = await fetch(`/api/projects/by-ids?ids=${projectIds.join(",")}`);
          const data = await res.json();
          if (data.success) {
            setSavedProjects(data.projects);
          }
        }
      } 
      catch (err)
      {
        console.error("Error fetching saved projects:", err);
      }
    }
    fetchSavedProjects();
  }, [loggedInUser]);

  useEffect(() => {
    if (!loggedInUserId || projects.length === 0) return;

    const userCreatedProjects = projects.filter(
      (p) => p.owner?.toString() === loggedInUserId || p.ownerId?.toString() === loggedInUserId
    );
    setCreatedProjects(userCreatedProjects);
  }, [projects, loggedInUserId]);

  useEffect(() => {
    async function fetchRecentActivities() {
      if (!loggedInUserId) return;

      try 
      {
        const res = await fetch(`/api/users/${loggedInUserId}/activity`);
        const data = await res.json();
        if (data.success) {
          const sortedActivities = (data.activities || []).sort(
            (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
          );
          setRecentActivities(sortedActivities.slice(0, 10));
        }
      } 
      catch (err) 
      {
        console.error("Error fetching recent activities:", err);
      }
    }
    fetchRecentActivities();
  }, [loggedInUserId]);

  const handleAddFriend = async (friendId) => {
    try {
      const res = await fetch(`/api/users/${loggedInUserId}/friends`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ friendId }),
      });
      const data = await res.json();
      if (data.success) {
        alert("Friend request sent!");
        const friendsRes = await fetch(`/api/users/${loggedInUserId}/friends`);
        const friendsData = await friendsRes.json();
        if (friendsData.success) setFriends(friendsData.friends);
      }
    } catch (err) {
      console.error("Error adding friend:", err);
    }
  };

  const filterProjects = (projects) => {
    if (!searchTerm) return projects;

    return projects.filter((proj) => {
      const projectNameMatch = proj.name.toLowerCase().includes(searchTerm.toLowerCase());
      const memberMatch = (proj.memberNames || [])
        .join(" ")
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
      const hashtagMatch = (proj.hashtags || [])
        .some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));

      return projectNameMatch || memberMatch || hashtagMatch;
    });
  };

  const filterUsers = (users) => {
    if (!searchTerm) return users;

    return users.filter((user) => {
      const usernameMatch = user.username.toLowerCase().includes(searchTerm.toLowerCase());
      const emailMatch = user.email.toLowerCase().includes(searchTerm.toLowerCase());
      const workMatch = user.work.toLowerCase().includes(searchTerm.toLowerCase());

      return usernameMatch || emailMatch || workMatch;
    });
  };

  const sortProjects = (projects) => {
    let sorted = [...projects];

    if(sortOptions.criteria.popularity) {
      sorted.sort((a, b) => a.popularity - b.popularity);
    }
    if (sortOptions.criteria.downloads) {
      sorted.sort((a, b) => a.downloads - b.downloads);
    }

    if (!sortOptions.criteria.popularity && !sortOptions.criteria.downloads) {
      sorted.sort((a, b) => a.name.localeCompare(b.name));
    }

    if (sortOptions.order === "desc") {
      sorted.reverse();
    }

    return sorted;
  };

  const handleDeleteAllProjects = async () => {
    try 
    {
      const res = await fetch("/api/projects");
      const data = await res.json();
      if (data.success) {
        setProjects(data.projects);
      }
    } catch (err) {
      console.error("Error fetching projects:", err);
    }
  };

  const handleDeleteUser = async (userId) => {
    try 
    {
      const res = await fetch("/api/users");
      const data = await res.json();
      if (data.success) {
        setAllUsers(data.users.filter((u) => u._id !== loggedInUserId));
      }
    } 
    catch (err) {
      console.error("Error fetching users:", err);
    }
  };

  const localProjects = projects.filter((p) =>
    (p.memberIds || []).some((id) => id.toString() === loggedInUserId)
  );
  const globalProjects = projects.filter(
    (p) => !(p.memberIds || []).some((id) => id.toString() === loggedInUserId)
  );

  const filteredUsers = filterUsers(allUsers);
  const hasSearchResults = searchTerm && (filterProjects(projects).length > 0 || filteredUsers.length > 0);

  return (
    <div className="page-container">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-accent3 mb-2">
          Welcome back, {loggedInUser?.username || "User"}!
          {isAdmin && <span className="ml-3 text-red-400 text-2xl">👑 Admin</span>}
        </h1>
        <p className="text-gray-300">
          Here's what's happening with your projects and collaborations.
        </p>
      </div>

      {isAdmin && (
        <div className="bg-red-900/20 border-2 border-red-500 rounded-xl p-4 mb-8">
          <div className="flex items-center gap-3">
            <span className="text-3xl">👑</span>
            <div>
              <h3 className="text-red-400 font-bold text-lg">Admin Mode Active</h3>
              <p className="text-red-300 text-sm">
                You have full access to edit and delete all content. Use admin controls at the bottom of the page.
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="feed-section">
          <h2 className="feed-title">Recent Activities</h2>
          <p className="text-gray-300 mb-4 text-sm">Your latest project contributions</p>
          <RecentActivity activities={recentActivities} />
        </div>

        <div className="feed-section">
          <h2 className="feed-title">Quick Stats</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white text-black rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-accent1">{createdProjects.length}</p>
              <p className="text-sm text-gray-600">Projects Created</p>
            </div>
            <div className="bg-white text-black rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-accent2">{savedProjects.length}</p>
              <p className="text-sm text-gray-600">Saved Projects</p>
            </div>
            <div className="bg-white text-black rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-accent3">{localProjects.length}</p>
              <p className="text-sm text-gray-600">Active Projects</p>
            </div>
            <div className="bg-white text-black rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-accent1">{friends.length}</p>
              <p className="text-sm text-gray-600">Friends</p>
            </div>
          </div>
        </div>
      </div>

      {(savedProjects.length > 0 || createdProjects.length > 0) && (
        <div className="mb-8">
          <h2 className="section-title">My Projects</h2>
          <p className="text-gray-300 mb-6">Projects you've created or bookmarked</p>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {createdProjects.length > 0 && (
              <div className="feed-section">
                <h3 className="text-accent2 font-bold text-xl mb-4">Created by Me</h3>
                <GlobalFeed projects={sortProjects(filterProjects(createdProjects))} onHashtagClick={(tag) => setSearchTerm(tag)} />
              </div>
            )}

            {savedProjects.length > 0 && (
              <div className="feed-section">
                <h3 className="text-accent3 font-bold text-xl mb-4">Saved Projects</h3>
                <GlobalFeed projects={sortProjects(filterProjects(savedProjects))} onHashtagClick={(tag) => setSearchTerm(tag)} />
              </div>
            )}
          </div>
        </div>
      )}

      <div className="mb-8">
        <h2 className="section-title">
          {searchTerm ? `Search Results for "${searchTerm}"` : "Explore All Projects"}
        </h2>
        <p className="text-gray-300 mb-6">
          {searchTerm 
            ? "Showing filtered results based on your search" 
            : "Search and filter through the project feeds and users"}
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="lg:col-span-2">
            <div className="bg-layer p-6 rounded-xl h-full">
              <h3 className="text-accent2 font-bold text-lg mb-4">Search</h3>
              <SearchBar onSearch={setSearchTerm} />
            </div>
          </div>

          <div>
            <SortPanel onSortChange={setSortOptions} />
          </div>
        </div>
      </div>

      {searchTerm && filteredUsers.length > 0 && (
        <div className="mb-8">
          <div className="feed-section">
            <h2 className="feed-title">Users ({filteredUsers.length})</h2>
            <p className="text-gray-300 mb-4 text-sm">People matching your search</p>
            <AllUsers 
              users={filteredUsers} 
              currentUserId={loggedInUserId}
              friends={friends}
              onAddFriend={handleAddFriend}
              isAdmin={isAdmin}
              onDeleteUser={handleDeleteUser}
            />
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {sortOptions.feeds.local && (
          <div className="feed-section">
            <h2 className="feed-title">
              Local Feed {searchTerm && `(${filterProjects(localProjects).length})`}
            </h2>
            <p className="text-gray-300 mb-4 text-sm">Projects you're collaborating on</p>
            <LocalFeed 
              projects={sortProjects(filterProjects(localProjects))} 
              onHashtagClick={(tag) => setSearchTerm(tag)} 
            />
          </div>
        )}

        {sortOptions.feeds.global && (
          <div className="feed-section">
            <h2 className="feed-title">
              Global Feed {searchTerm && `(${filterProjects(globalProjects).length})`}
            </h2>
            <p className="text-gray-300 mb-4 text-sm">Discover new projects from the community</p>
            <GlobalFeed 
              projects={sortProjects(filterProjects(globalProjects))} 
              onHashtagClick={(tag) => setSearchTerm(tag)} 
            />
          </div>
        )}
      </div>

      {!searchTerm && (
        <div className="mb-8">
          <div className="feed-section">
            <h2 className="feed-title">Community Members</h2>
            <p className="text-gray-300 mb-4 text-sm">Connect with other users</p>
            <AllUsers 
              users={allUsers} 
              currentUserId={loggedInUserId}
              friends={friends}
              onAddFriend={handleAddFriend}
              isAdmin={isAdmin}
              onDeleteUser={handleDeleteUser}
            />
          </div>
        </div>
      )}

      {isAdmin && (
        <AdminControls 
          isAdmin={isAdmin}
          showDeleteProjects={true}
          onDeleteAllProjects={handleDeleteAllProjects}
        />
      )}
    </div>
  );
}

export default Home;