import React, { useState, useEffect } from "react";
import { LoginForm } from "../components/LoginForm";
import { RegisterForm } from "../components/RegisterForm";
import { motion, useScroll, useTransform } from "framer-motion";

function Splash({ setCurrentUser }) {
  const [showRegister, setShowRegister] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  
  const { scrollYProgress } = useScroll();
  
  const y1 = useTransform(scrollYProgress, [0, 1], [0, -200]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -400]);
  const y3 = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.8]);

  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({
        x: (e.clientX - window.innerWidth / 2) / 50,
        y: (e.clientY - window.innerHeight / 2) / 50,
      });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <div className="min-h-screen bg-bgMain overflow-x-hidden">
      <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-animated-gradient -z-10" />
        
        <motion.div
          style={{
            x: mousePosition.x * 2,
            y: mousePosition.y * 2,
          }}
          className="absolute top-20 left-20 w-64 h-64 bg-accent1/30 rounded-full blur-3xl animate-pulse"
        />
        <motion.div
          style={{
            x: mousePosition.x * -1.5,
            y: mousePosition.y * -1.5,
          }}
          className="absolute bottom-40 right-20 w-96 h-96 bg-accent2/30 rounded-full blur-3xl animate-pulse"
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear",
          }}
        />
        <motion.div
          style={{
            x: mousePosition.x * 1,
            y: mousePosition.y * 1,
          }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent3/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
          }}
        />

        <motion.div
          style={{ y: y1 }}
          className="absolute top-32 right-1/4"
          animate={{
            rotate: [0, 360],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
          }}
        >
          <div className="w-20 h-20 border-4 border-accent1/50 rotate-45" />
        </motion.div>
        
        <motion.div
          style={{ y: y2 }}
          className="absolute bottom-40 left-1/4"
          animate={{
            rotate: [360, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          <div className="w-16 h-16 rounded-full border-4 border-accent2/50" />
        </motion.div>

        <motion.div
          style={{ opacity, scale }}
          className="relative z-10 text-center px-4"
        >
          <motion.div
            initial={{ opacity: 0, y: -100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <motion.h1
              className="text-7xl md:text-9xl font-extrabold mb-4"
              style={{
                background: "linear-gradient(135deg, var(--accent1), var(--accent2), var(--accent3))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
              animate={{
                backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
              }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: "linear",
              }}
            >
              beBold
            </motion.h1>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="text-xl md:text-2xl text-accent3 font-bold mb-8"
          >
            Where Innovation Meets Collaboration
          </motion.p>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 1 }}
            className="text-base md:text-lg max-w-2xl mx-auto mb-12 text-white/90 leading-relaxed"
          >
            Experience the luxury of effortless productivity. Create, share, and collaborate 
            on digital products with unparalleled ease. Transform your ideas into reality. 
            Make version-control memorable, through the beBold experience. 
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2, duration: 1 }}
            className="flex flex-col items-center gap-2"
          >
            <span className="text-accent2 text-sm font-semibold">Scroll to explore</span>
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-6 h-10 border-2 border-accent2 rounded-full flex justify-center pt-2"
            >
              <motion.div
                animate={{ y: [0, 12, 0], opacity: [1, 0, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="w-1.5 h-1.5 bg-accent2 rounded-full"
              />
            </motion.div>
          </motion.div>
        </motion.div>
      </section>

      <section className="relative py-20 bg-layer/50">
        <motion.div
          style={{ y: y3 }}
          className="container mx-auto px-4"
        >
          <motion.h2
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold text-accent1 text-center mb-16"
          >
            Why Choose beBold?
          </motion.h2>

          <div className="grid md:grid-cols-3 gap-8 mb-20">
            {[
              {
                icon: "⚡",
                title: "Lightning Fast",
                description: "Streamlined workflows that keep you moving at the speed of innovation",
                color: "accent1",
                delay: 0.2,
              },
              {
                icon: "🤝",
                title: "Seamless Collaboration",
                description: "Work together in real-time with your team, anywhere in the world",
                color: "accent2",
                delay: 0.4,
              },
              {
                icon: "🎨",
                title: "Beautiful Design",
                description: "Intuitive interfaces that make complex tasks feel effortless",
                color: "accent3",
                delay: 0.6,
              },
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: feature.delay, duration: 0.8 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05, rotateY: 5 }}
                className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 hover:border-accent1/50 transition-all"
              >
                <motion.div
                  animate={{
                    rotate: [0, 10, -10, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    delay: index * 0.5,
                  }}
                  className="text-6xl mb-4"
                >
                  {feature.icon}
                </motion.div>
                <h3 className={`text-2xl font-bold text-${feature.color} mb-3`}>
                  {feature.title}
                </h3>
                <p className="text-white/80">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      <section className="relative py-20 bg-bgMain overflow-hidden">
        <motion.div
          className="absolute inset-0 opacity-10"
          animate={{
            backgroundPosition: ["0% 0%", "100% 100%"],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            repeatType: "reverse",
          }}
          style={{
            backgroundImage: "linear-gradient(45deg, var(--accent1) 25%, transparent 25%, transparent 75%, var(--accent2) 75%, var(--accent2))",
            backgroundSize: "40px 40px",
          }}
        />

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid md:grid-cols-3 gap-12">
            {[
              { number: "1000+", label: "Projects Created", color: "accent1" },
              { number: "500+", label: "Active Collaborators", color: "accent2" },
              { number: "10k+", label: "Files Shared", color: "accent3" },
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.2, duration: 0.5 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  className={`text-5xl md:text-6xl font-extrabold text-${stat.color} mb-2`}
                >
                  {stat.number}
                </motion.div>
                <div className="text-white/80 text-lg">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="relative py-20 bg-layer">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="max-w-md mx-auto"
          >
            <motion.h2
              className="text-3xl font-bold text-center mb-8 text-accent3"
              animate={{
                textShadow: [
                  "0 0 20px rgba(178, 225, 49, 0.5)",
                  "0 0 40px rgba(178, 225, 49, 0.8)",
                  "0 0 20px rgba(178, 225, 49, 0.5)",
                ],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
            >
              {showRegister ? "Join the Movement" : "Welcome Back"}
            </motion.h2>

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="bg-white/10 backdrop-blur-xl rounded-2xl p-8 shadow-2xl border border-white/20"
            >
              {showRegister ? (
                <RegisterForm
                  onSwitchToLogin={() => setShowRegister(false)}
                  setCurrentUser={setCurrentUser}
                />
              ) : (
                <LoginForm
                  onSwitchToRegister={() => setShowRegister(true)}
                  setCurrentUser={setCurrentUser}
                />
              )}
            </motion.div>
          </motion.div>
        </div>
      </section>

      <footer className="relative py-12 bg-bgMain border-t border-white/10">
        <motion.div
          animate={{
            y: [0, -10, 0],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
          }}
          className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2"
        >
          <div className="w-20 h-20 bg-accent1/20 rounded-full blur-xl" />
        </motion.div>
        
        <div className="text-center text-white/60">
          <p className="text-lg mb-2">Made with 💜 by beBold Team</p>
          <p className="text-sm">© 2025 beBold. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default Splash;