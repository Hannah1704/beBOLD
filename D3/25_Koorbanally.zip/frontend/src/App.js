import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";

import Home from "./pages/Home";
import Projects from "./pages/Projects";
import Profile from "./pages/Profile";
import Splash from "./pages/Splash";
import ProjectDetails from "./components/ProjectDetails";
import UserView from "./pages/UserView";

import { NavBar } from "./components/NavBar";

function AppWrapper() {
  return (
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
}

function App() {
  const location = useLocation();
  const hideNav = location.pathname === "/";

  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) setCurrentUser(user);
  }, []);

  return (
    <div>
      {!hideNav && currentUser && <NavBar currentUser={currentUser} />}

      <Routes>
        <Route path="/" element={<Splash setCurrentUser={setCurrentUser} />} />
        <Route path="/home" element={<Home currentUser={currentUser} />} />
        <Route path="/profile/:id" element={<Profile currentUser={currentUser} />} />
        <Route path="/projects" element={<Projects currentUser={currentUser} />} />
        <Route path="/projects/:id" element={<ProjectDetails currentUser={currentUser} />} />
        <Route path="/user/:id" element={<UserView currentUser={currentUser} />} />
        <Route path="/project/:id" element={<ProjectDetails currentUser={currentUser} />} />
      </Routes>

    </div>
  );
}

export default AppWrapper;