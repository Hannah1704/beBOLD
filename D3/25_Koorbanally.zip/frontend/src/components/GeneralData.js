import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";

function GeneralData({ user, setUser }) {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef(null);

  const [formData, setFormData] = useState({
    username: user.username || "",
    password: user.password || "",
    pronouns: user.pronouns || "",
    birthday: user.birthday || "",
    work: user.work || "",
    contact: user.contact || "",
    image: user.image || "/assets/images/default.png",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setDragActive(false);
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await handleImageUpload(e.dataTransfer.files[0]);
    }
  };

  const handleImageClick = () => {
    if (isEditing && fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = async (e) => {
    if (e.target.files && e.target.files[0]) {
      await handleImageUpload(e.target.files[0]);
    }
  };

  const handleImageUpload = async (file) => {
    try 
    {
      const data = new FormData();
      data.append("image", file);

      const res = await fetch("/api/upload", { method: "POST", body: data });
      const json = await res.json();

      if(json.success) 
      {
        setFormData((prev) => ({ ...prev, image: json.path }));
      } 
      else 
      {
        console.error("Upload failed:", json.message);
      }
    } 
    catch(err) 
    {
      console.error("Upload error:", err);
    }
  };

  const handleSave = async () => {
    try 
    {
      const { _id, ...userData } = formData;
      const res = await fetch(`/api/users/${user._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userData),
      });
      const data = await res.json();

      if(data.success) 
      {
        setUser(data.user);
        setIsEditing(false);
      } 
      else 
      {
        console.error("Server error:", data.message);
      }
    } 
    catch(err) 
   {
      console.error("Server error:", err);
    }
  };

  const handleDelete = async () => {
    const confirmed = window.confirm(
      "Are you sure you want to delete your account? This action cannot be undone."
    );

    if (!confirmed) return;

    try 
    {
      const res = await fetch(`/api/users/${user._id}`, { method: "DELETE" });
      const data = await res.json();

      if(data.success) 
      {
        alert("Account deleted successfully");
        localStorage.removeItem("user");
        navigate("/");
      } 
      else 
      {
        alert("Error deleting account: " + data.message);
      }
    } 
    catch(err) 
    {
      console.error("Error deleting user:", err);
      alert("Error deleting account");
    }
  };

  return (
    <div className="general-data-card max-w-md mx-auto">

      <div
        className={`relative profile-img-wrapper mx-auto ${
          dragActive ? "ring-4 ring-accent2" : "hover:ring-2 hover:ring-accent1"
        } transition-all duration-300 rounded-full cursor-pointer`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleImageClick}
      >
        <img
          className="profile-img w-28 h-28 rounded-full object-cover shadow-lg"
          src={formData.image}
          alt="Profile"
        />
        {isEditing && (
          <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center rounded-full transition-opacity duration-200">
            <p className="text-white text-sm text-center px-2">
              Drag & Drop or Click to Change
            </p>
          </div>
        )}
      </div>
      <input
        type="file"
        accept="image/*"
        ref={fileInputRef}
        onChange={handleFileChange}
        style={{ display: "none" }}
      />

 
      <div className="mt-6 space-y-4">
        {["username", "password", "pronouns", "birthday", "work", "contact"].map((field) => (
          <div key={field} className="flex flex-col">
            <label className="text-accent1 font-semibold mb-1">
              {field.charAt(0).toUpperCase() + field.slice(1)}:
            </label>
            {isEditing ? (
              <input
                className="profile-input w-full"
                type={field === "password" ? "password" : field === "birthday" ? "date" : "text"}
                name={field}
                value={formData[field]}
                onChange={handleChange}
              />
            ) : (
              <p className="profile-text bg-white text-black px-3 py-2 rounded-md mb-2">
                {field === "password" ? "*".repeat(formData.password.length) : formData[field]}
              </p>
            )}
          </div>
        ))}
      </div>

      <div className="flex justify-between mt-6">
        <button
          className="profile-button flex-1 mr-2"
          onClick={isEditing ? handleSave : () => setIsEditing(true)}
        >
          {isEditing ? "Save" : "Edit"}
        </button>
        <button className="profile-button delete-button flex-1 ml-2 bg-red-500 hover:bg-red-600">
          Delete Account
        </button>
      </div>
    </div>

  );
}

export { GeneralData };
