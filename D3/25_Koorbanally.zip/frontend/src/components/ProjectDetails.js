import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { OwnerAbilities } from "./OwnerAbilities";
import { MemberAbilities } from "./MemberAbilities";
import { ViewerAbilities } from "./ViewerAbilities";
import { AdminDiscussionEditor } from "./AdminDiscussionEditor";

function ProjectDetails({ currentUser }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userMap, setUserMap] = useState({}); 
  const [checkinMessages, setCheckinMessages] = useState({});
  const [isAdmin, setIsAdmin] = useState(false);

  const getIdString = (obj) => {
    if (!obj) return null;
    if (typeof obj === "string") return obj;
    if (obj.$oid) return obj.$oid;
    if (obj._id?.$oid) return obj._id.$oid;
    if (obj._id) return obj._id.toString();
    return obj.toString();
  };

  const fetchProject = async () =>{
    try 
    {
      const res = await fetch(`/api/projects/${id}`);
      const data = await res.json();
      if (data.success) setProject(data.project);
      else alert("Project not found");
    } 
    catch (err) {
      console.error(err);
      alert("Server error fetching project");
    }
  };

  useEffect(() => {
    const checkAdminStatus = async () => {
      if (!currentUser || !currentUser.id) return;
      try {
        const res = await fetch(`/api/users/${getIdString(currentUser.id)}/is-admin`);
        const data = await res.json();
        if(data.success) 
        {
          setIsAdmin(data.isAdmin);
        }
      } 
      catch (err) {
        console.error("Error checking admin status:", err);
      }
    };
    checkAdminStatus();
  }, [currentUser]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await fetchProject();
      setLoading(false);
    })();
  }, [id]);

  useEffect(() => {
    const loadUsernames = async () => {
      if (!project) return;

      const ids = [
        ...(project.activity?.map(a => getIdString(a.userId)) || []),
        ...(project.discussion?.map(d => getIdString(d.userId)) || []),
        ...(project.checkedOutFiles?.map(c => getIdString(c.userId)) || [])
      ].filter(Boolean);

      const unique = [...new Set(ids)];
      if (unique.length === 0) return;

      try 
      {
        const res = await fetch("/api/users/by-ids", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ids: unique })
        });
        const data = await res.json();
        if (data.success) {
          const map = {};
          data.users.forEach(u => {
            const key = getIdString(u._id);
            map[key] = u.username;
          });
          setUserMap(map);
        }
      } catch (err) {
        console.error("Error fetching usernames:", err);
      }
    };
    loadUsernames();
  }, [project]);

  useEffect(() => {
    if (!currentUser || !currentUser.friends) return;
    
    const friendMap = {};
    currentUser.friends.forEach(f => {
      if (typeof f === 'object' && f.username) {
        const fid = getIdString(f._id || f);
        friendMap[fid] = f.username;
      }
    });
    
    setUserMap(prev => ({ ...prev, ...friendMap }));
  }, [currentUser]);

  if (loading) return <p className="text-white p-6 font-montserrat">Loading project...</p>;
  if (!project) return <p className="text-white p-6 font-montserrat">Project not found</p>;

  const currentUserId = getIdString(currentUser.id);
  const ownerId = getIdString(project.owner);
  const memberIds = (project.memberIds || []).map(getIdString).filter(Boolean);

  let role = "Viewer";
  if (currentUserId) {
    if (isAdmin) role = "Admin";
    else if (ownerId && currentUserId === ownerId) role = "Owner";
    else if (memberIds.includes(currentUserId)) role = "Member";
  }

  const isOwner = role === "Owner";
  const isMember = role === "Member";
  const isAdminUser = role === "Admin";

  const handleDeleteProject = async () => {
    if (!window.confirm("Are you sure you want to delete this project? This action cannot be undone.")) return;
    const projectIdStr = getIdString(project._id);
    const res = await fetch(`/api/projects/${projectIdStr}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) {
      alert("Project deleted");
      navigate("/projects");
    } else alert(data.message);
  };

  const handleRemoveMember = async (memberId) => {
    try 
    {
      const res = await fetch(`/api/projects/${getIdString(project._id)}/remove-member`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ memberId }),
      });
      const data = await res.json();
      if(data.success) 
      {
        alert("Member removed");
        await fetchProject();
      } else alert(data.message);
    } 
    catch (err) 
    {
      console.error(err);
      alert("Error removing member");
    }
  };

  const handleTransferOwnership = async (newOwnerId) => {
    try 
    {
      const res = await fetch(`/api/projects/${getIdString(project._id)}/transfer-ownership`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ newOwnerId }),
      });
      const data = await res.json();
      if (data.success) {
        alert("Ownership transferred");
        await fetchProject();
      } else alert(data.message);
    } 
    catch (err) 
    {
      console.error(err);
      alert("Error transferring ownership");
    }
  };

  const handleCheckOut = async (fileName) => {
    try 
    {
      const res = await fetch(`/api/projects/${getIdString(project._id)}/files/check-out`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileName, userId: currentUserId })
      });
      const data = await res.json();
      if(data.success) 
      {
        await fetchProject();
      } else {
        alert("Error checking out file: " + data.message);
      }
    } 
    catch (err) 
    {
      console.error(err);
      alert("Server error checking out file");
    }
  };

  const handleCheckIn = async (fileName) => {
    try 
    {
      const message = checkinMessages[fileName] || "";
      const res = await fetch(`/api/projects/${getIdString(project._id)}/files/check-in`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileName, userId: currentUserId, message })
      });
      const data = await res.json();
      if(data.success) 
      {
        setCheckinMessages(prev => ({ ...prev, [fileName]: "" }));
        await fetchProject();
      } 
      else {
        alert("Error checking in file: " + data.message);
      }
    } 
    catch (err) {
      console.error(err);
      alert("Server error checking in file");
    }
  };

  const checkedMap = {};
  (project.checkedOutFiles || []).forEach(c => {
    const uid = getIdString(c.userId);
    checkedMap[c.fileName] = { userId: uid, timestamp: c.timestamp };
  });

  const getUsernameForId = (id) => userMap[id] || id;

  return (
    <div className="bg-layer text-white p-6 rounded-xl mb-6 font-montserrat">
      {isAdminUser && (
        <div className="bg-yellow-500 text-black px-4 py-2 rounded-lg mb-4 font-bold flex items-center gap-2">
          <span>⚡</span>
          <span>ADMIN MODE - Full Control Enabled</span>
        </div>
      )}

      <h2 className="text-accent1 font-bold text-3xl mb-4 font-montserrat">{project.name} ({project.type})</h2>
      <img src={project.image} alt="project" className="w-48 h-48 object-cover rounded-md mb-4" />

      <h3 className="text-white mb-2 font-montserrat">You are: <span className="text-accent2 font-bold">{role}</span></h3>
      <p className="text-white mb-2 font-montserrat"><strong>Owner:</strong> {project.ownerName}</p>
      <p className="text-white mb-2 font-montserrat"><strong>Description:</strong> {project.description}</p>
      <p className="text-white mb-2 font-montserrat"><strong>Status:</strong> {project.status}</p>
      <p className="text-white mb-2 font-montserrat"><strong>Version:</strong> {project.version}</p>
      <p className="text-white mb-2 font-montserrat"><strong>Popularity:</strong> {project.popularity}, <strong>Downloads:</strong> {project.downloads}</p>
      <p className="text-white mb-2 font-montserrat">
        <strong>Hashtags:</strong> {project.hashtags?.map((tag, i) => (
          <span key={i} className="text-accent3 mr-2 cursor-pointer hover:underline font-montserrat">#{tag}</span>
        ))}
      </p>
      <p className="text-white mb-2 font-montserrat"><strong>Members:</strong> {project.memberNames?.join(", ") || "None"}</p>

      <h3 className="text-accent2 font-bold text-2xl mt-6 mb-3 font-montserrat">Files</h3>
      <div className="border border-gray-500 p-4 rounded-md mb-4">
        {!project.files || project.files.length === 0 ? (
          <p className="text-gray-300 font-montserrat">No files</p>
        ) : project.files.map((file) => {

          const fileName = typeof file === 'string' ? file : file.name;
          const filePath = typeof file === 'string' ? null : file.path;
          
          const co = checkedMap[fileName];
          const isCheckedOut = !!co;
          const checkedBy = co ? co.userId : null;
          const canCheckIn = isCheckedOut && (checkedBy === currentUserId || ownerId === currentUserId || isAdminUser);
          
          return (
            <div key={fileName} className="mb-3 font-montserrat">
              <strong className="text-white font-montserrat">{fileName}</strong>
              {filePath && <span className="text-gray-400 text-sm ml-2">({filePath})</span>}
              {" — "}
              <span className="ml-2 text-gray-300 italic font-montserrat">
                {isCheckedOut ? `Checked out by ${getUsernameForId(checkedBy)}` : "Available"}
              </span>
              <div className="mt-2 flex items-center gap-2">
                {filePath && (
                  <a 
                    href={filePath} 
                    download={fileName}
                    className="bg-green-600 text-white px-3 py-1 rounded-md hover:bg-green-700 font-montserrat inline-block"
                  >
                    Download
                  </a>
                )}
                
                {!isCheckedOut ? (
                  (isMember || isOwner || isAdminUser) && (
                    <button onClick={() => handleCheckOut(fileName)} className="bg-accent1 text-white px-3 py-1 rounded-md hover:bg-accent2 font-montserrat">
                      Check out
                    </button>
                  )
                ) : (
                  canCheckIn && (
                    <>
                      <input
                        placeholder="Check-in message (optional)"
                        value={checkinMessages[fileName] || ""}
                        onChange={(e) => setCheckinMessages(prev => ({ ...prev, [fileName]: e.target.value }))}
                        className="px-2 py-1 rounded-md border border-gray-400 bg-white text-black font-montserrat"
                      />
                      <button onClick={() => handleCheckIn(fileName)} className="bg-accent1 text-white px-3 py-1 rounded-md hover:bg-accent2 font-montserrat">
                        Check in
                      </button>
                    </>
                  )
                )}
              </div>
            </div>
          );
        })}
      </div>

      <h3 className="text-accent2 font-bold text-2xl mt-6 mb-3 font-montserrat">Activity</h3>
      <ul className="list-disc list-inside mb-4 font-montserrat">
        {!project.activity || project.activity.length === 0 ? (
          <li className="text-gray-300">No activity yet</li>
        ) : project.activity.map((act, i) => (
          <li key={i} className="mb-2 text-white font-montserrat">
            {getUsernameForId(getIdString(act.userId))}: {act.action} - {act.message} ({new Date(act.timestamp?.$date || act.timestamp).toLocaleString()})
          </li>
        ))}
      </ul>

      <h3 className="text-accent2 font-bold text-2xl mt-6 mb-3 font-montserrat">Discussion</h3>
      {isAdminUser ? (
        <AdminDiscussionEditor
          isAdmin={isAdminUser}
          discussion={project.discussion || []}
          projectId={getIdString(project._id)}
          currentUserId={currentUserId}
          onUpdate={fetchProject}
        />
      ) : (
        <ul className="list-disc list-inside mb-4 font-montserrat">
          {!project.discussion || project.discussion.length === 0 ? (
            <li className="text-gray-300">No discussion yet</li>
          ) : project.discussion.map((d, i) => (
            <li key={i} className="mb-2 text-white font-montserrat">
              {getUsernameForId(getIdString(d.userId))}: {d.text}
            </li>
          ))}
        </ul>
      )}

      {isAdminUser && (
        <OwnerAbilities 
          project={project} 
          setProject={setProject} 
          handleRemoveMember={handleRemoveMember} 
          handleTransferOwnership={handleTransferOwnership} 
          handleDeleteProject={handleDeleteProject}
          currentUser={currentUser}
        />
      )}
      {isOwner && !isAdminUser && (
        <OwnerAbilities 
          project={project} 
          setProject={setProject} 
          handleRemoveMember={handleRemoveMember} 
          handleTransferOwnership={handleTransferOwnership} 
          handleDeleteProject={handleDeleteProject}
          currentUser={currentUser}
        />
      )}
      {isMember && !isOwner && !isAdminUser && (
        <MemberAbilities 
          project={project} 
          currentUser={currentUser} 
          currentUserId={currentUserId} 
          userMap={userMap} 
          fetchProject={fetchProject} 
        />
      )}
      {!isMember && !isOwner && !isAdminUser && <ViewerAbilities project={project} />}
    </div>
  );
}

export default ProjectDetails;