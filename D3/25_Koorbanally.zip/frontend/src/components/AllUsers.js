import React from "react";
import { useNavigate } from "react-router-dom";

function AllUsers({ users, currentUserId, friends, onAddFriend, isAdmin, onDeleteUser }) {
  const navigate = useNavigate();
  const friendIds = (friends || []).map(f => f._id || f);

  const handleDeleteUser = async (userId, username) => {
    if(!confirm(`Are you sure you want to delete ${username}? This action cannot be undone!`)) 
    {
      return;
    }

    try 
    {
      const res = await fetch(`/api/users/${userId}`, {
        method: "DELETE"
      });
      const data = await res.json();
      
      if(data.success) 
      {
        alert(`User ${username} deleted successfully!`);
        if (onDeleteUser) onDeleteUser(userId);
      } 
      else 
      {
        alert("Error deleting user: " + data.message);
      }
    } 
    catch(err) 
    {
      console.error(err);
      alert("Error deleting user");
    }
  };

  return (
    <div className="space-y-3">
      {users.map((user) => {
        const isFriend = friendIds.includes(user._id);
        const isCurrentUser = user._id === currentUserId;
        const isUserAdmin = user.isAdmin === true;

        return (
          <div
            key={user._id}
            className="bg-white text-black rounded-lg p-4 flex items-center justify-between hover:shadow-md transition-shadow"
          >
            <div
              className="flex items-center gap-3 flex-1 cursor-pointer"
              onClick={() => navigate(`/user/${user._id}`)}
            >
              <img
                src={user.image || "/assets/images/default.png"}
                alt={user.username}
                className="w-12 h-12 rounded-full object-cover"
              />
              <div>
                <p className="font-bold text-accent1">
                  {user.username}
                  {isUserAdmin && <span className="ml-2 text-red-500 text-sm">👑 Admin</span>}
                </p>
                <p className="text-sm text-gray-600">{user.work || "No work info"}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isCurrentUser ? (
                <span className="text-accent3 font-semibold text-sm">You</span>
              ) : isFriend ? (
                <span className="text-green-600 font-semibold text-sm">✓ Friends</span>
              ) : (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddFriend(user._id);
                  }}
                  className="bg-accent1 text-white px-3 py-1 rounded text-sm hover:bg-accent2"
                >
                  Add Friend
                </button>
              )}

              {isAdmin && !isUserAdmin && !isCurrentUser && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteUser(user._id, user.username);
                  }}
                  className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600 ml-2"
                  title="Delete User (Admin)"
                >
                  🗑️
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

export { AllUsers };