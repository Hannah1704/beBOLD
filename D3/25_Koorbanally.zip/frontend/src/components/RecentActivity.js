import React from "react";

function RecentActivity({ activities }) {
  if (!activities || activities.length === 0) 
  {
    return (
      <div className="text-center py-8">
        <p className="text-gray-400">No recent activity yet</p>
        <p className="text-gray-500 text-sm mt-2">Start contributing to projects to see your activity here!</p>
      </div>
    );
  }

  return (
    <div className="activity-list space-y-3 max-h-96 overflow-y-auto">
      {activities.map((activity, index) => (
        <div key={index} className="activity-item border-l-4 border-accent1">
          <div className="flex justify-between items-start mb-2">
            <span className="font-bold text-accent1 capitalize">{activity.action}</span>
            <span className="text-xs text-gray-500">
              {new Date(activity.timestamp).toLocaleDateString()}
            </span>
          </div>
          <p className="text-sm mb-1">{activity.message}</p>
          <p className="text-xs text-gray-600">📁 {activity.projectName}</p>
        </div>
      ))}
    </div>
  );
}

export { RecentActivity };