import React, { useState } from "react";

function SearchBar({ onSearch }) {
  const [query, setQuery] = useState("");

  const handleChange = (e) => {
    setQuery(e.target.value);
    onSearch(e.target.value);
  };

  const handleClear = () => {
    setQuery("");
    onSearch("");
  };

  return (
    <div className="relative">
      <div className="search-bar flex items-center gap-2">
        <input
          type="text"
          placeholder="Search projects, users, hashtags..."
          value={query}
          onChange={handleChange}
          className="flex-1"
        />
        {query && (
          <button
            onClick={handleClear}
            className="bg-red-500 text-white px-3 py-2 rounded-md hover:bg-red-600"
          >
            Clear
          </button>
        )}
      </div>
    </div>
  );
}

export { SearchBar };