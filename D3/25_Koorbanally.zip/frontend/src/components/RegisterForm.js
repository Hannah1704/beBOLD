import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function RegisterForm({ onSwitchToLogin, setCurrentUser }) {
  const [form, setForm] = useState({
    email: "",
    username: "",
    password: "",
    confirm: "",
    pronouns: "",
    birthday: "",
    work: "",
    contact: "",
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validate = () => {
    let newErrors = {};
    if (!form.email) newErrors.email = "Email is required";
    if (!form.username) newErrors.username = "Username is required";
    if (form.password.length < 6)
      newErrors.password = "Password must be at least 6 characters";
    if (form.password !== form.confirm)
      newErrors.confirm = "Passwords do not match";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try 
    {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await response.json();

      if(data.success) 
      {
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));
        setCurrentUser(data.user);
        navigate("/home");
      }
      else 
      {
        setErrors({ form: data.message || "Registration failed" });
      }
    } 
    catch (err) 
    {
      setErrors({ form: "Server error" });
    }
  };

  return (
  <main className="bg-layer p-8 rounded-xl shadow-lg max-w-md mx-auto">
    <h1 className="text-3xl font-extrabold mb-6 text-accent1">Register</h1>

    {errors.form && <p className="text-red-500 mb-4">{errors.form}</p>}

    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="email" className="block font-semibold mb-1">Email:</label>
        <input
          type="text"
          name="email"
          id="email"
          value={form.email}
          onChange={handleChange}
          required
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
        {errors.email && <p className="text-red-500 mt-1">{errors.email}</p>}
      </div>

      <div>
        <label htmlFor="username" className="block font-semibold mb-1">Username:</label>
        <input
          type="text"
          name="username"
          id="username"
          value={form.username}
          onChange={handleChange}
          required
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
        {errors.username && <p className="text-red-500 mt-1">{errors.username}</p>}
      </div>

      <div>
        <label htmlFor="password" className="block font-semibold mb-1">Password:</label>
        <input
          type="password"
          name="password"
          id="password"
          value={form.password}
          onChange={handleChange}
          required
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
        {errors.password && <p className="text-red-500 mt-1">{errors.password}</p>}
      </div>

      <div>
        <label htmlFor="confirm" className="block font-semibold mb-1">Confirm Password:</label>
        <input
          type="password"
          name="confirm"
          id="confirm"
          value={form.confirm}
          onChange={handleChange}
          required
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
        {errors.confirm && <p className="text-red-500 mt-1">{errors.confirm}</p>}
      </div>

      <div>
        <label htmlFor="pronouns" className="block font-semibold mb-1">Pronouns:</label>
        <input
          type="text"
          name="pronouns"
          id="pronouns"
          value={form.pronouns}
          onChange={handleChange}
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
      </div>

      <div>
        <label htmlFor="birthday" className="block font-semibold mb-1">Birthday:</label>
        <input
          type="date"
          name="birthday"
          id="birthday"
          value={form.birthday}
          onChange={handleChange}
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
      </div>

      <div>
        <label htmlFor="work" className="block font-semibold mb-1">Work:</label>
        <input
          type="text"
          name="work"
          id="work"
          value={form.work}
          onChange={handleChange}
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
      </div>

      <div>
        <label htmlFor="contact" className="block font-semibold mb-1">Contact:</label>
        <input
          type="text"
          name="contact"
          id="contact"
          value={form.contact}
          onChange={handleChange}
          className="w-full p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-accent2"
        />
      </div>

      <button
        type="submit"
        className="w-full bg-accent1 text-white font-bold py-3 rounded-lg hover:bg-accent2 transition-colors"
      >
        Register
      </button>
    </form>

    <p className="mt-4 text-center">
      Already have an account?{" "}
      <button
        type="button"
        onClick={onSwitchToLogin}
        className="text-accent3 font-semibold hover:underline"
      >
        Login
      </button>
    </p>
  </main>
);

}

export { RegisterForm };