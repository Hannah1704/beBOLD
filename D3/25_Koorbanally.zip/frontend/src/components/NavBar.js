import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

function NavBar({ currentUser }) {
  const location = useLocation();
  const [isAdmin, setIsAdmin] = useState(false);
  const isActive = (path) => location.pathname.startsWith(path);

  useEffect(() => {
    async function checkAdmin() {
      if(!currentUser?.id) return;
      
      try 
      {
        const res = await fetch(`/api/users/${currentUser.id}/is-admin`);
        const data = await res.json();
        if (data.success) {
          setIsAdmin(data.isAdmin);
      }
      } 
      catch (err) 
      {
        console.error("Error checking admin status:", err);
      }
    }
    checkAdmin();
  }, [currentUser]);

  return (
    <nav className="professional-nav">
      <Link to="/home" className="nav-logo-section">
        <div className="nav-logo">
          <span className="logo-be">Be</span>
          <span className="logo-bold">BOLD</span>
        </div>
      </Link>

      <div className="nav-links-container">
        <Link
          to="/home"
          className={`nav-link-professional ${isActive("/home") ? "active-link-professional" : ""}`}
        >
          <span className="nav-icon">🏠</span>
          <span>Home</span>
        </Link>

        <Link
          to={`/profile/${currentUser.id}`}
          className={`nav-link-professional ${isActive("/profile") ? "active-link-professional" : ""}`}
        >
          <span className="nav-icon">👤</span>
          <span>Profile</span>
        </Link>

        <Link
          to="/projects"
          className={`nav-link-professional ${isActive("/projects") ? "active-link-professional" : ""}`}
        >
          <span className="nav-icon">📁</span>
          <span>Projects</span>
        </Link>
      </div>

      <div className="nav-user-section">
        {isAdmin && (
          <div className="admin-badge" title="Administrator">
            👑
          </div>
        )}
        <div className="user-info">
          <span className="username-display">{currentUser.username}</span>
        </div>
        <Link to="/" className="logout-button">
          <span className="nav-icon">🚪</span>
          <span>Logout</span>
        </Link>
      </div>
    </nav>
  );
}

export { NavBar };