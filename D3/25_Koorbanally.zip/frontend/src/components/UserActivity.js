import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function UserActivity({ user }) {
  const navigate = useNavigate();
  const [activities, setActivities] = useState([]);
  const [projects, setProjects] = useState([]);
  const [allUsers, setAllUsers] = useState([]);

  useEffect(() => {
    async function fetchUsers() {
      try 
      {
        const res = await fetch("/api/users");
        const data = await res.json();
        if (data.success) setAllUsers(data.users);
      } 
      catch (err) {
        console.error(err);
      }
    }

    fetchUsers();
  }, []);

  useEffect(() => {
    async function fetchUserActivity() {
      try 
      {
        const res = await fetch(`/api/users/${user._id}/activity`);
        const data = await res.json();
        if (data.success) {
          setActivities(data.activities);
          setProjects(data.projects);
        }
      } 
      catch (err) {
        console.error(err);
      }
    }
    if (user?._id) fetchUserActivity();
  }, [user]);

  const getUsername = (id) => {
    const u = allUsers.find((usr) => usr._id === id.toString());
    return u ? u.username : "Unknown";
  };

  const handleProjectClick = (projectId) => {
    navigate(`/project/${projectId}`);
  };

  const handleUserClick = (userId) => {
    navigate(`/user/${userId}`);
  };

  return (
    <div className="activity-card">
      <h2 className="section-title">{user.username}'s Activity</h2>
      {activities.length === 0 ? (
        <p className="text-gray-300">No activity yet</p>
      ) : (
        <ul className="space-y-3">
          {activities.map((act, idx) => (
            <li key={idx} className="bg-white text-black rounded-lg p-4 shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <span className="font-semibold text-accent1 capitalize">{act.action}</span>
                <span className="text-xs text-gray-500">
                  {new Date(act.timestamp).toLocaleString()}
                </span>
              </div>
              <p className="text-sm text-gray-700 mb-2">
                <strong>Message:</strong> {act.message}
              </p>
              <button
                onClick={() => handleProjectClick(act.projectId)}
                className="text-sm text-accent3 hover:underline font-semibold"
              >
                Project: {act.projectName} →
              </button>
            </li>
          ))}
        </ul>
      )}

      <h2 className="section-title mt-8">Projects Involved ({projects.length})</h2>
      {projects.length === 0 ? (
        <p className="text-gray-300">No projects yet</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.map((proj) => (
            <div
              key={proj._id}
              onClick={() => handleProjectClick(proj._id)}
              className="bg-white text-black rounded-lg p-4 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
            >
              <div className="flex items-start gap-3 mb-3">
                {proj.image && (
                  <img
                    src={proj.image}
                    alt={proj.name}
                    className="w-16 h-16 rounded-lg object-cover"
                  />
                )}
                <div className="flex-1">
                  <h3 className="font-bold text-accent1 text-lg">{proj.name}</h3>
                  <p className="text-sm text-gray-600 italic">{proj.type}</p>
                </div>
              </div>
              
              <div className="space-y-1 text-sm">
                <div>
                  <strong className="text-gray-700">Owner:</strong>{" "}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleUserClick(proj.owner);
                    }}
                    className="text-accent3 hover:underline"
                  >
                    {getUsername(proj.owner)}
                  </button>
                </div>
                
                {proj.members && proj.members.length > 0 && (
                  <div>
                    <strong className="text-gray-700">Members:</strong>{" "}
                    <span className="text-gray-600">
                      {proj.members.slice(0, 3).map((m, i) => (
                        <span key={m}>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleUserClick(m);
                            }}
                            className="text-accent3 hover:underline"
                          >
                            {getUsername(m)}
                          </button>
                          {i < Math.min(proj.members.length, 3) - 1 && ", "}
                        </span>
                      ))}
                      {proj.members.length > 3 && ` +${proj.members.length - 3} more`}
                    </span>
                  </div>
                )}
                
                <div className="flex gap-4 mt-2 text-xs text-gray-600">
                  <span>⭐ {proj.popularity}</span>
                  <span>📥 {proj.downloads}</span>
                  <span className="capitalize">{proj.status}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export { UserActivity };