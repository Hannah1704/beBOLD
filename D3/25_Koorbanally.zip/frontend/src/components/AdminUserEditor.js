import React, { useState } from "react";

export function AdminUserEditor({ isAdmin, user, onUpdate, onDelete }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    username: user.username || "",
    email: user.email || "",
    password: user.password || "",
    pronouns: user.pronouns || "",
    birthday: user.birthday || "",
    work: user.work || "",
    contact: user.contact || "",
  });

  if(!isAdmin) return null;

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    try 
    {
      const res = await fetch(`/api/admin/users/${user._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();

      if(data.success) 
      {
        alert("User information updated successfully!");
        setIsEditing(false);
        if (onUpdate) onUpdate(data.user);
      } 
      else 
      {
        alert("Error updating user: " + data.message);
      }
    } 
    catch(err) 
    {
      console.error(err);
      alert("Error updating user");
    }
  };

  const handleDelete = async () => {
    if(!confirm(`Are you sure you want to permanently delete ${user.username}? This cannot be undone!`)) 
    {
      return;
    }

    try 
    {
      const res = await fetch(`/api/users/${user._id}`, {
        method: "DELETE",
      });
      const data = await res.json();

      if(data.success) 
      {
        alert(`User ${user.username} deleted successfully!`);
        if (onDelete) onDelete();
      } 
      else 
      {
        alert("Error deleting user: " + data.message);
      }
    } 
    catch(err) 
    {
      console.error(err);
      alert("Error deleting user");
    }
  };

  return (
    <div className="bg-yellow-900/20 border-2 border-yellow-500 rounded-xl p-6 mt-6">
      <div className="flex items-center gap-3 mb-4">
        <span className="text-3xl">👑</span>
        <div>
          <h3 className="text-yellow-400 font-bold text-xl">Admin: Edit User Information</h3>
          <p className="text-yellow-300 text-sm">You can edit any user's information</p>
        </div>
      </div>

      {isEditing ? (
        <div className="space-y-4">
          {["username", "email", "password", "pronouns", "birthday", "work", "contact"].map((field) => (
            <div key={field} className="flex flex-col">
              <label className="text-yellow-200 font-semibold mb-1 capitalize">
                {field}:
              </label>
              <input
                type={field === "password" ? "password" : field === "birthday" ? "date" : "text"}
                name={field}
                value={formData[field]}
                onChange={handleChange}
                className="w-full bg-white text-black rounded-md px-4 py-2"
              />
            </div>
          ))}

          <div className="flex gap-3">
            <button
              onClick={handleSave}
              className="flex-1 bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 font-bold"
            >
              💾 Save Changes
            </button>
            <button
              onClick={() => {
                setIsEditing(false);
                setFormData({
                  username: user.username || "",
                  email: user.email || "",
                  password: user.password || "",
                  pronouns: user.pronouns || "",
                  birthday: user.birthday || "",
                  work: user.work || "",
                  contact: user.contact || "",
                });
              }}
              className="flex-1 bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 font-bold"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="flex gap-3">
          <button
            onClick={() => setIsEditing(true)}
            className="flex-1 bg-yellow-500 text-black px-4 py-2 rounded-md hover:bg-yellow-400 font-bold"
          >
            ✏️ Edit User Info
          </button>
          <button
            onClick={handleDelete}
            className="flex-1 bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 font-bold"
          >
            🗑️ Delete User
          </button>
        </div>
      )}
    </div>
  );
}