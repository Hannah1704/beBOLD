import React, { useEffect, useState } from "react";

function ViewOnlyGeneralData({ userId, currentUserId, onFriendChange }) {
  const [user, setUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [friendData, setFriendData] = useState([]);
  const [projects, setProjects] = useState([]);

  useEffect(() => {
  async function fetchUser(){
    try 
    {
      const res = await fetch(`/api/users/${userId}`);
      const data = await res.json();
      if(data.success) 
      {
        setUser(data.user);

        const friendIds = data.user.friends?.map(f => {
          if (typeof f === 'string') return f;
          if (f.$oid) return f.$oid;
          if (f._id) return f._id.toString();
          return f.toString();
        }).filter(Boolean);

        console.log('Friend IDs:', friendIds);

        if(friendIds?.length > 0) 
        {
          const friendsRes = await fetch(`/api/users/by-ids?ids=${friendIds.join(",")}`);
          const friendsData = await friendsRes.json();
          console.log('Friends response:', friendsData);
          if (friendsData.success) setFriendData(friendsData.users);
        }

        const projectIds = data.user.projects?.map(p => {
          if (typeof p === 'string') return p;
          if (p.$oid) return p.$oid;
          if (p._id) return p._id.toString();
          return p.toString();
        }).filter(Boolean);

        console.log('Project IDs:', projectIds);

        if (projectIds?.length > 0) {
          const projectsRes = await fetch(`/api/projects/by-ids?ids=${projectIds.join(",")}`);
          const projectsData = await projectsRes.json();
          console.log('Projects response:', projectsData); 

          if (projectsData.success) setProjects(projectsData.projects);
        }
      }
    } 
    catch (err) 
    {
      console.error('Error fetching user:', err);
    }
  }

  async function fetchCurrentUser() {
    try 
    {
      const res = await fetch(`/api/users/${currentUserId}`);
      const data = await res.json();
      if (data.success) setCurrentUser(data.user);
    } 
    catch (err) 
    {
      console.error('Error fetching current user:', err);
    }
  }

  if (userId) fetchUser();
  if (currentUserId) fetchCurrentUser();
}, [userId, currentUserId]);

  if (!user) return <p>User not found</p>;

  const isFriend = currentUser?.friends?.some(f => (f.$oid || f) === userId);

  const handleAddFriend = async () => {
    try 
    {
      const res = await fetch(`/api/users/${currentUserId}/friends`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ friendId: userId }),
      });
      const data = await res.json();
      if (data.success) onFriendChange?.();
    } 
    catch (err) {
      console.error(err);
    }
  };

  const handleUnfriend = async () => {
    try 
    {
      const res = await fetch(`/api/users/${currentUserId}/friends/${userId}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) onFriendChange?.();
    } 
    catch (err) 
    {
      console.error(err);
    }
  };

  return (
    <div className="general-data-card">
      <div className="flex flex-col items-center mb-4">
        <div className="profile-img-wrapper relative mb-2">
          <img
            src={user.image || "/assets/images/default.png"}
            alt={user.username}
            className="w-28 h-28 rounded-full object-cover"
          />
          <div className="overlay">
            <span className="text-accent3 font-semibold">View More</span>
          </div>
        </div>
        <p className="text-lg font-bold">{user.username}</p>
        {isFriend && <p className="text-gray-400">{user.email}</p>}
      </div>

      {isFriend && (
        <div className="mb-4">
          <p><strong>Pronouns:</strong> {user.pronouns}</p>
          <p><strong>Birthday:</strong> {user.birthday}</p>
          <p><strong>Work:</strong> {user.work}</p>
          <p><strong>Contact:</strong> {user.contact}</p>
        </div>
      )}

      {userId !== currentUserId && (
        <div className="flex gap-2 mb-4">
          {isFriend ? (
            <button onClick={handleUnfriend} className="friend-button bg-red-500 hover:bg-red-600">Unfriend</button>
          ) : (
            <button onClick={handleAddFriend} className="friend-button">Add Friend</button>
          )}
        </div>
      )}

      {isFriend && (
        <>
          {friendData.length > 0 && (
            <div className="mb-4">
              <h3 className="section-title text-xl mb-2">{user.username}'s Friends</h3>
              <ul className="friends-list grid grid-cols-2 gap-2">
                {friendData.map(f => (
                  <li key={f._id} className="friend-item flex items-center p-2 hover:bg-accent2 cursor-pointer">
                    <img src={f.image || "/assets/images/default.png"} alt={f.username} className="friend-img w-10 h-10" />
                    <span className="ml-2">{f.username}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {projects.length > 0 && (
            <div>
              <h3 className="section-title text-xl mb-2">{user.username}'s Projects</h3>
              <ul className="projects-grid">
                {projects.map(p => (
                  <li key={p._id} className="project-card">
                    <p className="project-name">{p.name || "Unnamed Project"}</p>
                    <p className="project-type">{p.type || "N/A"}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export { ViewOnlyGeneralData };