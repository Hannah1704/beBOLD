import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Friends({ user, onUserClick }) {
  const navigate = useNavigate();
  const [friends, setFriends] = useState([]);
  const [allUsers, setAllUsers] = useState([]);

  const fetchFriends = async () => {
    try 
    {
      const res = await fetch(`/api/users/${user._id}/friends`);
      const data = await res.json();
      if (data.success) setFriends(data.friends);
    } 
    catch(err) 
    {
      console.error(err);
    }
  };

  const fetchAllUsers = async () => {
    try 
    {
      const res = await fetch("/api/users");
      const data = await res.json();
      if (data.success) setAllUsers(data.users.filter((u) => u._id !== user._id));
    } 
    catch (err) 
    {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchFriends();
    fetchAllUsers();
  }, [user]);

  const handleUserClick = (userId) => {
    if(onUserClick) 
    {
      onUserClick(userId);
    } 
    else 
    {
      navigate(`/user/${userId}`);
    }
  };

  const friendIds = friends.map((f) => f._id);

  return (
    <div>
      <h2 className="text-accent2 font-bold text-xl mb-3">
        Friends ({friends.length})
      </h2>
      
      {friends.length === 0 ? (
        <p className="text-gray-300 mb-6">No friends yet - send friend requests to other users first</p>
      ) : (
        <div className="space-y-2 mb-6 max-h-64 overflow-y-auto">
          {friends.map((f) => (
            <div
              key={f._id}
              onClick={() => handleUserClick(f._id)}
              className="flex items-center gap-3 bg-white text-black rounded-lg p-3 cursor-pointer hover:shadow-md transition-shadow"
            >
              <img
                className="w-12 h-12 rounded-full object-cover"
                src={f.image || "/assets/images/default.png"}
                alt={f.username}
              />
              <div className="flex-1">
                <p className="font-semibold text-accent1">{f.username}</p>
                <p className="text-xs text-gray-600">{f.work || "No work info"}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      <h3 className="text-accent3 font-bold text-lg mb-3">
        Discover Users ({allUsers.length})
      </h3>
      <div className="space-y-2 max-h-64 overflow-y-auto">
        {allUsers.map((u) => (
          <div
            key={u._id}
            className="flex items-center justify-between bg-white text-black rounded-lg p-3"
          >
            <div
              className="flex items-center gap-3 flex-1 cursor-pointer"
              onClick={() => handleUserClick(u._id)}
            >
              <img
                className="w-10 h-10 rounded-full object-cover"
                src={u.image || "/assets/images/default.png"}
                alt={u.username}
              />
              <div>
                <p className="font-semibold text-accent1">{u.username}</p>
                <p className="text-xs text-gray-600">{u.work || "No work info"}</p>
              </div>
            </div>

            {friendIds.includes(u._id) ? (
              <span className="text-xs text-green-600 font-semibold">✓ Friends</span>
            ) : (
              <button
                className="bg-accent1 text-white px-3 py-1 rounded-md text-sm hover:bg-accent2"
                onClick={async (e) => {
                  e.stopPropagation();
                  try {
                    const res = await fetch(`/api/users/${user._id}/friends`, {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ friendId: u._id }),
                    });
                    const data = await res.json();
                    if (data.success) {
                      alert(`Friend request sent to ${u.username}`);
                      fetchFriends();
                    }
                  } catch (err) {
                    console.error(err);
                  }
                }}
              >
                Add
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export { Friends };