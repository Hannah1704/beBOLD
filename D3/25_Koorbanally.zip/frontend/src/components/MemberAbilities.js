import React, { useState, useEffect } from "react";

export function MemberAbilities({ project, currentUser, currentUserId, fetchProject }) {
  const [selectedFriends, setSelectedFriends] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [friends, setFriends] = useState([]);
  const [newFileName, setNewFileName] = useState("");
  const [editingFile, setEditingFile] = useState(null);
  const [editFileName, setEditFileName] = useState("");
  const [checkoutFileName, setCheckoutFileName] = useState("");
  const [checkinFileName, setCheckinFileName] = useState("");
  const [checkinMessage, setCheckinMessage] = useState("");

  useEffect(() => {
    fetchFriends();
  }, [currentUserId]);

  const fetchFriends = async () => {
    try 
    {
      const res = await fetch(`/api/users/${currentUserId}/friends`);
      const data = await res.json();
      if (data.success) {
        setFriends(data.friends);
      }
    } 
    catch (err) 
    {
      console.error("Error fetching friends:", err);
    }
  };

  const getIdString = (obj) => {
    if (!obj) return null;
    if (typeof obj === "string") return obj;
    if (obj.$oid) return obj.$oid;
    if (obj._id?.$oid) return obj._id.$oid;
    if (obj._id) return obj._id.toString();
    return obj.toString();
  };

  const handleAddMembers = async () => {
    if(selectedFriends.length === 0) 
    {
      alert("Please select at least one friend to add");
      return;
    }

    try 
    {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/add-members`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ memberIds: selectedFriends })
      });
      const data = await res.json();
      if(data.success) 
      {
        alert(`Successfully added ${selectedFriends.length} member(s)!`);
        setSelectedFriends([]);
        await fetchProject();
      } 
      else 
      {
        alert(data.message);
      }
    } 
    catch(err)
    {
      console.error(err);
      alert("Error adding members");
    }
  };

  const handlePostMessage = async () => {
    if (!newMessage.trim()) return;
    try 
    {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/discussion`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: currentUserId, text: newMessage })
      });
      const data = await res.json();
      if(data.success) 
      {
        setNewMessage("");
        await fetchProject();
      } 
      else 
      {
        alert(data.message);
      }
    } 
    catch(err) 
    {
      console.error(err);
      alert("Error posting discussion message");
    }
  };

  const handleAddFile = async () => {
    if(!newFileName.trim()) 
    {
      alert("Please enter a file name");
      return;
    }

    try 
    {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/files`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          fileName: newFileName,
          userId: currentUserId
        })
      });
      
      const data = await res.json();
      if(data.success) 
      {
        alert("File added successfully!");
        setNewFileName("");
        await fetchProject();
      } 
      else 
      {
        alert(data.message);
      }
    } 
    catch (err) 
    {
      console.error(err);
      alert("Error adding file");
    }
  };

  const handleDeleteFile = async (fileName) => {
    if (!confirm(`Are you sure you want to delete ${fileName}?`)) return;
    try 
    {
      const projectIdStr = getIdString(project._id);
      
      const res = await fetch(`/api/projects/${projectIdStr}/files/${encodeURIComponent(fileName)}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: currentUserId })
      });
      
      const data = await res.json();
      if(data.success) 
      {
        alert("File deleted successfully!");
        await fetchProject();
      } 
      else 
      {
        alert(data.message);
      }
    } 
    catch (err) 
    {
      console.error(err);
      alert("Error deleting file");
    }
  };

  const handleCheckOut = async () => {
    if(!checkoutFileName) 
    {
      alert("Please select a file to check out");
      return;
    }

    try 
    {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/files/check-out`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileName: checkoutFileName, userId: currentUserId })
      });
      
      const data = await res.json();
      if(data.success) 
      {
        alert(`Successfully checked out ${checkoutFileName}`);
        setCheckoutFileName("");
        await fetchProject();
      } 
      else 
      {
        alert(data.message);
      }
    } 
    catch (err)
    {
      console.error(err);
      alert("Error checking out file");
    }
  };
  const handleCheckIn = async () => {
    if(!checkinFileName) 
    {
      alert("Please select a file to check in");
      return;
    }

    try 
    {
      const projectIdStr = getIdString(project._id);
      const res = await fetch(`/api/projects/${projectIdStr}/files/check-in`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          fileName: checkinFileName, 
          userId: currentUserId,
          message: checkinMessage || `Checked in ${checkinFileName}`
        })
      });
      
      const data = await res.json();
      if(data.success) 
      {
        alert(`Successfully checked in ${checkinFileName}`);
        setCheckinFileName("");
        setCheckinMessage("");
        await fetchProject();
      } 
      else 
      {
        alert(data.message);
      }
    } 
    catch (err) 
    {
      console.error(err);
      alert("Error checking in file");
    }
  };

  const toggleFriendSelection = (friendId) => {
    setSelectedFriends(prev => 
      prev.includes(friendId) 
        ? prev.filter(id => id !== friendId)
        : [...prev, friendId]
    );
  };

  const memberIdsStr = (project.memberIds || []).map(getIdString).filter(Boolean);
  const friendsNotInProject = friends.filter(f => {
    const fid = getIdString(f._id);
    return !memberIdsStr.includes(fid);
  });

  const availableFiles = (project.files || []).map(f => typeof f === 'string' ? f : f.name);
  const checkedOutFiles = project.checkedOutFiles || [];
  const availableToCheckout = availableFiles.filter(fileName => 
    !checkedOutFiles.some(co => co.fileName === fileName)
  );
  const availableToCheckin = checkedOutFiles.filter(co => 
    getIdString(co.userId) === currentUserId
  ).map(co => co.fileName);

  return (
    <div className="bg-layer border border-accent2 p-6 rounded-lg mt-6">
      <h3 className="text-accent2 font-bold text-2xl mb-6">Member Controls</h3>

      <div className="mb-8 bg-bgMain p-4 rounded-lg">
        <h4 className="text-accent1 font-bold text-lg mb-3">Add Members (from friends)</h4>
        {friendsNotInProject.length === 0 ? (
          <p className="text-gray-300">No friends available to add.</p>
        ) : (
          <div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4 max-h-48 overflow-y-auto">
              {friendsNotInProject.map(f => {
                const fid = getIdString(f._id);
                const isSelected = selectedFriends.includes(fid);
                return (
                  <div
                    key={fid}
                    onClick={() => toggleFriendSelection(fid)}
                    className={`p-3 rounded-md cursor-pointer transition-all ${
                      isSelected 
                        ? 'bg-accent1 text-white' 
                        : 'bg-white text-black hover:bg-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input 
                        type="checkbox" 
                        checked={isSelected}
                        onChange={() => {}}
                        className="cursor-pointer"
                      />
                      <span className="text-sm font-semibold">{f.username}</span>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">{selectedFriends.length} selected</span>
              <button 
                onClick={handleAddMembers}
                disabled={selectedFriends.length === 0}
                className="bg-accent1 text-white px-6 py-2 rounded-md hover:bg-accent2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add {selectedFriends.length > 0 ? `${selectedFriends.length} ` : ''}Member{selectedFriends.length !== 1 ? 's' : ''}
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="mb-8 bg-bgMain p-4 rounded-lg">
        <h4 className="text-accent1 font-bold text-lg mb-3">File Management</h4>
        
        <div className="mb-4">
          <label className="block text-gray-300 mb-2 text-sm">Add New File</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={newFileName}
              onChange={e => setNewFileName(e.target.value)}
              placeholder="Enter file name (e.g., design.psd)"
              className="flex-1 px-3 py-2 rounded-md bg-white text-black"
            />
            <button 
              onClick={handleAddFile}
              className="bg-accent3 text-black px-4 py-2 rounded-md hover:bg-accent2"
            >
              Add File
            </button>
          </div>
        </div>

        <div className="mb-4">
          <label className="block text-gray-300 mb-2 text-sm">Current Files</label>
          {availableFiles.length === 0 ? (
            <p className="text-gray-400 text-sm">No files in project</p>
          ) : (
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {availableFiles.map((fileName, idx) => {
                const isCheckedOut = checkedOutFiles.some(co => co.fileName === fileName);
                const checkedOutBy = checkedOutFiles.find(co => co.fileName === fileName);
                return (
                  <div key={idx} className="flex justify-between items-center bg-white text-black p-2 rounded">
                    <div className="flex-1">
                      <span className="font-semibold">{fileName}</span>
                      {isCheckedOut && (
                        <span className="text-xs text-red-600 ml-2">
                          (Checked out by {getIdString(checkedOutBy?.userId) === currentUserId ? 'you' : 'another user'})
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => handleDeleteFile(fileName)}
                      className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
                    >
                      Delete
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="mb-4">
          <label className="block text-gray-300 mb-2 text-sm">Check Out File</label>
          <div className="flex gap-2">
            <select
              value={checkoutFileName}
              onChange={e => setCheckoutFileName(e.target.value)}
              className="flex-1 px-3 py-2 rounded-md bg-white text-black"
            >
              <option value="">Select file to check out</option>
              {availableToCheckout.map((fileName, idx) => (
                <option key={idx} value={fileName}>{fileName}</option>
              ))}
            </select>
            <button 
              onClick={handleCheckOut}
              disabled={!checkoutFileName}
              className="bg-accent1 text-white px-4 py-2 rounded-md hover:bg-accent2 disabled:opacity-50"
            >
              Check Out
            </button>
          </div>
        </div>

        <div className="mb-4">
          <label className="block text-gray-300 mb-2 text-sm">Check In File</label>
          <div className="space-y-2">
            <select
              value={checkinFileName}
              onChange={e => setCheckinFileName(e.target.value)}
              className="w-full px-3 py-2 rounded-md bg-white text-black"
            >
              <option value="">Select file to check in</option>
              {availableToCheckin.map((fileName, idx) => (
                <option key={idx} value={fileName}>{fileName}</option>
              ))}
            </select>
            <input
              type="text"
              value={checkinMessage}
              onChange={e => setCheckinMessage(e.target.value)}
              placeholder="Check-in message (optional)"
              className="w-full px-3 py-2 rounded-md bg-white text-black"
            />
            <button 
              onClick={handleCheckIn}
              disabled={!checkinFileName}
              className="w-full bg-accent1 text-white px-4 py-2 rounded-md hover:bg-accent2 disabled:opacity-50"
            >
              Check In
            </button>
          </div>
        </div>
      </div>

      <div className="bg-bgMain p-4 rounded-lg">
        <h4 className="text-accent1 font-bold text-lg mb-3">Post to Discussion</h4>
        <textarea
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          placeholder="Write a message..."
          rows={3}
          className="w-full px-3 py-2 rounded-md bg-white text-black mb-2"
        />
        <button 
          onClick={handlePostMessage}
          className="bg-accent1 text-white px-4 py-2 rounded-md hover:bg-accent2"
        >
          Post Message
        </button>
      </div>
    </div>
  );
}