import React from "react";
import { useNavigate } from "react-router-dom";

function Project({ project, onHashtagClick }) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/project/${project._id}`);
  };

  const handleHashtagClick = (e, tag) => {
    e.stopPropagation(); 
    if (onHashtagClick) onHashtagClick(tag); 
  };

  return (
    <li
      className="project-card cursor-pointer hover:shadow-lg transition-shadow"
      onClick={handleClick}
    >
      <div className="flex items-start gap-4">
        {project.image && (
          <img
            src={project.image}
            alt={project.name}
            className="w-20 h-20 rounded-lg object-cover"
          />
        )}
        <div className="flex-1">
          <strong className="project-name text-xl">{project.name}</strong>
          <br />
          <em className="project-type">{project.type}</em> – v{project.version}
          <br />
          <span className="project-status">Status: {project.status}</span>
          <br />
          {project.hashtags && project.hashtags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {project.hashtags.map((tag, index) => (
                <span
                  key={index}
                  className="bg-accent3 text-black text-xs px-2 py-1 rounded-full cursor-pointer hover:bg-accent2"
                  onClick={(e) => handleHashtagClick(e, tag)}
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
          <div className="mt-2 text-sm text-gray-600">
            <span className="project-popularity">
              ⭐ {project.popularity} | 📥 {project.downloads}
            </span>
          </div>
          {project.memberNames && project.memberNames.length > 0 && (
            <p className="text-xs text-gray-500 mt-1">
              Members: {project.memberNames.slice(0, 3).join(", ")}
              {project.memberNames.length > 3 && ` +${project.memberNames.length - 3} more`}
            </p>
          )}
        </div>
      </div>
    </li>
  );
}

export { Project };
