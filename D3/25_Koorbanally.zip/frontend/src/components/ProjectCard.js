import React, { useState } from "react";
import { Link } from "react-router-dom";

function ProjectCard({ project, onHashtagClick }) {
  const projectDate = project.date?.$date?.$numberLong || project.date;
  const formattedDate = new Date(parseInt(projectDate)).toLocaleDateString();
  const [imgError, setImgError] = useState(false);

  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 flex flex-col h-full">
      <div className="relative h-48 bg-gradient-to-br from-purple-400 to-purple-600 overflow-hidden">
        {project.image && !imgError ? (
          <img
            src={project.image}
            alt={project.name}
            className="w-full h-full object-cover"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <svg className="w-20 h-20 text-white opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
        )}
        
        <div className="absolute top-3 right-3">
          <span
            className={`px-3 py-1 rounded-full text-xs font-bold shadow-lg ${
              project.status === "Checked In" 
                ? "bg-green-500 text-white" 
                : "bg-yellow-500 text-black"
            }`}
          >
            {project.status}
          </span>
        </div>
      </div>

      <div className="p-5 flex-1 flex flex-col">
        <div className="mb-3">
          <h2 className="text-xl font-bold text-purple-700 mb-1 line-clamp-2">
            {project.name}
          </h2>
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <span className="flex items-center gap-1">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
              </svg>
              {project.type}
            </span>
            <span className="flex items-center gap-1">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              v{project.version}
            </span>
          </div>
        </div>

        {project.description && (
          <p className="text-sm text-gray-600 mb-3 line-clamp-2">
            {project.description}
          </p>
        )}

        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="bg-purple-50 rounded-lg p-2 text-center">
            <div className="text-lg font-bold text-purple-700">
              {project.popularity || 0}
            </div>
            <div className="text-xs text-gray-600">Popularity</div>
          </div>
          <div className="bg-blue-50 rounded-lg p-2 text-center">
            <div className="text-lg font-bold text-blue-700">
              {project.downloads || 0}
            </div>
            <div className="text-xs text-gray-600">Downloads</div>
          </div>
        </div>

        {project.hashtags?.length > 0 && (
          <div className="mb-3">
            <div className="flex flex-wrap gap-1">
              {project.hashtags.slice(0, 4).map((tag, i) => (
                <button
                  key={i}
                  onClick={(e) => {
                    e.preventDefault();
                    onHashtagClick(tag);
                  }}
                  className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full hover:bg-purple-200 transition-colors font-semibold"
                >
                  #{tag}
                </button>
              ))}
              {project.hashtags.length > 4 && (
                <span className="text-xs text-gray-500 px-2 py-1">
                  +{project.hashtags.length - 4} more
                </span>
              )}
            </div>
          </div>
        )}

        {project.files?.length > 0 && (
          <div className="mb-3 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <span className="font-semibold">{project.files.length} file{project.files.length !== 1 ? 's' : ''}</span>
            </div>
          </div>
        )}

        {project.memberNames?.length > 0 && (
          <div className="mb-4 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
              <span>
                {project.memberNames.slice(0, 2).join(", ")}
                {project.memberNames.length > 2 && ` +${project.memberNames.length - 2} more`}
              </span>
            </div>
          </div>
        )}

        <div className="mt-auto">
          <Link
            to={`/projects/${project._id}`}
            className="block text-center bg-gradient-to-r from-purple-600 to-purple-700 text-white font-bold px-4 py-3 rounded-lg hover:from-purple-700 hover:to-purple-800 transition-all shadow-md hover:shadow-lg"
          >
            View Details →
          </Link>
        </div>

        <div className="mt-3 pt-3 border-t border-gray-200 text-xs text-gray-500 text-center">
          Created {formattedDate}
        </div>
      </div>
    </div>
  );
}

export { ProjectCard };