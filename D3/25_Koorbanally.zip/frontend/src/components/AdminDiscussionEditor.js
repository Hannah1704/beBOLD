import React, { useState } from "react";

export function AdminDiscussionEditor({ 
  isAdmin, 
  discussion, 
  projectId, 
  currentUserId, 
  onUpdate 
}) {
  const [editingIndex, setEditingIndex] = useState(null);
  const [editText, setEditText] = useState("");

  if (!isAdmin) return null;

  const handleEdit = (index, currentText) => {
    setEditingIndex(index);
    setEditText(currentText);
  };

  const handleSave = async (index) => {
    try 
    {
      const res = await fetch(`/api/projects/${projectId}/discussion/${index}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: editText, userId: currentUserId })
      });
      const data = await res.json();
      
      if(data.success) 
      {
        alert("Discussion message updated!");
        setEditingIndex(null);
        setEditText("");
        if (onUpdate) onUpdate();
      } 
      else 
      {
        alert("Error updating message: " + data.message);
      }
    } 
    catch(err) 
    {
      console.error(err);
      alert("Error updating message");
    }
  };

  const handleDelete = async (index) => {
    if(!confirm("Are you sure you want to delete this discussion message?")) return;

    try 
    {
      const res = await fetch(`/api/projects/${projectId}/discussion/${index}`, {
        method: "DELETE"
      });
      const data = await res.json();
      
      if(data.success) 
      {
        alert("Discussion message deleted!");
        if (onUpdate) onUpdate();
      } 
      else 
      {
        alert("Error deleting message: " + data.message);
      }
    } 
    catch(err) 
    {
      console.error(err);
      alert("Error deleting message");
    }
  };

  return (
    <div className="space-y-3">
      {discussion.map((msg, index) => (
        <div key={index} className="bg-yellow-900/20 border border-yellow-500 rounded-lg p-3">
          {editingIndex === index ? (
            <div>
              <textarea
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                className="w-full bg-white text-black rounded-md px-3 py-2 mb-2"
                rows={3}
              />
              <div className="flex gap-2">
                <button
                  onClick={() => handleSave(index)}
                  className="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600"
                >
                  Save
                </button>
                <button
                  onClick={() => {
                    setEditingIndex(null);
                    setEditText("");
                  }}
                  className="bg-gray-500 text-white px-3 py-1 rounded text-sm hover:bg-gray-600"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-start justify-between mb-2">
                <p className="text-gray-200 flex-1">{msg.text}</p>
                <div className="flex gap-2 ml-3">
                  <button
                    onClick={() => handleEdit(index, msg.text)}
                    className="text-yellow-400 hover:text-yellow-300 text-sm"
                    title="Edit (Admin)"
                  >
                    ✏️
                  </button>
                  <button
                    onClick={() => handleDelete(index)}
                    className="text-red-400 hover:text-red-300 text-sm"
                    title="Delete (Admin)"
                  >
                    🗑️
                  </button>
                </div>
              </div>
              <p className="text-xs text-gray-500">
                Message #{index + 1}
                {msg.editedAt && " (Edited by Admin)"}
              </p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}