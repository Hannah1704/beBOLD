import React from "react";
import { Project } from "./Project";

function GlobalFeed({ projects, onHashtagClick }) {
  return (
    <ul>
      {projects.map((proj) => (
        <Project key={proj._id} project={proj} onHashtagClick={onHashtagClick} />
      ))}
    </ul>
  );
}

export { GlobalFeed };