import React, { useState } from "react";

export function AdminControls({ 
  isAdmin, 
  onDeleteAllProjects, 
  onDeleteUser, 
  showDeleteProjects = false,
  showDeleteUser = false,
  userId = null,
  username = null
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [confirmDeleteUser, setConfirmDeleteUser] = useState(false);

  if(!isAdmin) return null;

  const handleDeleteAllProjects = async () =>{
    if(!confirmDelete) 
    {
      setConfirmDelete(true);
      return;
    }

    try 
    {
      const res = await fetch('/api/admin/delete-all-projects', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      
      if(data.success) 
      {
        alert(`Successfully deleted ${data.deletedCount} projects!`);
        if(onDeleteAllProjects) onDeleteAllProjects();
        setConfirmDelete(false);
      } 
      else 
      {
        alert('Error deleting projects: ' + data.message);
      }
    } 
    catch(err) 
    {
      console.error(err);
      alert('Error deleting projects');
    }
  };

  const handleDeleteUser = async () => {
    if(!confirmDeleteUser) 
    {
      setConfirmDeleteUser(true);
      return;
    }

    try 
    {
      const res = await fetch(`/api/users/${userId}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      
      if(data.success) 
      {
        alert(`User ${username} deleted successfully!`);
        if (onDeleteUser) onDeleteUser(userId);
        setConfirmDeleteUser(false);
      } 
      else 
      {
        alert('Error deleting user: ' + data.message);
      }
    } catch (err) {
      console.error(err);
      alert('Error deleting user');
    }
  };

  return(
    <div className="bg-red-900/20 border-2 border-red-500 rounded-xl p-6 mt-6">
      <div className="flex items-center gap-3 mb-4">
        <span className="text-3xl">⚠️</span>
        <div>
          <h3 className="text-red-400 font-bold text-xl">Admin Controls</h3>
          <p className="text-red-300 text-sm">Dangerous operations - be careful when using</p>
        </div>
      </div>

      <div className="space-y-4">
        {showDeleteProjects && (
          <div className="bg-red-900/30 p-4 rounded-lg">
            <h4 className="text-red-300 font-semibold mb-2">Delete All Projects</h4>
            <p className="text-gray-300 text-sm mb-3">
              This will delete ALL projects from the database. This action cannot be undone.
            </p>
            <button
              onClick={handleDeleteAllProjects}
              className={`w-full px-4 py-3 rounded-lg font-bold transition-all ${
                confirmDelete
                  ? 'bg-red-600 hover:bg-red-700 animate-pulse'
                  : 'bg-red-500 hover:bg-red-600'
              } text-white`}
            >
              {confirmDelete ? '⚠️ Click Again to Confirm Delete' : '🗑️ Delete All Projects'}
            </button>
            {confirmDelete && (
              <button
                onClick={() => setConfirmDelete(false)}
                className="w-full mt-2 px-4 py-2 rounded-lg bg-gray-600 hover:bg-gray-700 text-white"
              >
                Cancel
              </button>
            )}
          </div>
        )}

        {showDeleteUser && userId && (
          <div className="bg-red-900/30 p-4 rounded-lg">
            <h4 className="text-red-300 font-semibold mb-2">Delete User Account</h4>
            <p className="text-gray-300 text-sm mb-3">
              This will delete the user account for <span className="font-bold">{username}</span>. 
              This action cannot be undone!
            </p>
            <button
              onClick={handleDeleteUser}
              className={`w-full px-4 py-3 rounded-lg font-bold transition-all ${
                confirmDeleteUser
                  ? 'bg-red-600 hover:bg-red-700 animate-pulse'
                  : 'bg-red-500 hover:bg-red-600'
              } text-white`}
            >
              {confirmDeleteUser ? '⚠️ Click Again to Confirm Delete' : `🗑️ Delete User: ${username}`}
            </button>
            {confirmDeleteUser && (
              <button
                onClick={() => setConfirmDeleteUser(false)}
                className="w-full mt-2 px-4 py-2 rounded-lg bg-gray-600 hover:bg-gray-700 text-white"
              >
                Cancel
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}