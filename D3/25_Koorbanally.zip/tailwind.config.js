/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./frontend/src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#5318A0",   // background
        layer: "#6C2BAF",     // slightly lighter card
        accent1: "#F50DC6",   // bold pink
        accent2: "#5EE7C8",   // teal accent
        accent3: "#B2E131",   // green accent
      },
      fontFamily: {
        bold: ["Poppins", "sans-serif"],
      },
    },
  },
  plugins: [],
};
