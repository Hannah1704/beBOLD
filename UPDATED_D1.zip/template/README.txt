1. Building the docker file 
docker build -t be-bold .

2. Run
docker run -p 3000:3000 be-bold

gitHub
https://github.com/Hannah1704/beBOLD