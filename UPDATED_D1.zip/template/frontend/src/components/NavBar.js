import React from "react";
import { Link, useLocation } from "react-router-dom";

function NavBar({ currentUser }){

  const location= useLocation();
  const isActive =(path) => location.pathname.startsWith(path);

  return (
    <nav>
      <Link to="/home" style={{ fontWeight: isActive("/home") ? "bold" : "normal" }}>Home</Link> |{" "}

      <Link to={`/profile/${currentUser.id}`} style={{ fontWeight: isActive("/profile") ? "bold" : "normal" }}>Profile</Link> |{" "}

      <Link to="/projects" style={{ fontWeight: isActive("/projects") ? "bold" : "normal" }}>Projects</Link> |{" "}
      
      <Link to="/">Logout</Link>
    </nav>
  );
}

export { NavBar };


// import React from "react";
// import { Link } from "react-router-dom";

// function NavBar() {
//   return (
//     <nav>
//       <Link to="/home">Home</Link> |{" "}
//       <Link to="/profile">Profile</Link> |{" "}
//       <Link to="/projects">Projects</Link> |{" "}
//       <Link to="/">Logout</Link>
//     </nav>
//   );
// }

// export { NavBar };
