import React from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";

import Home from "./pages/Home";
import Projects from "./pages/Projects";
import Profile from "./pages/Profile";
import Splash from "./pages/Splash";
import ProjectView from "./pages/ProjectView";

import { NavBar } from "./components/NavBar";
import { users } from "./data";

function AppWrapper(){
  return (
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
}

function App() {
  const location = useLocation();
  const currentUser = users[0]; 
  const hideNav = location.pathname=== "/";

  return (
    <div>
      {!hideNav && <NavBar currentUser={currentUser} />}

      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/profile/:id" element={<Profile />} />  
        <Route path="/projects" element={<Projects />} />
        <Route path="/projects/:id" element={<ProjectView />} /> 
        <Route path="/" element={<Splash />} />
      </Routes>
    </div>
  );
}

export default AppWrapper;
