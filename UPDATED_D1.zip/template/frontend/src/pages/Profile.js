import React from "react";
import { useParams } from "react-router-dom";
import { GeneralData } from "../components/GeneralData";
import { UserActivity } from "../components/UserActivity";
import { Friends } from "../components/Friends";

function Profile() {
  const { id } = useParams();
  const userId = Number(id) || 1; //goes to dummy 1 if problem 

  return (
    <div>
      <h1>Profile Page</h1>

      <h2>My Profile Data</h2>
      <GeneralData userId={userId} />

      <h2>My Activity</h2>
      <UserActivity userId={userId} />

      <h2>My Friends</h2>
      <Friends userId={userId} />
    </div>
  );
}

export default Profile;



// import React from "react";
// import {GeneralData} from "../components/GeneralData"
// import { UserActivity } from "../components/UserActivity";
// import {Friends} from "../components/Friends"
// function Profile() {
//   return (
//     <div>
//       <h1>Profile Page</h1>

//       <h2>My Profile Data</h2>
//       <GeneralData userId={1} />

//       <h2>My Activity</h2>
//       <UserActivity userId={1}/>

//       <h2>My Friends</h2>
//       <Friends userId={1}/>
      
//     </div>
//   );
// }

// export default Profile;
