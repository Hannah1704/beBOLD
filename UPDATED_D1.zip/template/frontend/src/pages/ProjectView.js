import React,{ useState } from "react";
import { useParams } from "react-router-dom";
import { localFeedData, users } from "../data";

function ProjectView(){
  const { id } = useParams();
  const projectId = Number(id);
  const project = localFeedData.find((p) => p.id === projectId);

  const [checkins, setCheckins] = useState([
    { userId: 2, message: "Initial commit to project x" },
    { userId: 3, message: "Me, i fix bug" },
  ]);

  const [newMessage, setNewMessage] = useState("");
  const currentUserId = 1;

  if(!project) return <p>Project not found</p>;

  const addCheckin = () => {
    if (newMessage.trim() === "") return;
    setCheckins([...checkins, { userId: currentUserId, message: newMessage }]);
    setNewMessage("");
  };

  return (
    <div>
      <h1>{project.name}</h1>
      <p>{project.description}</p>
      <p><strong>Owner:</strong> {users.find(u => u.id === project.owner)?.username}</p>

      <h3>Members</h3>
      <ul>
        {project.participants.map(id => (
          <li key={id}>{users.find(u => u.id === id)?.username}</li>
        ))}
      </ul>

      <h3>Check-ins</h3>
      <ul>
        {checkins.map((c, i) => (
          <li key={i}>
            <b>{users.find(u => u.id === c.userId)?.username}:</b> {c.message}
          </li>
        ))}
      </ul>

      <input
        type="text"
        value={newMessage}
        onChange={(e) => setNewMessage(e.target.value)}
        placeholder="Check in message"
      />
      <button onClick={addCheckin}>Check in</button>
    </div>
  );
}

export default ProjectView;
